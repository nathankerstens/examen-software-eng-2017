﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace yahtzee
{
    class Dice
    {
        int id, value, x, y, defaultX, defaultY;
        public bool selected = false;
        static Random rnd = new Random();

        public Dice(int id, int value, int defaultX, int defaultY)
        {
            this.id = id;
            this.value = value;
            this.defaultX = defaultX;
            this.defaultY = defaultY;
        }

        public void randomize()
        {  
            if (selected == false)
            {
                value = rnd.Next(1, 7);
                changePos();
            }
        }

        public void reset()
        {
            value = 1;
            selected = false;
            x = defaultX;
            y = defaultY;
        }

        public void clicked()
        {
            if (selected)
            {
                selected = false;
                changePos();
            }else
            {
                selected = true;
                x = defaultX;
                y = defaultY;
            }
        }

        public void changePos()
        {
            switch (id)
            {
                case 1:
                    x = rnd.Next(220, 281);
                    break;
                case 2:
                    x = rnd.Next(370, 431);
                    break;
                case 3:
                    x = rnd.Next(520, 581);
                    break;
                case 4:
                    x = rnd.Next(670, 731);
                    break;
                case 5:
                    x = rnd.Next(820, 881);
                    break;
            }
            y = rnd.Next(100, 301);
        }

        public int getValue()
        {
            return value;
        }
        public int getX()
        {
            return x;
        }
        public int getY()
        {
            return y;
        }
    }
}

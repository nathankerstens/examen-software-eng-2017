﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace yahtzee
{
    public partial class Form1 : Form
    {
        Image image1 = new Bitmap(@"D:\_KDG 2DE JAAR\Software engineering\yahtzee\yahtzee\assets\1.png");
        Image image2 = new Bitmap(@"D:\_KDG 2DE JAAR\Software engineering\yahtzee\yahtzee\assets\2.png");
        Image image3 = new Bitmap(@"D:\_KDG 2DE JAAR\Software engineering\yahtzee\yahtzee\assets\3.png");
        Image image4 = new Bitmap(@"D:\_KDG 2DE JAAR\Software engineering\yahtzee\yahtzee\assets\4.png");
        Image image5 = new Bitmap(@"D:\_KDG 2DE JAAR\Software engineering\yahtzee\yahtzee\assets\5.png");
        Image image6 = new Bitmap(@"D:\_KDG 2DE JAAR\Software engineering\yahtzee\yahtzee\assets\6.png");

        public Form1()
        {
            InitializeComponent();
            panel1.Visible = false;
        }

        Controller controller = new Controller();

        private void rollDice_Click(object sender, EventArgs e)
        {
            controller.rollDice();
            updateDiceImage();
            updateDiceLocation();
            updateScoreBoard();
            updateScreen();
        }

        private void dice1_Click(object sender, EventArgs e)
        {
            controller.dice[0].clicked();
            updateDiceLocation();
        }

        private void dice2_Click(object sender, EventArgs e)
        {
            controller.dice[1].clicked();
            updateDiceLocation();
        }

        private void dice3_Click(object sender, EventArgs e)
        {
            controller.dice[2].clicked();
            updateDiceLocation();
        }

        private void dice4_Click(object sender, EventArgs e)
        {
            controller.dice[3].clicked();
            updateDiceLocation();
        }

        private void dice5_Click(object sender, EventArgs e)
        {
            controller.dice[4].clicked();
            updateDiceLocation();
        }

        private void updateDiceImage()
        {
            switch (controller.dice[0].getValue())
            {
                case 1:
                    dice1.Image = image1;
                    break;
                case 2:
                    dice1.Image = image2;
                    break;
                case 3:
                    dice1.Image = image3;
                    break;
                case 4:
                    dice1.Image = image4;
                    break;
                case 5:
                    dice1.Image = image5;
                    break;
                case 6:
                    dice1.Image = image6;
                    break;
            }

            switch (controller.dice[1].getValue())
            {
                case 1:
                    dice2.Image = image1;
                    break;
                case 2:
                    dice2.Image = image2;
                    break;
                case 3:
                    dice2.Image = image3;
                    break;
                case 4:
                    dice2.Image = image4;
                    break;
                case 5:
                    dice2.Image = image5;
                    break;
                case 6:
                    dice2.Image = image6;
                    break;
            }

            switch (controller.dice[2].getValue())
            {
                case 1:
                    dice3.Image = image1;
                    break;
                case 2:
                    dice3.Image = image2;
                    break;
                case 3:
                    dice3.Image = image3;
                    break;
                case 4:
                    dice3.Image = image4;
                    break;
                case 5:
                    dice3.Image = image5;
                    break;
                case 6:
                    dice3.Image = image6;
                    break;
            }

            switch (controller.dice[3].getValue())
            {
                case 1:
                    dice4.Image = image1;
                    break;
                case 2:
                    dice4.Image = image2;
                    break;
                case 3:
                    dice4.Image = image3;
                    break;
                case 4:
                    dice4.Image = image4;
                    break;
                case 5:
                    dice4.Image = image5;
                    break;
                case 6:
                    dice4.Image = image6;
                    break;
            }

            switch (controller.dice[4].getValue())
            {
                case 1:
                    dice5.Image = image1;
                    break;
                case 2:
                    dice5.Image = image2;
                    break;
                case 3:
                    dice5.Image = image3;
                    break;
                case 4:
                    dice5.Image = image4;
                    break;
                case 5:
                    dice5.Image = image5;
                    break;
                case 6:
                    dice5.Image = image6;
                    break;
            }
        }

        private void updateDiceLocation()
        {
            dice1.Location = new Point(controller.dice[0].getX(), controller.dice[0].getY());
            dice2.Location = new Point(controller.dice[1].getX(), controller.dice[1].getY());
            dice3.Location = new Point(controller.dice[2].getX(), controller.dice[2].getY());
            dice4.Location = new Point(controller.dice[3].getX(), controller.dice[3].getY());
            dice5.Location = new Point(controller.dice[4].getX(), controller.dice[4].getY());
        }

        private void updateScoreBoard()
        {
            if (controller.score.onesSet == false)
            {
                ones.Text = controller.score.Ones(controller.dice[0].getValue(),
                controller.dice[1].getValue(),
                controller.dice[2].getValue(),
                controller.dice[3].getValue(),
                controller.dice[4].getValue()).ToString();
            }else
            {
                ones.Text = controller.score.ones.ToString();
            }
            if (controller.score.twosSet == false)
            {
                twos.Text = controller.score.Twos(controller.dice[0].getValue(),
                controller.dice[1].getValue(),
                controller.dice[2].getValue(),
                controller.dice[3].getValue(),
                controller.dice[4].getValue()).ToString();
            }
            else
            {
                twos.Text = controller.score.twos.ToString();
            }
            if (controller.score.threesSet == false)
            {
                threes.Text = controller.score.Threes(controller.dice[0].getValue(),
                controller.dice[1].getValue(),
                controller.dice[2].getValue(),
                controller.dice[3].getValue(),
                controller.dice[4].getValue()).ToString();
            }
            else
            {
                threes.Text = controller.score.threes.ToString();
            }
            if (controller.score.foursSet = false)
            {
                fours.Text = controller.score.Fours(controller.dice[0].getValue(),
                controller.dice[1].getValue(),
                controller.dice[2].getValue(),
                controller.dice[3].getValue(),
                controller.dice[4].getValue()).ToString();
            }
            else
            {
                fours.Text = controller.score.fours.ToString();
            }
            if (controller.score.fivesSet == false)
            {
                fives.Text = controller.score.Fives(controller.dice[0].getValue(),
                controller.dice[1].getValue(),
                controller.dice[2].getValue(),
                controller.dice[3].getValue(),
                controller.dice[4].getValue()).ToString();
            }
            else
            {
                fives.Text = controller.score.fives.ToString();
            }
            if (controller.score.sixesSet = false)
            {
                sixes.Text = controller.score.Sixes(controller.dice[0].getValue(),
                controller.dice[1].getValue(),
                controller.dice[2].getValue(),
                controller.dice[3].getValue(),
                controller.dice[4].getValue()).ToString();
            }
            else
            {
                sixes.Text = controller.score.sixes.ToString();
            }

            if (controller.score.threeOfAKindSet == false)
            {
                threeOfAKind.Text = controller.score.ThreeOfAKind(controller.dice[0].getValue(),
                controller.dice[1].getValue(),
                controller.dice[2].getValue(),
                controller.dice[3].getValue(),
                controller.dice[4].getValue()).ToString();
            }
            else
            {
                threeOfAKind.Text = controller.score.threeOfAKind.ToString();
            }
            if (controller.score.fourOfAKindSet == false)
            {
                fourOfAKind.Text = controller.score.FourOfAKind(controller.dice[0].getValue(),
                controller.dice[1].getValue(),
                controller.dice[2].getValue(),
                controller.dice[3].getValue(),
                controller.dice[4].getValue()).ToString();
            }
            else
            {
                fourOfAKind.Text = controller.score.fourOfAKind.ToString();
            }
            if (controller.score.fullHouseSet == false)
            {
                fullHouse.Text = controller.score.FullHouse(controller.dice[0].getValue(),
                controller.dice[1].getValue(),
                controller.dice[2].getValue(),
                controller.dice[3].getValue(),
                controller.dice[4].getValue()).ToString();
            }
            else
            {
                fullHouse.Text = controller.score.fullHouse.ToString();
            }
            if (controller.score.smallStraightSet == false)
            {
                smallStraight.Text = controller.score.SmallStraight(controller.dice[0].getValue(),
                controller.dice[1].getValue(),
                controller.dice[2].getValue(),
                controller.dice[3].getValue(),
                controller.dice[4].getValue()).ToString();
            }
            else
            {
                smallStraight.Text = controller.score.smallStraight.ToString();
            }
            if (controller.score.largeStraightSet == false)
            {
                largeStraight.Text = controller.score.LargeStraight(controller.dice[0].getValue(),
                controller.dice[1].getValue(),
                controller.dice[2].getValue(),
                controller.dice[3].getValue(),
                controller.dice[4].getValue()).ToString();
            }
            else
            {
                largeStraight.Text = controller.score.largeStraight.ToString();
            }
            if (controller.score.chanceSet == false)
            {
                chance.Text = controller.score.Chance(controller.dice[0].getValue(),
                controller.dice[1].getValue(),
                controller.dice[2].getValue(),
                controller.dice[3].getValue(),
                controller.dice[4].getValue()).ToString();
            }
            else
            {
                chance.Text = controller.score.chance.ToString();
            }
            if (controller.score.yahtzeeSet == false)
            {
                yahtzee.Text = controller.score.Yahtzee(controller.dice[0].getValue(),
                controller.dice[1].getValue(),
                controller.dice[2].getValue(),
                controller.dice[3].getValue(),
                controller.dice[4].getValue()).ToString();
            }
            else
            {
                yahtzee.Text = controller.score.yahtzee.ToString();
            }

            score.Text = controller.score.Total().ToString();
        }

        private void updateScreen()
        {
            if(controller.throwsLeft > 0)
            {
                throwsLeft.Text = "Throws left: " + controller.throwsLeft;
            }else
            {
                throwsLeft.Text = "Select your move by clicking one of the white cells at the right side:";
            }
        }
        
        private void resetDices()
        {
            for (int i = 0; i < 5; i++)
            {
                controller.dice[i].reset();
            }
        }

        private void ones_Click(object sender, EventArgs e)
        {
            if (controller.throwsLeft <=2)
            {
                controller.score.ones = controller.score.Ones(controller.dice[0].getValue(),
                controller.dice[1].getValue(),
                controller.dice[2].getValue(),
                controller.dice[3].getValue(),
                controller.dice[4].getValue());
                controller.score.onesSet = true;
                ones.BackColor = Color.LightBlue;
                controller.throwsLeft = 3;
                resetDices();
                updateScreen();
            }
        }

        private void twos_Click(object sender, EventArgs e)
        {
            if (controller.throwsLeft <= 2)
            {
                controller.score.twos = controller.score.Twos(controller.dice[0].getValue(),
                controller.dice[1].getValue(),
                controller.dice[2].getValue(),
                controller.dice[3].getValue(),
                controller.dice[4].getValue());
                controller.score.twosSet = true;
                twos.BackColor = Color.LightBlue;
                controller.throwsLeft = 3;
                resetDices();
                updateScreen();
            }
        }

        private void threes_Click(object sender, EventArgs e)
        {
            if (controller.throwsLeft <= 2)
            {
                controller.score.threes = controller.score.Threes(controller.dice[0].getValue(),
                controller.dice[1].getValue(),
                controller.dice[2].getValue(),
                controller.dice[3].getValue(),
                controller.dice[4].getValue());
                controller.score.threesSet = true;
                threes.BackColor = Color.LightBlue;
                controller.throwsLeft = 3;
                resetDices();
                updateScreen();
            }
        }

        private void fours_Click(object sender, EventArgs e)
        {
            if (controller.throwsLeft <= 2)
            {
                controller.score.fours = controller.score.Fours(controller.dice[0].getValue(),
                controller.dice[1].getValue(),
                controller.dice[2].getValue(),
                controller.dice[3].getValue(),
                controller.dice[4].getValue());
                controller.score.foursSet = true;
                fours.BackColor = Color.LightBlue;
                controller.throwsLeft = 3;
                resetDices();
                updateScreen();
            }
        }

        private void fives_Click(object sender, EventArgs e)
        {
            if (controller.throwsLeft <= 2)
            {
                controller.score.fives = controller.score.Fives(controller.dice[0].getValue(),
                controller.dice[1].getValue(),
                controller.dice[2].getValue(),
                controller.dice[3].getValue(),
                controller.dice[4].getValue());
                controller.score.fivesSet = true;
                fives.BackColor = Color.LightBlue;
                controller.throwsLeft = 3;
                resetDices();
                updateScreen();
            }
        }

        private void sixes_Click(object sender, EventArgs e)
        {
            if (controller.throwsLeft <= 2)
            {
                controller.score.sixes = controller.score.Sixes(controller.dice[0].getValue(),
                controller.dice[1].getValue(),
                controller.dice[2].getValue(),
                controller.dice[3].getValue(),
                controller.dice[4].getValue());
                controller.score.sixesSet = true;
                sixes.BackColor = Color.LightBlue;
                controller.throwsLeft = 3;
                resetDices();
                updateScreen();
            }
        }

        private void threeOfAKind_Click(object sender, EventArgs e)
        {
            if (controller.throwsLeft <= 2)
            {
                controller.score.threeOfAKind = controller.score.ThreeOfAKind(controller.dice[0].getValue(),
                controller.dice[1].getValue(),
                controller.dice[2].getValue(),
                controller.dice[3].getValue(),
                controller.dice[4].getValue());
                controller.score.threeOfAKindSet = true;
                threeOfAKind.BackColor = Color.LightBlue;
                controller.throwsLeft = 3;
                resetDices();
                updateScreen();
            }
        }

        private void fourOfAKind_Click(object sender, EventArgs e)
        {
            if (controller.throwsLeft <= 2)
            {
                controller.score.fourOfAKind = controller.score.FourOfAKind(controller.dice[0].getValue(),
                controller.dice[1].getValue(),
                controller.dice[2].getValue(),
                controller.dice[3].getValue(),
                controller.dice[4].getValue());
                controller.score.fourOfAKindSet = true;
                fourOfAKind.BackColor = Color.LightBlue;
                controller.throwsLeft = 3;
                resetDices();
                updateScreen();
            }
        }

        private void fullHouse_Click(object sender, EventArgs e)
        {
            if (controller.throwsLeft <= 2)
            {
                controller.score.fullHouse = controller.score.FullHouse(controller.dice[0].getValue(),
                controller.dice[1].getValue(),
                controller.dice[2].getValue(),
                controller.dice[3].getValue(),
                controller.dice[4].getValue());
                controller.score.fullHouseSet = true;
                fullHouse.BackColor = Color.LightBlue;
                controller.throwsLeft = 3;
                resetDices();
                updateScreen();
            }
        }

        private void smallStraight_Click(object sender, EventArgs e)
        {
            if (controller.throwsLeft <= 2)
            {
                controller.score.smallStraight = controller.score.SmallStraight(controller.dice[0].getValue(),
                controller.dice[1].getValue(),
                controller.dice[2].getValue(),
                controller.dice[3].getValue(),
                controller.dice[4].getValue());
                controller.score.smallStraightSet = true;
                smallStraight.BackColor = Color.LightBlue;
                controller.throwsLeft = 3;
                resetDices();
                updateScreen();
            }
        }

        private void largeStraight_Click(object sender, EventArgs e)
        {
            if (controller.throwsLeft <= 2)
            {
                controller.score.largeStraight = controller.score.LargeStraight(controller.dice[0].getValue(),
                controller.dice[1].getValue(),
                controller.dice[2].getValue(),
                controller.dice[3].getValue(),
                controller.dice[4].getValue());
                controller.score.largeStraightSet = true;
                largeStraight.BackColor = Color.LightBlue;
                controller.throwsLeft = 3;
                resetDices();
                updateScreen();
            }
        }

        private void chance_Click(object sender, EventArgs e)
        {
            if (controller.throwsLeft <= 2)
            {
                controller.score.chance = controller.score.Chance(controller.dice[0].getValue(),
                controller.dice[1].getValue(),
                controller.dice[2].getValue(),
                controller.dice[3].getValue(),
                controller.dice[4].getValue());
                controller.score.chanceSet = true;
                chance.BackColor = Color.LightBlue;
                controller.throwsLeft = 3;
                resetDices();
                updateScreen();
            }
        }

        private void yahtzee_Click(object sender, EventArgs e)
        {
            if (controller.throwsLeft <= 2)
            {
                controller.score.yahtzee = controller.score.Yahtzee(controller.dice[0].getValue(),
                controller.dice[1].getValue(),
                controller.dice[2].getValue(),
                controller.dice[3].getValue(),
                controller.dice[4].getValue());
                controller.score.yahtzeeSet = true;
                yahtzee.BackColor = Color.LightBlue;
                controller.throwsLeft = 3;
                resetDices();
                updateScreen();
            }
        }

        private void help_Click(object sender, EventArgs e)
        {
            if(panel1.Visible == false)
            {
                panel1.Visible = true;
            }else
            {
                panel1.Visible = false;
            }
            
        }
    }
}

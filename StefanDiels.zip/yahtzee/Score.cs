﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace yahtzee
{
    class Score
    {
        public int ones,
            twos,
            threes,
            fours,
            fives,
            sixes,
            threeOfAKind,
            fourOfAKind,
            fullHouse,
            smallStraight,
            largeStraight,
            chance,
            yahtzee;
        public bool onesSet = false,
            twosSet = false,
            threesSet = false,
            foursSet = false,
            fivesSet = false,
            sixesSet = false,
            threeOfAKindSet = false,
            fourOfAKindSet = false,
            fullHouseSet = false,
            smallStraightSet = false,
            largeStraightSet = false,
            chanceSet = false,
            yahtzeeSet = false;

        public int Ones(int a, int b, int c, int d, int e)
        {
            int score = 0;
            int[] values = new int[] { a, b, c, d, e };

            for (int i = 0; i < 5; i++)
            {
                if (values[i] == 1)
                {
                    score += 1;
                }
            }
            Console.WriteLine(ones);
            return score;
        }
        public int Twos(int a, int b, int c, int d, int e)
        {
            int score = 0;
            int[] values = new int[] { a, b, c, d, e };

            for (int i = 0; i < 5; i++)
            {
                if (values[i] == 2)
                {
                    score += 2;
                }
            }
            return score;
        }
        public int Threes(int a, int b, int c, int d, int e)
        {
            int score = 0;
            int[] values = new int[] { a, b, c, d, e };

            for (int i = 0; i < 5; i++)
            {
                if (values[i] == 3)
                {
                    score += 3;
                }
            }
            return score;
        }
        public int Fours(int a, int b, int c, int d, int e)
        {
            int score = 0;
            int[] values = new int[] { a, b, c, d, e };

            for (int i = 0; i < 5; i++)
            {
                if (values[i] == 4)
                {
                    score += 4;
                }
            }
            return score;
        }
        public int Fives(int a, int b, int c, int d, int e)
        {
            int score = 0;
            int[] values = new int[] { a, b, c, d, e };

            for (int i = 0; i < 5; i++)
            {
                if (values[i] == 5)
                {
                    score += 5;
                }
            }
            return score;
        }
        public int Sixes(int a, int b, int c, int d, int e)
        {
            int score = 0;
            int[] values = new int[] { a, b, c, d, e };

            for (int i = 0; i < 5; i++)
            {
                if (values[i] == 6)
                {
                    score += 6;
                }
            }
            return score;
        }

        public int ThreeOfAKind(int a, int b, int c, int d, int e)
        {
            int[] values = new int[] { a, b, c, d, e };
            Array.Sort(values);
            int oneCount = 0, twoCount = 0, threeCount = 0, fourCount = 0, fiveCount = 0, sixCount = 0;
            for (int i = 0; i < 5; i++)
            {
                if (values[i] == 1)
                {
                    oneCount++;
                }
                if (values[i] == 2)
                {
                    twoCount++;
                }
                if (values[i] == 3)
                {
                    threeCount++;
                }
                if (values[i] == 4)
                {
                    fourCount++;
                }
                if (values[i] == 5)
                {
                    fiveCount++;
                }
                if (values[i] == 6)
                {
                    sixCount++;
                }
            }
            if (oneCount >= 3 || twoCount >= 3 || threeCount >= 3 || fourCount >= 3 || fiveCount >= 3 || sixCount >= 3)
            {
                return a + b + c + d + e;
            }else
            {
                return 0;
            }
        }

        public int FourOfAKind(int a, int b, int c, int d, int e)
        {
            int[] values = new int[] { a, b, c, d, e };
            Array.Sort(values);
            int oneCount = 0, twoCount = 0, threeCount = 0, fourCount = 0, fiveCount = 0, sixCount = 0;
            for (int i = 0; i < 5; i++)
            {
                if (values[i] == 1)
                {
                    oneCount++;
                }
                if (values[i] == 2)
                {
                    twoCount++;
                }
                if (values[i] == 3)
                {
                    threeCount++;
                }
                if (values[i] == 4)
                {
                    fourCount++;
                }
                if (values[i] == 5)
                {
                    fiveCount++;
                }
                if (values[i] == 6)
                {
                    sixCount++;
                }
            }
            if (oneCount >= 4 || twoCount >= 4 || threeCount >= 4 || fourCount >= 4 || fiveCount >= 4 || sixCount >= 4)
            {
                return a + b + c + d + e;
            }
            else
            {
                return 0;
            }
        }

        public int SmallStraight(int a, int b, int c, int d, int e)
        {
            int[] values = new int[] { a, b, c, d, e };
            Array.Sort(values);
            values.Distinct();
            if (values[0] == values[1]-1 && values[1] == values[2] - 1 && values[2] == values[3] - 1)
            {
                return 30;
            }else
            {
                return 0;
            }
        }

        public int LargeStraight(int a, int b, int c, int d, int e)
        {
            int[] values = new int[] { a, b, c, d, e };
            Array.Sort(values);
            values.Distinct();
            if (values[0] == values[1] - 1 && values[1] == values[2] - 1 && values[2] == values[3] - 1 && values[3] == values[4] - 1)
            {
                return 30;
            }
            else
            {
                return 0;
            }
        }

        public int FullHouse(int a, int b, int c, int d, int e)
        {
            int[] values = new int[] { a, b, c, d, e };
            Array.Sort(values);
            if (values[0] == values[1] && values[1] == values[2] && values[3] == values[4])
            {
                return 25;
            }
            else if (values[0] == values[1] && values[2] == values[3] && values[3] == values[4])
            {
                return 25;
            }else
            {
                return 0;
            }
        }

        public int Chance(int a, int b, int c, int d, int e)
        {
            return a + b + c + d + e;
        }

        public int Yahtzee(int a, int b, int c, int d, int e)
        {
            if (a == b && b == c && c == d && d == e)
            {
                return 50;
            }
            else
            {
                return 0;
            }
        }

        public int Total()
        {
            return ones + twos + threes + fours + fives + sixes + threeOfAKind + fourOfAKind + fullHouse + smallStraight + largeStraight + chance + yahtzee;
        }
    }
}

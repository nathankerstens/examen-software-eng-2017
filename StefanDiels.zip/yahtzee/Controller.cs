﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace yahtzee
{
    class Controller
    {

        public Dice[] dice = new Dice[] { new Dice(1, 1, 250, 550),
            new Dice(2, 2, 400, 550),
            new Dice(3, 3, 550, 550),
            new Dice(4, 4, 700, 550),
            new Dice(5, 5, 850, 550) };
        public Score score = new Score();
        public int throwsLeft = 3;

        public void rollDice()
        {
            if (throwsLeft >= 1)
            {
                for (int i = 0; i < 5; i++)
                {
                    dice[i].randomize();
                }
                throwsLeft--;
            }
        }

    }
}

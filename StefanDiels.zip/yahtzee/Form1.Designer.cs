﻿namespace yahtzee
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.rollDice = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dice5 = new System.Windows.Forms.Button();
            this.dice4 = new System.Windows.Forms.Button();
            this.dice3 = new System.Windows.Forms.Button();
            this.dice2 = new System.Windows.Forms.Button();
            this.dice1 = new System.Windows.Forms.Button();
            this.ones = new System.Windows.Forms.Button();
            this.twos = new System.Windows.Forms.Button();
            this.threes = new System.Windows.Forms.Button();
            this.fours = new System.Windows.Forms.Button();
            this.fives = new System.Windows.Forms.Button();
            this.sixes = new System.Windows.Forms.Button();
            this.sum = new System.Windows.Forms.Button();
            this.bonus = new System.Windows.Forms.Button();
            this.threeOfAKind = new System.Windows.Forms.Button();
            this.fourOfAKind = new System.Windows.Forms.Button();
            this.fullHouse = new System.Windows.Forms.Button();
            this.smallStraight = new System.Windows.Forms.Button();
            this.largeStraight = new System.Windows.Forms.Button();
            this.chance = new System.Windows.Forms.Button();
            this.yahtzee = new System.Windows.Forms.Button();
            this.score = new System.Windows.Forms.Button();
            this.throwsLeft = new System.Windows.Forms.Label();
            this.help = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // rollDice
            // 
            this.rollDice.Location = new System.Drawing.Point(464, 414);
            this.rollDice.Name = "rollDice";
            this.rollDice.Size = new System.Drawing.Size(268, 91);
            this.rollDice.TabIndex = 2;
            this.rollDice.Text = "Roll dice";
            this.rollDice.UseVisualStyleBackColor = true;
            this.rollDice.Click += new System.EventHandler(this.rollDice_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::yahtzee.Properties.Resources.scoreboard;
            this.pictureBox1.Location = new System.Drawing.Point(1090, 18);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(153, 487);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // dice5
            // 
            this.dice5.BackgroundImage = global::yahtzee.Properties.Resources._1;
            this.dice5.Location = new System.Drawing.Point(850, 550);
            this.dice5.Name = "dice5";
            this.dice5.Size = new System.Drawing.Size(100, 100);
            this.dice5.TabIndex = 6;
            this.dice5.Text = "5";
            this.dice5.UseVisualStyleBackColor = true;
            this.dice5.Click += new System.EventHandler(this.dice5_Click);
            // 
            // dice4
            // 
            this.dice4.BackgroundImage = global::yahtzee.Properties.Resources._1;
            this.dice4.Location = new System.Drawing.Point(700, 550);
            this.dice4.Name = "dice4";
            this.dice4.Size = new System.Drawing.Size(100, 100);
            this.dice4.TabIndex = 5;
            this.dice4.Text = "4";
            this.dice4.UseVisualStyleBackColor = true;
            this.dice4.Click += new System.EventHandler(this.dice4_Click);
            // 
            // dice3
            // 
            this.dice3.BackgroundImage = global::yahtzee.Properties.Resources._1;
            this.dice3.Location = new System.Drawing.Point(550, 550);
            this.dice3.Name = "dice3";
            this.dice3.Size = new System.Drawing.Size(100, 100);
            this.dice3.TabIndex = 4;
            this.dice3.Text = "3";
            this.dice3.UseVisualStyleBackColor = true;
            this.dice3.Click += new System.EventHandler(this.dice3_Click);
            // 
            // dice2
            // 
            this.dice2.BackgroundImage = global::yahtzee.Properties.Resources._1;
            this.dice2.Location = new System.Drawing.Point(400, 550);
            this.dice2.Name = "dice2";
            this.dice2.Size = new System.Drawing.Size(100, 100);
            this.dice2.TabIndex = 3;
            this.dice2.Text = "2";
            this.dice2.UseVisualStyleBackColor = true;
            this.dice2.Click += new System.EventHandler(this.dice2_Click);
            // 
            // dice1
            // 
            this.dice1.BackgroundImage = global::yahtzee.Properties.Resources._1;
            this.dice1.Location = new System.Drawing.Point(250, 550);
            this.dice1.Name = "dice1";
            this.dice1.Size = new System.Drawing.Size(100, 100);
            this.dice1.TabIndex = 1;
            this.dice1.Text = "1";
            this.dice1.UseVisualStyleBackColor = true;
            this.dice1.Click += new System.EventHandler(this.dice1_Click);
            // 
            // ones
            // 
            this.ones.BackColor = System.Drawing.SystemColors.Window;
            this.ones.Location = new System.Drawing.Point(1199, 18);
            this.ones.Name = "ones";
            this.ones.Size = new System.Drawing.Size(44, 32);
            this.ones.TabIndex = 8;
            this.ones.Text = "0";
            this.ones.UseVisualStyleBackColor = false;
            this.ones.Click += new System.EventHandler(this.ones_Click);
            // 
            // twos
            // 
            this.twos.BackColor = System.Drawing.SystemColors.Window;
            this.twos.Location = new System.Drawing.Point(1199, 48);
            this.twos.Name = "twos";
            this.twos.Size = new System.Drawing.Size(44, 32);
            this.twos.TabIndex = 9;
            this.twos.Text = "0";
            this.twos.UseVisualStyleBackColor = false;
            this.twos.Click += new System.EventHandler(this.twos_Click);
            // 
            // threes
            // 
            this.threes.BackColor = System.Drawing.SystemColors.Window;
            this.threes.Location = new System.Drawing.Point(1199, 78);
            this.threes.Name = "threes";
            this.threes.Size = new System.Drawing.Size(44, 32);
            this.threes.TabIndex = 10;
            this.threes.Text = "0";
            this.threes.UseVisualStyleBackColor = false;
            this.threes.Click += new System.EventHandler(this.threes_Click);
            // 
            // fours
            // 
            this.fours.BackColor = System.Drawing.SystemColors.Window;
            this.fours.Location = new System.Drawing.Point(1199, 108);
            this.fours.Name = "fours";
            this.fours.Size = new System.Drawing.Size(44, 32);
            this.fours.TabIndex = 11;
            this.fours.Text = "0";
            this.fours.UseVisualStyleBackColor = false;
            this.fours.Click += new System.EventHandler(this.fours_Click);
            // 
            // fives
            // 
            this.fives.BackColor = System.Drawing.SystemColors.Window;
            this.fives.Location = new System.Drawing.Point(1199, 138);
            this.fives.Name = "fives";
            this.fives.Size = new System.Drawing.Size(44, 32);
            this.fives.TabIndex = 12;
            this.fives.Text = "0";
            this.fives.UseVisualStyleBackColor = false;
            this.fives.Click += new System.EventHandler(this.fives_Click);
            // 
            // sixes
            // 
            this.sixes.BackColor = System.Drawing.SystemColors.Window;
            this.sixes.Location = new System.Drawing.Point(1199, 168);
            this.sixes.Name = "sixes";
            this.sixes.Size = new System.Drawing.Size(44, 32);
            this.sixes.TabIndex = 13;
            this.sixes.Text = "0";
            this.sixes.UseVisualStyleBackColor = false;
            this.sixes.Click += new System.EventHandler(this.sixes_Click);
            // 
            // sum
            // 
            this.sum.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.sum.Location = new System.Drawing.Point(1199, 199);
            this.sum.Name = "sum";
            this.sum.Size = new System.Drawing.Size(44, 32);
            this.sum.TabIndex = 14;
            this.sum.Text = "0";
            this.sum.UseVisualStyleBackColor = false;
            // 
            // bonus
            // 
            this.bonus.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.bonus.Location = new System.Drawing.Point(1199, 229);
            this.bonus.Name = "bonus";
            this.bonus.Size = new System.Drawing.Size(44, 32);
            this.bonus.TabIndex = 15;
            this.bonus.Text = "0";
            this.bonus.UseVisualStyleBackColor = false;
            // 
            // threeOfAKind
            // 
            this.threeOfAKind.BackColor = System.Drawing.SystemColors.Window;
            this.threeOfAKind.Location = new System.Drawing.Point(1199, 260);
            this.threeOfAKind.Name = "threeOfAKind";
            this.threeOfAKind.Size = new System.Drawing.Size(44, 32);
            this.threeOfAKind.TabIndex = 16;
            this.threeOfAKind.Text = "0";
            this.threeOfAKind.UseVisualStyleBackColor = false;
            this.threeOfAKind.Click += new System.EventHandler(this.threeOfAKind_Click);
            // 
            // fourOfAKind
            // 
            this.fourOfAKind.BackColor = System.Drawing.SystemColors.Window;
            this.fourOfAKind.Location = new System.Drawing.Point(1199, 290);
            this.fourOfAKind.Name = "fourOfAKind";
            this.fourOfAKind.Size = new System.Drawing.Size(44, 32);
            this.fourOfAKind.TabIndex = 17;
            this.fourOfAKind.Text = "0";
            this.fourOfAKind.UseVisualStyleBackColor = false;
            this.fourOfAKind.Click += new System.EventHandler(this.fourOfAKind_Click);
            // 
            // fullHouse
            // 
            this.fullHouse.BackColor = System.Drawing.SystemColors.Window;
            this.fullHouse.Location = new System.Drawing.Point(1199, 320);
            this.fullHouse.Name = "fullHouse";
            this.fullHouse.Size = new System.Drawing.Size(44, 32);
            this.fullHouse.TabIndex = 18;
            this.fullHouse.Text = "0";
            this.fullHouse.UseVisualStyleBackColor = false;
            this.fullHouse.Click += new System.EventHandler(this.fullHouse_Click);
            // 
            // smallStraight
            // 
            this.smallStraight.BackColor = System.Drawing.SystemColors.Window;
            this.smallStraight.Location = new System.Drawing.Point(1199, 350);
            this.smallStraight.Name = "smallStraight";
            this.smallStraight.Size = new System.Drawing.Size(44, 32);
            this.smallStraight.TabIndex = 19;
            this.smallStraight.Text = "0";
            this.smallStraight.UseVisualStyleBackColor = false;
            this.smallStraight.Click += new System.EventHandler(this.smallStraight_Click);
            // 
            // largeStraight
            // 
            this.largeStraight.BackColor = System.Drawing.SystemColors.Window;
            this.largeStraight.Location = new System.Drawing.Point(1199, 380);
            this.largeStraight.Name = "largeStraight";
            this.largeStraight.Size = new System.Drawing.Size(44, 32);
            this.largeStraight.TabIndex = 20;
            this.largeStraight.Text = "0";
            this.largeStraight.UseVisualStyleBackColor = false;
            this.largeStraight.Click += new System.EventHandler(this.largeStraight_Click);
            // 
            // chance
            // 
            this.chance.BackColor = System.Drawing.SystemColors.Window;
            this.chance.Location = new System.Drawing.Point(1199, 410);
            this.chance.Name = "chance";
            this.chance.Size = new System.Drawing.Size(44, 32);
            this.chance.TabIndex = 21;
            this.chance.Text = "0";
            this.chance.UseVisualStyleBackColor = false;
            this.chance.Click += new System.EventHandler(this.chance_Click);
            // 
            // yahtzee
            // 
            this.yahtzee.BackColor = System.Drawing.SystemColors.Window;
            this.yahtzee.Location = new System.Drawing.Point(1199, 440);
            this.yahtzee.Name = "yahtzee";
            this.yahtzee.Size = new System.Drawing.Size(44, 32);
            this.yahtzee.TabIndex = 22;
            this.yahtzee.Text = "0";
            this.yahtzee.UseVisualStyleBackColor = false;
            this.yahtzee.Click += new System.EventHandler(this.yahtzee_Click);
            // 
            // score
            // 
            this.score.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.score.Location = new System.Drawing.Point(1199, 471);
            this.score.Name = "score";
            this.score.Size = new System.Drawing.Size(44, 32);
            this.score.TabIndex = 23;
            this.score.Text = "0";
            this.score.UseVisualStyleBackColor = false;
            // 
            // throwsLeft
            // 
            this.throwsLeft.AutoSize = true;
            this.throwsLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.throwsLeft.Location = new System.Drawing.Point(22, 18);
            this.throwsLeft.Name = "throwsLeft";
            this.throwsLeft.Size = new System.Drawing.Size(210, 37);
            this.throwsLeft.TabIndex = 24;
            this.throwsLeft.Text = "Throws left: 3";
            // 
            // help
            // 
            this.help.Location = new System.Drawing.Point(1090, 550);
            this.help.Name = "help";
            this.help.Size = new System.Drawing.Size(153, 54);
            this.help.TabIndex = 25;
            this.help.Text = "HELP";
            this.help.UseVisualStyleBackColor = true;
            this.help.Click += new System.EventHandler(this.help_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1265, 515);
            this.panel1.TabIndex = 26;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(17, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(1227, 36);
            this.label3.TabIndex = 2;
            this.label3.Text = resources.GetString("label3.Text");
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(1244, 54);
            this.label2.TabIndex = 1;
            this.label2.Text = resources.GetString("label2.Text");
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "HELP";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(17, 190);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(1149, 252);
            this.label4.TabIndex = 3;
            this.label4.Text = resources.GetString("label4.Text");
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.help);
            this.Controls.Add(this.throwsLeft);
            this.Controls.Add(this.score);
            this.Controls.Add(this.yahtzee);
            this.Controls.Add(this.chance);
            this.Controls.Add(this.largeStraight);
            this.Controls.Add(this.smallStraight);
            this.Controls.Add(this.fullHouse);
            this.Controls.Add(this.fourOfAKind);
            this.Controls.Add(this.threeOfAKind);
            this.Controls.Add(this.bonus);
            this.Controls.Add(this.sum);
            this.Controls.Add(this.sixes);
            this.Controls.Add(this.fives);
            this.Controls.Add(this.fours);
            this.Controls.Add(this.threes);
            this.Controls.Add(this.twos);
            this.Controls.Add(this.ones);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dice5);
            this.Controls.Add(this.dice4);
            this.Controls.Add(this.dice3);
            this.Controls.Add(this.dice2);
            this.Controls.Add(this.rollDice);
            this.Controls.Add(this.dice1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button dice1;
        private System.Windows.Forms.Button rollDice;
        private System.Windows.Forms.Button dice2;
        private System.Windows.Forms.Button dice3;
        private System.Windows.Forms.Button dice4;
        private System.Windows.Forms.Button dice5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button ones;
        private System.Windows.Forms.Button twos;
        private System.Windows.Forms.Button threes;
        private System.Windows.Forms.Button fours;
        private System.Windows.Forms.Button fives;
        private System.Windows.Forms.Button sixes;
        private System.Windows.Forms.Button sum;
        private System.Windows.Forms.Button bonus;
        private System.Windows.Forms.Button threeOfAKind;
        private System.Windows.Forms.Button fourOfAKind;
        private System.Windows.Forms.Button fullHouse;
        private System.Windows.Forms.Button smallStraight;
        private System.Windows.Forms.Button largeStraight;
        private System.Windows.Forms.Button chance;
        private System.Windows.Forms.Button yahtzee;
        private System.Windows.Forms.Button score;
        private System.Windows.Forms.Label throwsLeft;
        private System.Windows.Forms.Button help;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
    }
}


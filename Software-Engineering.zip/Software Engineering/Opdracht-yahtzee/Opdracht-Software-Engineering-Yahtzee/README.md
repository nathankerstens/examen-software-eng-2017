# Opdracht-Software-Engineering-Yahtzee
Groep, Tom Verschueren, Lode Diels, Hendrik van Dijck

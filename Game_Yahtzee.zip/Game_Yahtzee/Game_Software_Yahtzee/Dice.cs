﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game_Software_Yahtzee
{
    class Dice
    {
        bool LockedDice = false;
        int DiceNumber = 0;

        

        public int RollDice(Random rndNumber)
        {
            if (!LockedDice)
            {
                DiceNumber = rndNumber.Next(1, 7);
            }
            
            
            return DiceNumber;
        }

        public void DiceLock()
        {
            LockedDice = true;
        }

        public void DiceUnlock()
        {
            LockedDice = false;
        }

        public void mDiceReset()
        {
            LockedDice = false;
            DiceNumber = 0;
        }

    }
    
}

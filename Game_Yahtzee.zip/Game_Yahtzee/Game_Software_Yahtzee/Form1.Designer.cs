﻿namespace Game_Software_Yahtzee
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lblPlayer = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnChance = new System.Windows.Forms.Button();
            this.lblLowertotal2 = new System.Windows.Forms.Label();
            this.lblYahtzeebonus = new System.Windows.Forms.Label();
            this.lblLowertotal1 = new System.Windows.Forms.Label();
            this.btnYahtzee = new System.Windows.Forms.Button();
            this.BtnLargeStraight = new System.Windows.Forms.Button();
            this.BtnSmallStraight = new System.Windows.Forms.Button();
            this.BtnFullHouse = new System.Windows.Forms.Button();
            this.BtnFourOfAKind = new System.Windows.Forms.Button();
            this.BtnThreeOfAKind = new System.Windows.Forms.Button();
            this.Lowersection = new System.Windows.Forms.Label();
            this.uppertotal2 = new System.Windows.Forms.Label();
            this.upperbonus = new System.Windows.Forms.Label();
            this.Uppertotal1 = new System.Windows.Forms.Label();
            this.BtnSix = new System.Windows.Forms.Button();
            this.BtnFives = new System.Windows.Forms.Button();
            this.BtnFours = new System.Windows.Forms.Button();
            this.BtnThrees = new System.Windows.Forms.Button();
            this.BtnTwos = new System.Windows.Forms.Button();
            this.BtnOnes = new System.Windows.Forms.Button();
            this.uppersection = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Roll = new System.Windows.Forms.Button();
            this.Lock5 = new System.Windows.Forms.Button();
            this.Lock4 = new System.Windows.Forms.Button();
            this.Lock3 = new System.Windows.Forms.Button();
            this.Lock2 = new System.Windows.Forms.Button();
            this.Lock1 = new System.Windows.Forms.Button();
            this.PB5 = new System.Windows.Forms.PictureBox();
            this.PB4 = new System.Windows.Forms.PictureBox();
            this.PB3 = new System.Windows.Forms.PictureBox();
            this.PB2 = new System.Windows.Forms.PictureBox();
            this.PB1 = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.PB5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblPlayer
            // 
            this.lblPlayer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblPlayer.Location = new System.Drawing.Point(73, 47);
            this.lblPlayer.Name = "lblPlayer";
            this.lblPlayer.Size = new System.Drawing.Size(129, 25);
            this.lblPlayer.TabIndex = 133;
            this.lblPlayer.Text = "PLAYER:";
            this.lblPlayer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label23.Location = new System.Drawing.Point(1149, 686);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(121, 20);
            this.label23.TabIndex = 132;
            this.label23.Text = "0";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label22.Image = ((System.Drawing.Image)(resources.GetObject("label22.Image")));
            this.label22.Location = new System.Drawing.Point(723, 684);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(413, 22);
            this.label22.TabIndex = 131;
            this.label22.Text = "TOTAL";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label19.Location = new System.Drawing.Point(1149, 604);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(121, 20);
            this.label19.TabIndex = 130;
            this.label19.Text = "0";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // label20
            // 
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label20.Location = new System.Drawing.Point(1149, 580);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(121, 20);
            this.label20.TabIndex = 129;
            this.label20.Text = "0";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // label21
            // 
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label21.Location = new System.Drawing.Point(1149, 556);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(121, 20);
            this.label21.TabIndex = 128;
            this.label21.Text = "0";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // label18
            // 
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label18.Location = new System.Drawing.Point(1149, 527);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(121, 20);
            this.label18.TabIndex = 127;
            this.label18.Text = "0";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label12.Location = new System.Drawing.Point(1149, 505);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(121, 20);
            this.label12.TabIndex = 126;
            this.label12.Text = "0";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label13.Location = new System.Drawing.Point(1149, 482);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(121, 20);
            this.label13.TabIndex = 125;
            this.label13.Text = "0";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label14.Location = new System.Drawing.Point(1149, 459);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(121, 20);
            this.label14.TabIndex = 124;
            this.label14.Text = "0";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label15.Location = new System.Drawing.Point(1149, 436);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(121, 20);
            this.label15.TabIndex = 123;
            this.label15.Text = "0";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label16.Location = new System.Drawing.Point(1149, 411);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(121, 22);
            this.label16.TabIndex = 122;
            this.label16.Text = "0";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label17.Location = new System.Drawing.Point(1149, 386);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(121, 22);
            this.label17.TabIndex = 121;
            this.label17.Text = "0";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label11.Location = new System.Drawing.Point(1149, 306);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(121, 20);
            this.label11.TabIndex = 120;
            this.label11.Text = "0";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label10.Location = new System.Drawing.Point(1149, 282);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(121, 20);
            this.label10.TabIndex = 119;
            this.label10.Text = "0";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label9.Location = new System.Drawing.Point(1149, 258);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(121, 20);
            this.label9.TabIndex = 118;
            this.label9.Text = "0";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label8.Location = new System.Drawing.Point(1149, 229);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(121, 20);
            this.label8.TabIndex = 117;
            this.label8.Text = "0";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label7.Location = new System.Drawing.Point(1149, 206);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(121, 20);
            this.label7.TabIndex = 116;
            this.label7.Text = "0";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label6.Location = new System.Drawing.Point(1149, 183);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(121, 20);
            this.label6.TabIndex = 115;
            this.label6.Text = "0";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label5.Location = new System.Drawing.Point(1149, 160);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(121, 20);
            this.label5.TabIndex = 114;
            this.label5.Text = "0";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label4.Location = new System.Drawing.Point(1149, 135);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(121, 22);
            this.label4.TabIndex = 113;
            this.label4.Text = "0";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label3.Location = new System.Drawing.Point(1149, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 22);
            this.label3.TabIndex = 112;
            this.label3.Text = "0";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Image = ((System.Drawing.Image)(resources.GetObject("label2.Image")));
            this.label2.Location = new System.Drawing.Point(701, 645);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(587, 26);
            this.label2.TabIndex = 111;
            this.label2.Text = "GRAND TOTAL";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnChance
            // 
            this.btnChance.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.btnChance.Location = new System.Drawing.Point(720, 523);
            this.btnChance.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnChance.Name = "btnChance";
            this.btnChance.Size = new System.Drawing.Size(415, 25);
            this.btnChance.TabIndex = 110;
            this.btnChance.Text = "CHANCE";
            this.btnChance.UseVisualStyleBackColor = true;
            this.btnChance.Click += new System.EventHandler(this.btnChance_Click);
            // 
            // lblLowertotal2
            // 
            this.lblLowertotal2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblLowertotal2.Image = ((System.Drawing.Image)(resources.GetObject("lblLowertotal2.Image")));
            this.lblLowertotal2.Location = new System.Drawing.Point(721, 604);
            this.lblLowertotal2.Name = "lblLowertotal2";
            this.lblLowertotal2.Size = new System.Drawing.Size(413, 22);
            this.lblLowertotal2.TabIndex = 109;
            this.lblLowertotal2.Text = "LOWER TOTAL 2";
            this.lblLowertotal2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblYahtzeebonus
            // 
            this.lblYahtzeebonus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblYahtzeebonus.Image = ((System.Drawing.Image)(resources.GetObject("lblYahtzeebonus.Image")));
            this.lblYahtzeebonus.Location = new System.Drawing.Point(721, 580);
            this.lblYahtzeebonus.Name = "lblYahtzeebonus";
            this.lblYahtzeebonus.Size = new System.Drawing.Size(413, 22);
            this.lblYahtzeebonus.TabIndex = 108;
            this.lblYahtzeebonus.Text = "YAHTZEE BONUS ";
            this.lblYahtzeebonus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLowertotal1
            // 
            this.lblLowertotal1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblLowertotal1.Image = ((System.Drawing.Image)(resources.GetObject("lblLowertotal1.Image")));
            this.lblLowertotal1.Location = new System.Drawing.Point(721, 556);
            this.lblLowertotal1.Name = "lblLowertotal1";
            this.lblLowertotal1.Size = new System.Drawing.Size(413, 22);
            this.lblLowertotal1.TabIndex = 107;
            this.lblLowertotal1.Text = "LOWER TOTAL 1";
            this.lblLowertotal1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnYahtzee
            // 
            this.btnYahtzee.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.btnYahtzee.Location = new System.Drawing.Point(720, 500);
            this.btnYahtzee.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnYahtzee.Name = "btnYahtzee";
            this.btnYahtzee.Size = new System.Drawing.Size(415, 25);
            this.btnYahtzee.TabIndex = 106;
            this.btnYahtzee.Text = "YAHTZEE";
            this.btnYahtzee.UseVisualStyleBackColor = true;
            this.btnYahtzee.Click += new System.EventHandler(this.btnYahtzee_Click);
            // 
            // BtnLargeStraight
            // 
            this.BtnLargeStraight.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.BtnLargeStraight.Location = new System.Drawing.Point(720, 478);
            this.BtnLargeStraight.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnLargeStraight.Name = "BtnLargeStraight";
            this.BtnLargeStraight.Size = new System.Drawing.Size(415, 25);
            this.BtnLargeStraight.TabIndex = 105;
            this.BtnLargeStraight.Text = "LARGE STRAIGHT";
            this.BtnLargeStraight.UseVisualStyleBackColor = true;
            this.BtnLargeStraight.Click += new System.EventHandler(this.BtnLargeStraight_Click);
            // 
            // BtnSmallStraight
            // 
            this.BtnSmallStraight.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.BtnSmallStraight.Location = new System.Drawing.Point(720, 455);
            this.BtnSmallStraight.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnSmallStraight.Name = "BtnSmallStraight";
            this.BtnSmallStraight.Size = new System.Drawing.Size(415, 25);
            this.BtnSmallStraight.TabIndex = 104;
            this.BtnSmallStraight.Text = "SMALL STRAIGHT";
            this.BtnSmallStraight.UseVisualStyleBackColor = true;
            this.BtnSmallStraight.Click += new System.EventHandler(this.BtnSmallStraight_Click);
            // 
            // BtnFullHouse
            // 
            this.BtnFullHouse.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.BtnFullHouse.Location = new System.Drawing.Point(720, 432);
            this.BtnFullHouse.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnFullHouse.Name = "BtnFullHouse";
            this.BtnFullHouse.Size = new System.Drawing.Size(415, 25);
            this.BtnFullHouse.TabIndex = 103;
            this.BtnFullHouse.Text = "FULL HOUSE";
            this.BtnFullHouse.UseVisualStyleBackColor = true;
            this.BtnFullHouse.Click += new System.EventHandler(this.BtnFullHouse_Click);
            // 
            // BtnFourOfAKind
            // 
            this.BtnFourOfAKind.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.BtnFourOfAKind.Location = new System.Drawing.Point(720, 409);
            this.BtnFourOfAKind.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnFourOfAKind.Name = "BtnFourOfAKind";
            this.BtnFourOfAKind.Size = new System.Drawing.Size(415, 25);
            this.BtnFourOfAKind.TabIndex = 102;
            this.BtnFourOfAKind.Text = "FOUR OF A KIND";
            this.BtnFourOfAKind.UseVisualStyleBackColor = true;
            this.BtnFourOfAKind.Click += new System.EventHandler(this.BtnFourOfAKind_Click);
            // 
            // BtnThreeOfAKind
            // 
            this.BtnThreeOfAKind.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.BtnThreeOfAKind.Location = new System.Drawing.Point(720, 386);
            this.BtnThreeOfAKind.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnThreeOfAKind.Name = "BtnThreeOfAKind";
            this.BtnThreeOfAKind.Size = new System.Drawing.Size(415, 25);
            this.BtnThreeOfAKind.TabIndex = 101;
            this.BtnThreeOfAKind.Text = "THREE OF A KIND";
            this.BtnThreeOfAKind.UseVisualStyleBackColor = true;
            this.BtnThreeOfAKind.Click += new System.EventHandler(this.BtnThreeOfAKind_Click);
            // 
            // Lowersection
            // 
            this.Lowersection.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.Lowersection.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Lowersection.Image = ((System.Drawing.Image)(resources.GetObject("Lowersection.Image")));
            this.Lowersection.Location = new System.Drawing.Point(701, 347);
            this.Lowersection.Name = "Lowersection";
            this.Lowersection.Size = new System.Drawing.Size(587, 26);
            this.Lowersection.TabIndex = 100;
            this.Lowersection.Text = "LOWER SECTION";
            this.Lowersection.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uppertotal2
            // 
            this.uppertotal2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.uppertotal2.Image = ((System.Drawing.Image)(resources.GetObject("uppertotal2.Image")));
            this.uppertotal2.Location = new System.Drawing.Point(721, 304);
            this.uppertotal2.Name = "uppertotal2";
            this.uppertotal2.Size = new System.Drawing.Size(413, 22);
            this.uppertotal2.TabIndex = 99;
            this.uppertotal2.Text = "UPPER TOTAL 2";
            this.uppertotal2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // upperbonus
            // 
            this.upperbonus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.upperbonus.Image = ((System.Drawing.Image)(resources.GetObject("upperbonus.Image")));
            this.upperbonus.Location = new System.Drawing.Point(721, 281);
            this.upperbonus.Name = "upperbonus";
            this.upperbonus.Size = new System.Drawing.Size(413, 22);
            this.upperbonus.TabIndex = 98;
            this.upperbonus.Text = "UPPER BONUS (total =<63)";
            this.upperbonus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Uppertotal1
            // 
            this.Uppertotal1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.Uppertotal1.Image = ((System.Drawing.Image)(resources.GetObject("Uppertotal1.Image")));
            this.Uppertotal1.Location = new System.Drawing.Point(721, 256);
            this.Uppertotal1.Name = "Uppertotal1";
            this.Uppertotal1.Size = new System.Drawing.Size(413, 22);
            this.Uppertotal1.TabIndex = 97;
            this.Uppertotal1.Text = "UPPER TOTAL 1";
            this.Uppertotal1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BtnSix
            // 
            this.BtnSix.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.BtnSix.Location = new System.Drawing.Point(720, 224);
            this.BtnSix.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnSix.Name = "BtnSix";
            this.BtnSix.Size = new System.Drawing.Size(415, 25);
            this.BtnSix.TabIndex = 96;
            this.BtnSix.Text = "SIX";
            this.BtnSix.UseVisualStyleBackColor = true;
            this.BtnSix.Click += new System.EventHandler(this.BtnSix_Click);
            // 
            // BtnFives
            // 
            this.BtnFives.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.BtnFives.Location = new System.Drawing.Point(720, 202);
            this.BtnFives.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnFives.Name = "BtnFives";
            this.BtnFives.Size = new System.Drawing.Size(415, 25);
            this.BtnFives.TabIndex = 95;
            this.BtnFives.Text = "FIVES";
            this.BtnFives.UseVisualStyleBackColor = true;
            this.BtnFives.Click += new System.EventHandler(this.BtnFives_Click);
            // 
            // BtnFours
            // 
            this.BtnFours.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.BtnFours.Location = new System.Drawing.Point(720, 178);
            this.BtnFours.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnFours.Name = "BtnFours";
            this.BtnFours.Size = new System.Drawing.Size(415, 25);
            this.BtnFours.TabIndex = 94;
            this.BtnFours.Text = "FOURS";
            this.BtnFours.UseVisualStyleBackColor = true;
            this.BtnFours.Click += new System.EventHandler(this.BtnFours_Click);
            // 
            // BtnThrees
            // 
            this.BtnThrees.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.BtnThrees.Location = new System.Drawing.Point(720, 156);
            this.BtnThrees.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnThrees.Name = "BtnThrees";
            this.BtnThrees.Size = new System.Drawing.Size(415, 25);
            this.BtnThrees.TabIndex = 93;
            this.BtnThrees.Text = "THREES";
            this.BtnThrees.UseVisualStyleBackColor = true;
            this.BtnThrees.Click += new System.EventHandler(this.BtnThrees_Click);
            // 
            // BtnTwos
            // 
            this.BtnTwos.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.BtnTwos.Location = new System.Drawing.Point(720, 133);
            this.BtnTwos.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnTwos.Name = "BtnTwos";
            this.BtnTwos.Size = new System.Drawing.Size(415, 25);
            this.BtnTwos.TabIndex = 92;
            this.BtnTwos.Text = "TWOS";
            this.BtnTwos.UseVisualStyleBackColor = true;
            this.BtnTwos.Click += new System.EventHandler(this.BtnTwos_Click);
            // 
            // BtnOnes
            // 
            this.BtnOnes.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.BtnOnes.Location = new System.Drawing.Point(720, 110);
            this.BtnOnes.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnOnes.Name = "BtnOnes";
            this.BtnOnes.Size = new System.Drawing.Size(415, 25);
            this.BtnOnes.TabIndex = 91;
            this.BtnOnes.Text = "ONES";
            this.BtnOnes.UseVisualStyleBackColor = true;
            this.BtnOnes.Click += new System.EventHandler(this.BtnOnes_Click);
            // 
            // uppersection
            // 
            this.uppersection.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.uppersection.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.uppersection.Image = ((System.Drawing.Image)(resources.GetObject("uppersection.Image")));
            this.uppersection.Location = new System.Drawing.Point(701, 71);
            this.uppersection.Name = "uppersection";
            this.uppersection.Size = new System.Drawing.Size(587, 26);
            this.uppersection.TabIndex = 90;
            this.uppersection.Text = "UPPER SECTION";
            this.uppersection.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
            this.label1.Location = new System.Drawing.Point(701, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(587, 30);
            this.label1.TabIndex = 89;
            this.label1.Text = "YAHTZEE";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Roll
            // 
            this.Roll.Font = new System.Drawing.Font("Microsoft Sans Serif", 27F);
            this.Roll.Location = new System.Drawing.Point(226, 500);
            this.Roll.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Roll.Name = "Roll";
            this.Roll.Size = new System.Drawing.Size(219, 68);
            this.Roll.TabIndex = 88;
            this.Roll.Text = "ROLL";
            this.Roll.UseVisualStyleBackColor = true;
            this.Roll.Click += new System.EventHandler(this.Roll_Click);
            // 
            // Lock5
            // 
            this.Lock5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Lock5.Location = new System.Drawing.Point(363, 436);
            this.Lock5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Lock5.Name = "Lock5";
            this.Lock5.Size = new System.Drawing.Size(107, 30);
            this.Lock5.TabIndex = 87;
            this.Lock5.Text = "LOCK";
            this.Lock5.UseVisualStyleBackColor = true;
            this.Lock5.Click += new System.EventHandler(this.Lock5_Click);
            // 
            // Lock4
            // 
            this.Lock4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Lock4.Location = new System.Drawing.Point(192, 439);
            this.Lock4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Lock4.Name = "Lock4";
            this.Lock4.Size = new System.Drawing.Size(107, 30);
            this.Lock4.TabIndex = 86;
            this.Lock4.Text = "LOCK";
            this.Lock4.UseVisualStyleBackColor = true;
            this.Lock4.Click += new System.EventHandler(this.Lock4_Click);
            // 
            // Lock3
            // 
            this.Lock3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Lock3.Location = new System.Drawing.Point(456, 245);
            this.Lock3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Lock3.Name = "Lock3";
            this.Lock3.Size = new System.Drawing.Size(107, 30);
            this.Lock3.TabIndex = 85;
            this.Lock3.Text = "LOCK";
            this.Lock3.UseVisualStyleBackColor = true;
            this.Lock3.Click += new System.EventHandler(this.Lock3_Click);
            // 
            // Lock2
            // 
            this.Lock2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Lock2.Location = new System.Drawing.Point(276, 245);
            this.Lock2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Lock2.Name = "Lock2";
            this.Lock2.Size = new System.Drawing.Size(107, 30);
            this.Lock2.TabIndex = 84;
            this.Lock2.Text = "LOCK";
            this.Lock2.UseVisualStyleBackColor = true;
            this.Lock2.Click += new System.EventHandler(this.Lock2_Click);
            // 
            // Lock1
            // 
            this.Lock1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Lock1.Location = new System.Drawing.Point(95, 245);
            this.Lock1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Lock1.Name = "Lock1";
            this.Lock1.Size = new System.Drawing.Size(107, 30);
            this.Lock1.TabIndex = 83;
            this.Lock1.Text = "LOCK";
            this.Lock1.UseVisualStyleBackColor = true;
            this.Lock1.Click += new System.EventHandler(this.Lock1_Click);
            // 
            // PB5
            // 
            this.PB5.Location = new System.Drawing.Point(350, 293);
            this.PB5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PB5.Name = "PB5";
            this.PB5.Size = new System.Drawing.Size(140, 140);
            this.PB5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB5.TabIndex = 82;
            this.PB5.TabStop = false;
            // 
            // PB4
            // 
            this.PB4.Location = new System.Drawing.Point(171, 293);
            this.PB4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PB4.Name = "PB4";
            this.PB4.Size = new System.Drawing.Size(140, 140);
            this.PB4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB4.TabIndex = 81;
            this.PB4.TabStop = false;
            // 
            // PB3
            // 
            this.PB3.Location = new System.Drawing.Point(441, 99);
            this.PB3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PB3.Name = "PB3";
            this.PB3.Size = new System.Drawing.Size(140, 140);
            this.PB3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB3.TabIndex = 80;
            this.PB3.TabStop = false;
            this.PB3.Click += new System.EventHandler(this.PB3_Click);
            // 
            // PB2
            // 
            this.PB2.Location = new System.Drawing.Point(260, 99);
            this.PB2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PB2.Name = "PB2";
            this.PB2.Size = new System.Drawing.Size(140, 140);
            this.PB2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB2.TabIndex = 79;
            this.PB2.TabStop = false;
            // 
            // PB1
            // 
            this.PB1.Location = new System.Drawing.Point(77, 99);
            this.PB1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PB1.Name = "PB1";
            this.PB1.Size = new System.Drawing.Size(140, 140);
            this.PB1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB1.TabIndex = 78;
            this.PB1.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.Control;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(196, 47);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(204, 25);
            this.textBox1.TabIndex = 134;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label24
            // 
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label24.Image = ((System.Drawing.Image)(resources.GetObject("label24.Image")));
            this.label24.Location = new System.Drawing.Point(90, 604);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(491, 102);
            this.label24.TabIndex = 135;
            this.label24.Text = "SPELREGELS";
            // 
            // label25
            // 
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label25.Image = ((System.Drawing.Image)(resources.GetObject("label25.Image")));
            this.label25.Location = new System.Drawing.Point(90, 628);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(491, 78);
            this.label25.TabIndex = 136;
            this.label25.Text = resources.GetString("label25.Text");
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1361, 726);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblPlayer);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnChance);
            this.Controls.Add(this.lblLowertotal2);
            this.Controls.Add(this.lblYahtzeebonus);
            this.Controls.Add(this.lblLowertotal1);
            this.Controls.Add(this.btnYahtzee);
            this.Controls.Add(this.BtnLargeStraight);
            this.Controls.Add(this.BtnSmallStraight);
            this.Controls.Add(this.BtnFullHouse);
            this.Controls.Add(this.BtnFourOfAKind);
            this.Controls.Add(this.BtnThreeOfAKind);
            this.Controls.Add(this.Lowersection);
            this.Controls.Add(this.uppertotal2);
            this.Controls.Add(this.upperbonus);
            this.Controls.Add(this.Uppertotal1);
            this.Controls.Add(this.BtnSix);
            this.Controls.Add(this.BtnFives);
            this.Controls.Add(this.BtnFours);
            this.Controls.Add(this.BtnThrees);
            this.Controls.Add(this.BtnTwos);
            this.Controls.Add(this.BtnOnes);
            this.Controls.Add(this.uppersection);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Roll);
            this.Controls.Add(this.Lock5);
            this.Controls.Add(this.Lock4);
            this.Controls.Add(this.Lock3);
            this.Controls.Add(this.Lock2);
            this.Controls.Add(this.Lock1);
            this.Controls.Add(this.PB5);
            this.Controls.Add(this.PB4);
            this.Controls.Add(this.PB3);
            this.Controls.Add(this.PB2);
            this.Controls.Add(this.PB1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PB5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblPlayer;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnChance;
        private System.Windows.Forms.Label lblLowertotal2;
        private System.Windows.Forms.Label lblYahtzeebonus;
        private System.Windows.Forms.Label lblLowertotal1;
        private System.Windows.Forms.Button btnYahtzee;
        private System.Windows.Forms.Button BtnLargeStraight;
        private System.Windows.Forms.Button BtnSmallStraight;
        private System.Windows.Forms.Button BtnFullHouse;
        private System.Windows.Forms.Button BtnFourOfAKind;
        private System.Windows.Forms.Button BtnThreeOfAKind;
        private System.Windows.Forms.Label Lowersection;
        private System.Windows.Forms.Label uppertotal2;
        private System.Windows.Forms.Label upperbonus;
        private System.Windows.Forms.Label Uppertotal1;
        private System.Windows.Forms.Button BtnSix;
        private System.Windows.Forms.Button BtnFives;
        private System.Windows.Forms.Button BtnFours;
        private System.Windows.Forms.Button BtnThrees;
        private System.Windows.Forms.Button BtnTwos;
        private System.Windows.Forms.Button BtnOnes;
        private System.Windows.Forms.Label uppersection;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Roll;
        private System.Windows.Forms.Button Lock5;
        private System.Windows.Forms.Button Lock4;
        private System.Windows.Forms.Button Lock3;
        private System.Windows.Forms.Button Lock2;
        private System.Windows.Forms.Button Lock1;
        private System.Windows.Forms.PictureBox PB5;
        private System.Windows.Forms.PictureBox PB4;
        private System.Windows.Forms.PictureBox PB3;
        private System.Windows.Forms.PictureBox PB2;
        private System.Windows.Forms.PictureBox PB1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
    }

    partial class MethodesForm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MethodesForm1));
            this.lblPlayer = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnChance = new System.Windows.Forms.Button();
            this.lblLowertotal2 = new System.Windows.Forms.Label();
            this.lblYahtzeebonus = new System.Windows.Forms.Label();
            this.lblLowertotal1 = new System.Windows.Forms.Label();
            this.btnYahtzee = new System.Windows.Forms.Button();
            this.BtnLargeStraight = new System.Windows.Forms.Button();
            this.BtnSmallStraight = new System.Windows.Forms.Button();
            this.BtnFullHouse = new System.Windows.Forms.Button();
            this.BtnFourOfAKind = new System.Windows.Forms.Button();
            this.BtnThreeOfAKind = new System.Windows.Forms.Button();
            this.Lowersection = new System.Windows.Forms.Label();
            this.uppertotal2 = new System.Windows.Forms.Label();
            this.upperbonus = new System.Windows.Forms.Label();
            this.Uppertotal1 = new System.Windows.Forms.Label();
            this.BtnSix = new System.Windows.Forms.Button();
            this.BtnFives = new System.Windows.Forms.Button();
            this.BtnFours = new System.Windows.Forms.Button();
            this.BtnThrees = new System.Windows.Forms.Button();
            this.BtnTwos = new System.Windows.Forms.Button();
            this.BtnOnes = new System.Windows.Forms.Button();
            this.uppersection = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Roll = new System.Windows.Forms.Button();
            this.Lock5 = new System.Windows.Forms.Button();
            this.Lock4 = new System.Windows.Forms.Button();
            this.Lock3 = new System.Windows.Forms.Button();
            this.Lock2 = new System.Windows.Forms.Button();
            this.Lock1 = new System.Windows.Forms.Button();
            this.PB5 = new System.Windows.Forms.PictureBox();
            this.PB4 = new System.Windows.Forms.PictureBox();
            this.PB3 = new System.Windows.Forms.PictureBox();
            this.PB2 = new System.Windows.Forms.PictureBox();
            this.PB1 = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.PB5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblPlayer
            // 
            this.lblPlayer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblPlayer.Location = new System.Drawing.Point(73, 47);
            this.lblPlayer.Name = "lblPlayer";
            this.lblPlayer.Size = new System.Drawing.Size(129, 25);
            this.lblPlayer.TabIndex = 133;
            this.lblPlayer.Text = "PLAYER:";
            this.lblPlayer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label23.Location = new System.Drawing.Point(1149, 686);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(121, 20);
            this.label23.TabIndex = 132;
            this.label23.Text = "0";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label22.Image = ((System.Drawing.Image)(resources.GetObject("label22.Image")));
            this.label22.Location = new System.Drawing.Point(723, 684);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(413, 22);
            this.label22.TabIndex = 131;
            this.label22.Text = "TOTAL";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label19.Location = new System.Drawing.Point(1149, 604);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(121, 20);
            this.label19.TabIndex = 130;
            this.label19.Text = "0";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // label20
            // 
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label20.Location = new System.Drawing.Point(1149, 580);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(121, 20);
            this.label20.TabIndex = 129;
            this.label20.Text = "0";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // label21
            // 
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label21.Location = new System.Drawing.Point(1149, 556);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(121, 20);
            this.label21.TabIndex = 128;
            this.label21.Text = "0";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // label18
            // 
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label18.Location = new System.Drawing.Point(1149, 527);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(121, 20);
            this.label18.TabIndex = 127;
            this.label18.Text = "0";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label12.Location = new System.Drawing.Point(1149, 505);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(121, 20);
            this.label12.TabIndex = 126;
            this.label12.Text = "0";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label13.Location = new System.Drawing.Point(1149, 482);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(121, 20);
            this.label13.TabIndex = 125;
            this.label13.Text = "0";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label14.Location = new System.Drawing.Point(1149, 459);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(121, 20);
            this.label14.TabIndex = 124;
            this.label14.Text = "0";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label15.Location = new System.Drawing.Point(1149, 436);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(121, 20);
            this.label15.TabIndex = 123;
            this.label15.Text = "0";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label16.Location = new System.Drawing.Point(1149, 411);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(121, 22);
            this.label16.TabIndex = 122;
            this.label16.Text = "0";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label17.Location = new System.Drawing.Point(1149, 386);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(121, 22);
            this.label17.TabIndex = 121;
            this.label17.Text = "0";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label11.Location = new System.Drawing.Point(1149, 306);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(121, 20);
            this.label11.TabIndex = 120;
            this.label11.Text = "0";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label10.Location = new System.Drawing.Point(1149, 282);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(121, 20);
            this.label10.TabIndex = 119;
            this.label10.Text = "0";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label9.Location = new System.Drawing.Point(1149, 258);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(121, 20);
            this.label9.TabIndex = 118;
            this.label9.Text = "0";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label8.Location = new System.Drawing.Point(1149, 229);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(121, 20);
            this.label8.TabIndex = 117;
            this.label8.Text = "0";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label7.Location = new System.Drawing.Point(1149, 206);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(121, 20);
            this.label7.TabIndex = 116;
            this.label7.Text = "0";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label6.Location = new System.Drawing.Point(1149, 183);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(121, 20);
            this.label6.TabIndex = 115;
            this.label6.Text = "0";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label5.Location = new System.Drawing.Point(1149, 160);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(121, 20);
            this.label5.TabIndex = 114;
            this.label5.Text = "0";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label4.Location = new System.Drawing.Point(1149, 135);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(121, 22);
            this.label4.TabIndex = 113;
            this.label4.Text = "0";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label3.Location = new System.Drawing.Point(1149, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 22);
            this.label3.TabIndex = 112;
            this.label3.Text = "0";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Image = ((System.Drawing.Image)(resources.GetObject("label2.Image")));
            this.label2.Location = new System.Drawing.Point(701, 645);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(587, 26);
            this.label2.TabIndex = 111;
            this.label2.Text = "GRAND TOTAL";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnChance
            // 
            this.btnChance.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.btnChance.Location = new System.Drawing.Point(720, 523);
            this.btnChance.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnChance.Name = "btnChance";
            this.btnChance.Size = new System.Drawing.Size(415, 25);
            this.btnChance.TabIndex = 110;
            this.btnChance.Text = "CHANCE";
            this.btnChance.UseVisualStyleBackColor = true;
            this.btnChance.Click += new System.EventHandler(this.btnChance_Click);
            // 
            // lblLowertotal2
            // 
            this.lblLowertotal2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblLowertotal2.Image = ((System.Drawing.Image)(resources.GetObject("lblLowertotal2.Image")));
            this.lblLowertotal2.Location = new System.Drawing.Point(721, 604);
            this.lblLowertotal2.Name = "lblLowertotal2";
            this.lblLowertotal2.Size = new System.Drawing.Size(413, 22);
            this.lblLowertotal2.TabIndex = 109;
            this.lblLowertotal2.Text = "LOWER TOTAL 2";
            this.lblLowertotal2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblYahtzeebonus
            // 
            this.lblYahtzeebonus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblYahtzeebonus.Image = ((System.Drawing.Image)(resources.GetObject("lblYahtzeebonus.Image")));
            this.lblYahtzeebonus.Location = new System.Drawing.Point(721, 580);
            this.lblYahtzeebonus.Name = "lblYahtzeebonus";
            this.lblYahtzeebonus.Size = new System.Drawing.Size(413, 22);
            this.lblYahtzeebonus.TabIndex = 108;
            this.lblYahtzeebonus.Text = "YAHTZEE BONUS ";
            this.lblYahtzeebonus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLowertotal1
            // 
            this.lblLowertotal1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblLowertotal1.Image = ((System.Drawing.Image)(resources.GetObject("lblLowertotal1.Image")));
            this.lblLowertotal1.Location = new System.Drawing.Point(721, 556);
            this.lblLowertotal1.Name = "lblLowertotal1";
            this.lblLowertotal1.Size = new System.Drawing.Size(413, 22);
            this.lblLowertotal1.TabIndex = 107;
            this.lblLowertotal1.Text = "LOWER TOTAL 1";
            this.lblLowertotal1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnYahtzee
            // 
            this.btnYahtzee.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.btnYahtzee.Location = new System.Drawing.Point(720, 500);
            this.btnYahtzee.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnYahtzee.Name = "btnYahtzee";
            this.btnYahtzee.Size = new System.Drawing.Size(415, 25);
            this.btnYahtzee.TabIndex = 106;
            this.btnYahtzee.Text = "YAHTZEE";
            this.btnYahtzee.UseVisualStyleBackColor = true;
            this.btnYahtzee.Click += new System.EventHandler(this.btnYahtzee_Click);
            // 
            // BtnLargeStraight
            // 
            this.BtnLargeStraight.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.BtnLargeStraight.Location = new System.Drawing.Point(720, 478);
            this.BtnLargeStraight.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnLargeStraight.Name = "BtnLargeStraight";
            this.BtnLargeStraight.Size = new System.Drawing.Size(415, 25);
            this.BtnLargeStraight.TabIndex = 105;
            this.BtnLargeStraight.Text = "LARGE STRAIGHT";
            this.BtnLargeStraight.UseVisualStyleBackColor = true;
            this.BtnLargeStraight.Click += new System.EventHandler(this.BtnLargeStraight_Click);
            // 
            // BtnSmallStraight
            // 
            this.BtnSmallStraight.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.BtnSmallStraight.Location = new System.Drawing.Point(720, 455);
            this.BtnSmallStraight.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnSmallStraight.Name = "BtnSmallStraight";
            this.BtnSmallStraight.Size = new System.Drawing.Size(415, 25);
            this.BtnSmallStraight.TabIndex = 104;
            this.BtnSmallStraight.Text = "SMALL STRAIGHT";
            this.BtnSmallStraight.UseVisualStyleBackColor = true;
            this.BtnSmallStraight.Click += new System.EventHandler(this.BtnSmallStraight_Click);
            // 
            // BtnFullHouse
            // 
            this.BtnFullHouse.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.BtnFullHouse.Location = new System.Drawing.Point(720, 432);
            this.BtnFullHouse.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnFullHouse.Name = "BtnFullHouse";
            this.BtnFullHouse.Size = new System.Drawing.Size(415, 25);
            this.BtnFullHouse.TabIndex = 103;
            this.BtnFullHouse.Text = "FULL HOUSE";
            this.BtnFullHouse.UseVisualStyleBackColor = true;
            this.BtnFullHouse.Click += new System.EventHandler(this.BtnFullHouse_Click);
            // 
            // BtnFourOfAKind
            // 
            this.BtnFourOfAKind.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.BtnFourOfAKind.Location = new System.Drawing.Point(720, 409);
            this.BtnFourOfAKind.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnFourOfAKind.Name = "BtnFourOfAKind";
            this.BtnFourOfAKind.Size = new System.Drawing.Size(415, 25);
            this.BtnFourOfAKind.TabIndex = 102;
            this.BtnFourOfAKind.Text = "FOUR OF A KIND";
            this.BtnFourOfAKind.UseVisualStyleBackColor = true;
            this.BtnFourOfAKind.Click += new System.EventHandler(this.BtnFourOfAKind_Click);
            // 
            // BtnThreeOfAKind
            // 
            this.BtnThreeOfAKind.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.BtnThreeOfAKind.Location = new System.Drawing.Point(720, 386);
            this.BtnThreeOfAKind.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnThreeOfAKind.Name = "BtnThreeOfAKind";
            this.BtnThreeOfAKind.Size = new System.Drawing.Size(415, 25);
            this.BtnThreeOfAKind.TabIndex = 101;
            this.BtnThreeOfAKind.Text = "THREE OF A KIND";
            this.BtnThreeOfAKind.UseVisualStyleBackColor = true;
            this.BtnThreeOfAKind.Click += new System.EventHandler(this.BtnThreeOfAKind_Click);
            // 
            // Lowersection
            // 
            this.Lowersection.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.Lowersection.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Lowersection.Image = ((System.Drawing.Image)(resources.GetObject("Lowersection.Image")));
            this.Lowersection.Location = new System.Drawing.Point(701, 347);
            this.Lowersection.Name = "Lowersection";
            this.Lowersection.Size = new System.Drawing.Size(587, 26);
            this.Lowersection.TabIndex = 100;
            this.Lowersection.Text = "LOWER SECTION";
            this.Lowersection.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uppertotal2
            // 
            this.uppertotal2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.uppertotal2.Image = ((System.Drawing.Image)(resources.GetObject("uppertotal2.Image")));
            this.uppertotal2.Location = new System.Drawing.Point(721, 304);
            this.uppertotal2.Name = "uppertotal2";
            this.uppertotal2.Size = new System.Drawing.Size(413, 22);
            this.uppertotal2.TabIndex = 99;
            this.uppertotal2.Text = "UPPER TOTAL 2";
            this.uppertotal2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // upperbonus
            // 
            this.upperbonus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.upperbonus.Image = ((System.Drawing.Image)(resources.GetObject("upperbonus.Image")));
            this.upperbonus.Location = new System.Drawing.Point(721, 281);
            this.upperbonus.Name = "upperbonus";
            this.upperbonus.Size = new System.Drawing.Size(413, 22);
            this.upperbonus.TabIndex = 98;
            this.upperbonus.Text = "UPPER BONUS (total =<63)";
            this.upperbonus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Uppertotal1
            // 
            this.Uppertotal1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.Uppertotal1.Image = ((System.Drawing.Image)(resources.GetObject("Uppertotal1.Image")));
            this.Uppertotal1.Location = new System.Drawing.Point(721, 256);
            this.Uppertotal1.Name = "Uppertotal1";
            this.Uppertotal1.Size = new System.Drawing.Size(413, 22);
            this.Uppertotal1.TabIndex = 97;
            this.Uppertotal1.Text = "UPPER TOTAL 1";
            this.Uppertotal1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BtnSix
            // 
            this.BtnSix.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.BtnSix.Location = new System.Drawing.Point(720, 224);
            this.BtnSix.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnSix.Name = "BtnSix";
            this.BtnSix.Size = new System.Drawing.Size(415, 25);
            this.BtnSix.TabIndex = 96;
            this.BtnSix.Text = "SIX";
            this.BtnSix.UseVisualStyleBackColor = true;
            this.BtnSix.Click += new System.EventHandler(this.BtnSix_Click);
            // 
            // BtnFives
            // 
            this.BtnFives.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.BtnFives.Location = new System.Drawing.Point(720, 202);
            this.BtnFives.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnFives.Name = "BtnFives";
            this.BtnFives.Size = new System.Drawing.Size(415, 25);
            this.BtnFives.TabIndex = 95;
            this.BtnFives.Text = "FIVES";
            this.BtnFives.UseVisualStyleBackColor = true;
            this.BtnFives.Click += new System.EventHandler(this.BtnFives_Click);
            // 
            // BtnFours
            // 
            this.BtnFours.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.BtnFours.Location = new System.Drawing.Point(720, 178);
            this.BtnFours.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnFours.Name = "BtnFours";
            this.BtnFours.Size = new System.Drawing.Size(415, 25);
            this.BtnFours.TabIndex = 94;
            this.BtnFours.Text = "FOURS";
            this.BtnFours.UseVisualStyleBackColor = true;
            this.BtnFours.Click += new System.EventHandler(this.BtnFours_Click);
            // 
            // BtnThrees
            // 
            this.BtnThrees.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.BtnThrees.Location = new System.Drawing.Point(720, 156);
            this.BtnThrees.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnThrees.Name = "BtnThrees";
            this.BtnThrees.Size = new System.Drawing.Size(415, 25);
            this.BtnThrees.TabIndex = 93;
            this.BtnThrees.Text = "THREES";
            this.BtnThrees.UseVisualStyleBackColor = true;
            this.BtnThrees.Click += new System.EventHandler(this.BtnThrees_Click);
            // 
            // BtnTwos
            // 
            this.BtnTwos.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.BtnTwos.Location = new System.Drawing.Point(720, 133);
            this.BtnTwos.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnTwos.Name = "BtnTwos";
            this.BtnTwos.Size = new System.Drawing.Size(415, 25);
            this.BtnTwos.TabIndex = 92;
            this.BtnTwos.Text = "TWOS";
            this.BtnTwos.UseVisualStyleBackColor = true;
            this.BtnTwos.Click += new System.EventHandler(this.BtnTwos_Click);
            // 
            // BtnOnes
            // 
            this.BtnOnes.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.BtnOnes.Location = new System.Drawing.Point(720, 110);
            this.BtnOnes.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnOnes.Name = "BtnOnes";
            this.BtnOnes.Size = new System.Drawing.Size(415, 25);
            this.BtnOnes.TabIndex = 91;
            this.BtnOnes.Text = "ONES";
            this.BtnOnes.UseVisualStyleBackColor = true;
            this.BtnOnes.Click += new System.EventHandler(this.BtnOnes_Click);
            // 
            // uppersection
            // 
            this.uppersection.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.uppersection.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.uppersection.Image = ((System.Drawing.Image)(resources.GetObject("uppersection.Image")));
            this.uppersection.Location = new System.Drawing.Point(701, 71);
            this.uppersection.Name = "uppersection";
            this.uppersection.Size = new System.Drawing.Size(587, 26);
            this.uppersection.TabIndex = 90;
            this.uppersection.Text = "UPPER SECTION";
            this.uppersection.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
            this.label1.Location = new System.Drawing.Point(701, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(587, 30);
            this.label1.TabIndex = 89;
            this.label1.Text = "YAHTZEE";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Roll
            // 
            this.Roll.Font = new System.Drawing.Font("Microsoft Sans Serif", 27F);
            this.Roll.Location = new System.Drawing.Point(226, 500);
            this.Roll.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Roll.Name = "Roll";
            this.Roll.Size = new System.Drawing.Size(219, 68);
            this.Roll.TabIndex = 88;
            this.Roll.Text = "ROLL";
            this.Roll.UseVisualStyleBackColor = true;
            this.Roll.Click += new System.EventHandler(this.Roll_Click);
            // 
            // Lock5
            // 
            this.Lock5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Lock5.Location = new System.Drawing.Point(363, 436);
            this.Lock5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Lock5.Name = "Lock5";
            this.Lock5.Size = new System.Drawing.Size(107, 30);
            this.Lock5.TabIndex = 87;
            this.Lock5.Text = "LOCK";
            this.Lock5.UseVisualStyleBackColor = true;
            this.Lock5.Click += new System.EventHandler(this.Lock5_Click);
            // 
            // Lock4
            // 
            this.Lock4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Lock4.Location = new System.Drawing.Point(192, 439);
            this.Lock4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Lock4.Name = "Lock4";
            this.Lock4.Size = new System.Drawing.Size(107, 30);
            this.Lock4.TabIndex = 86;
            this.Lock4.Text = "LOCK";
            this.Lock4.UseVisualStyleBackColor = true;
            this.Lock4.Click += new System.EventHandler(this.Lock4_Click);
            // 
            // Lock3
            // 
            this.Lock3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Lock3.Location = new System.Drawing.Point(456, 245);
            this.Lock3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Lock3.Name = "Lock3";
            this.Lock3.Size = new System.Drawing.Size(107, 30);
            this.Lock3.TabIndex = 85;
            this.Lock3.Text = "LOCK";
            this.Lock3.UseVisualStyleBackColor = true;
            this.Lock3.Click += new System.EventHandler(this.Lock3_Click);
            // 
            // Lock2
            // 
            this.Lock2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Lock2.Location = new System.Drawing.Point(276, 245);
            this.Lock2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Lock2.Name = "Lock2";
            this.Lock2.Size = new System.Drawing.Size(107, 30);
            this.Lock2.TabIndex = 84;
            this.Lock2.Text = "LOCK";
            this.Lock2.UseVisualStyleBackColor = true;
            this.Lock2.Click += new System.EventHandler(this.Lock2_Click);
            // 
            // Lock1
            // 
            this.Lock1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Lock1.Location = new System.Drawing.Point(95, 245);
            this.Lock1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Lock1.Name = "Lock1";
            this.Lock1.Size = new System.Drawing.Size(107, 30);
            this.Lock1.TabIndex = 83;
            this.Lock1.Text = "LOCK";
            this.Lock1.UseVisualStyleBackColor = true;
            this.Lock1.Click += new System.EventHandler(this.Lock1_Click);
            // 
            // PB5
            // 
            this.PB5.Location = new System.Drawing.Point(350, 293);
            this.PB5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PB5.Name = "PB5";
            this.PB5.Size = new System.Drawing.Size(140, 140);
            this.PB5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB5.TabIndex = 82;
            this.PB5.TabStop = false;
            // 
            // PB4
            // 
            this.PB4.Location = new System.Drawing.Point(171, 293);
            this.PB4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PB4.Name = "PB4";
            this.PB4.Size = new System.Drawing.Size(140, 140);
            this.PB4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB4.TabIndex = 81;
            this.PB4.TabStop = false;
            // 
            // PB3
            // 
            this.PB3.Location = new System.Drawing.Point(441, 99);
            this.PB3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PB3.Name = "PB3";
            this.PB3.Size = new System.Drawing.Size(140, 140);
            this.PB3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB3.TabIndex = 80;
            this.PB3.TabStop = false;
            this.PB3.Click += new System.EventHandler(this.PB3_Click);
            // 
            // PB2
            // 
            this.PB2.Location = new System.Drawing.Point(260, 99);
            this.PB2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PB2.Name = "PB2";
            this.PB2.Size = new System.Drawing.Size(140, 140);
            this.PB2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB2.TabIndex = 79;
            this.PB2.TabStop = false;
            // 
            // PB1
            // 
            this.PB1.Location = new System.Drawing.Point(77, 99);
            this.PB1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PB1.Name = "PB1";
            this.PB1.Size = new System.Drawing.Size(140, 140);
            this.PB1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB1.TabIndex = 78;
            this.PB1.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.Control;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(196, 47);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(204, 25);
            this.textBox1.TabIndex = 134;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label24
            // 
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label24.Image = ((System.Drawing.Image)(resources.GetObject("label24.Image")));
            this.label24.Location = new System.Drawing.Point(90, 604);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(491, 102);
            this.label24.TabIndex = 135;
            this.label24.Text = "SPELREGELS";
            // 
            // label25
            // 
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label25.Image = ((System.Drawing.Image)(resources.GetObject("label25.Image")));
            this.label25.Location = new System.Drawing.Point(90, 628);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(491, 78);
            this.label25.TabIndex = 136;
            this.label25.Text = resources.GetString("label25.Text");
            // 
            // CopyOfForm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1361, 726);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblPlayer);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnChance);
            this.Controls.Add(this.lblLowertotal2);
            this.Controls.Add(this.lblYahtzeebonus);
            this.Controls.Add(this.lblLowertotal1);
            this.Controls.Add(this.btnYahtzee);
            this.Controls.Add(this.BtnLargeStraight);
            this.Controls.Add(this.BtnSmallStraight);
            this.Controls.Add(this.BtnFullHouse);
            this.Controls.Add(this.BtnFourOfAKind);
            this.Controls.Add(this.BtnThreeOfAKind);
            this.Controls.Add(this.Lowersection);
            this.Controls.Add(this.uppertotal2);
            this.Controls.Add(this.upperbonus);
            this.Controls.Add(this.Uppertotal1);
            this.Controls.Add(this.BtnSix);
            this.Controls.Add(this.BtnFives);
            this.Controls.Add(this.BtnFours);
            this.Controls.Add(this.BtnThrees);
            this.Controls.Add(this.BtnTwos);
            this.Controls.Add(this.BtnOnes);
            this.Controls.Add(this.uppersection);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Roll);
            this.Controls.Add(this.Lock5);
            this.Controls.Add(this.Lock4);
            this.Controls.Add(this.Lock3);
            this.Controls.Add(this.Lock2);
            this.Controls.Add(this.Lock1);
            this.Controls.Add(this.PB5);
            this.Controls.Add(this.PB4);
            this.Controls.Add(this.PB3);
            this.Controls.Add(this.PB2);
            this.Controls.Add(this.PB1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "CopyOfForm1";
            this.Text = "CopyOfForm1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PB5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblPlayer;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnChance;
        private System.Windows.Forms.Label lblLowertotal2;
        private System.Windows.Forms.Label lblYahtzeebonus;
        private System.Windows.Forms.Label lblLowertotal1;
        private System.Windows.Forms.Button btnYahtzee;
        private System.Windows.Forms.Button BtnLargeStraight;
        private System.Windows.Forms.Button BtnSmallStraight;
        private System.Windows.Forms.Button BtnFullHouse;
        private System.Windows.Forms.Button BtnFourOfAKind;
        private System.Windows.Forms.Button BtnThreeOfAKind;
        private System.Windows.Forms.Label Lowersection;
        private System.Windows.Forms.Label uppertotal2;
        private System.Windows.Forms.Label upperbonus;
        private System.Windows.Forms.Label Uppertotal1;
        private System.Windows.Forms.Button BtnSix;
        private System.Windows.Forms.Button BtnFives;
        private System.Windows.Forms.Button BtnFours;
        private System.Windows.Forms.Button BtnThrees;
        private System.Windows.Forms.Button BtnTwos;
        private System.Windows.Forms.Button BtnOnes;
        private System.Windows.Forms.Label uppersection;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Roll;
        private System.Windows.Forms.Button Lock5;
        private System.Windows.Forms.Button Lock4;
        private System.Windows.Forms.Button Lock3;
        private System.Windows.Forms.Button Lock2;
        private System.Windows.Forms.Button Lock1;
        private System.Windows.Forms.PictureBox PB5;
        private System.Windows.Forms.PictureBox PB4;
        private System.Windows.Forms.PictureBox PB3;
        private System.Windows.Forms.PictureBox PB2;
        private System.Windows.Forms.PictureBox PB1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game_Software_Yahtzee
{
    class Game
    {
        Dice[] dobbelsteen = new Dice[5];
        int[] DiceNumbers = new int[5];

        Random RandomNbr = new Random(); 

        private int countTotalPoints = 0;
        private int countSub1 = 0;
        private int countSub2 = 0;
        private byte bonusOver63 = 35;
        private int scoreSum = 0;
        private int score1 = 0;
        private int score2 = 0;

        private bool yahtzeebool2 = false;

        private int one, two, three, four, five, six;
        private int threeOfAKind = 0, fourOfAKind = 0, chance = 0;
        private int fullHouse = 0;// 25
        private int smallStraight = 0;//30
        private int largeStraight = 0; //40
        private int yahtzee = 0; //50
        private int yahtzeecount = 0;
        private int ytzBonus = 100;

        
        public void InitDice()
        {
            for (int i = 0; i < dobbelsteen.Length; i++)
            { dobbelsteen[i] = new Dice(); }
        }

        public void Lockdice(int DiceNumber)
        {
            dobbelsteen[DiceNumber].DiceLock();
        }

        public void UnlockDice (int DiceNumber)
        {
            dobbelsteen[DiceNumber].DiceUnlock();
        }

        public int[] RollDice()
        {
            for (int i = 0; i < dobbelsteen.Length; i++)
            {
                DiceNumbers[i] = dobbelsteen[i].RollDice(RandomNbr);
            }
           /*DiceNumbers[0] = 6;
            DiceNumbers[1] = 6;
            DiceNumbers[2] = 6;
            DiceNumbers[3] = 6;
            DiceNumbers[4] = 6;*/

            return DiceNumbers;
        }

        public  int ASumOfNbrs(int DiceNumber)
        {
            scoreSum = 0;
            for (int i = 0; i < DiceNumbers.Length; i++)
            {
                //System.Diagnostics.Debug.WriteLine(DiceNumbers[i]);
                if (DiceNumbers[i] == DiceNumber)
                {
                    scoreSum += DiceNumbers[i];
                    
                }

                switch (DiceNumber)
                {
                    case 1:
                        one = scoreSum;
                        break;
                    case 2:
                        two = scoreSum;
                        break;
                    case 3:
                        three = scoreSum;
                        break;
                    case 4:
                        four = scoreSum;
                        break;
                    case 5:
                        five = scoreSum;
                        break;
                    case 6:
                        six = scoreSum;
                        break;
                    
                }
            }
           
            return scoreSum;
        }

        public int ThreeOfKind()
        {
           
            bool threeOfAKindBool = false;

            for (int i = 1; i <= 6; i++)
            {
                int Count = 0;
                for (int j = 0; j < 5; j++)
                {
                    if (DiceNumbers[j] == i) 
                        Count++;

                    if (Count > 2)
                        threeOfAKindBool = true;
                }
            }

            if (threeOfAKindBool)
            {
                for (int k = 0; k < 5; k++)
                {
                    threeOfAKind += DiceNumbers[k];
                }
            }

            return threeOfAKind;
        }

        public int FourOfKind()
        {

            bool fourOfAKindBool = false;

            for (int i = 1; i <= 6; i++)
            {
                int Count = 0;
                for (int j = 0; j < 5; j++)
                {
                    if (DiceNumbers[j] == i)
                        Count++;

                    if (Count > 3)
                        fourOfAKindBool = true;
                }
            }

            if (fourOfAKindBool)
            {
                for (int k = 0; k < 5; k++)
                {
                    fourOfAKind += DiceNumbers[k];
                }
            }

            return fourOfAKind;
        }

        public  int FullHouse( )
        {
            int[] i = new int[5];

            for (int j = 0; j < DiceNumbers.Length; j++)
            {
                i[j] = DiceNumbers[j];
            }
          
            Array.Sort(i);

            if ((((i[0] == i[1]) && (i[1] == i[2])) && 
                 (i[3] == i[4]) && 
                 (i[2] != i[3])) ||
                ((i[0] == i[1]) && 
                 ((i[2] == i[3]) && (i[3] == i[4])) && 
                 (i[1] != i[2])))
            {
                fullHouse = 25;
            }
            return fullHouse;
        }

        public  int SmallStraight()
        {

            int[] i = new int[5];

            for (int j = 0; j < DiceNumbers.Length; j++)
            {
                i[j] = DiceNumbers[j];
            }

            Array.Sort(i);

            for (int j = 0; j < 4; j++)
            {
                int temp = 0;
                if (i[j] == i[j + 1])
                {
                    temp = i[j];

                    for (int k = j; k < 4; k++)
                    {
                        i[k] = i[k + 1];
                    }

                    i[4] = temp;
                }
            }

            if (((i[0] == 1) && (i[1] == 2) && (i[2] == 3) && (i[3] == 4)) ||
                ((i[0] == 2) && (i[1] == 3) && (i[2] == 4) && (i[3] == 5)) ||
                ((i[0] == 3) && (i[1] == 4) && (i[2] == 5) && (i[3] == 6)) ||
                ((i[1] == 1) && (i[2] == 2) && (i[3] == 3) && (i[4] == 4)) ||
                ((i[1] == 2) && (i[2] == 3) && (i[3] == 4) && (i[4] == 5)) ||
                ((i[1] == 3) && (i[2] == 4) && (i[3] == 5) && (i[4] == 6)))
            {
                smallStraight = 30;
            }
            return smallStraight;
        }

        public  int LargeStraight()
        {
            int[] i = new int[5];

            for (int j = 0; j < DiceNumbers.Length; j++)
            {
                i[j] = DiceNumbers[j];
            }

            Array.Sort(i);

            if (((i[0] == 1) &&
                 (i[1] == 2) &&
                 (i[2] == 3) &&
                 (i[3] == 4) &&
                 (i[4] == 5)) ||
                ((i[0] == 2) &&
                 (i[1] == 3) &&
                 (i[2] == 4) &&
                 (i[3] == 5) &&
                 (i[4] == 6)))
            {
                largeStraight = 40;
            }
            return largeStraight;
        }

        public  int Yahtzee()
        {
            
            for (int i = 1; i <= 6; i++)
            {
                int Count = 0;
                for (int j = 0; j < 5; j++)
                {
                    if (DiceNumbers[j] == i)
                    { Count++; }

                    if (Count > 4)
                    { yahtzee = 50;
                        if (yahtzeecount == 1)
                        {
                            yahtzeebool2 = true;
                        }
                    }
                }
            }
            yahtzeecount++;
            return yahtzee;
           
        }

        public  int Chance ()
        {
            for (int i = 0; i < 5; i++)
            {
                chance += DiceNumbers[i] ;
            }

            return chance;
        }
    

        public int Sub1Total1()
        {
            
            score1 = one + two + three + four + five + six;
            return score1;
            
        }

        public int Sub1Total2()
        {
            if (score1 >= 63)
            {
                countSub1 = score1;
                countSub1 += bonusOver63;
            }
            else
            {
                countSub1 = score1;
            }

           
            return countSub1;
        }

        public int Sub2Total1()
        {

            score2 = threeOfAKind + fourOfAKind + fullHouse + smallStraight + largeStraight + yahtzee + chance;
            return score2;
            
        }

        public int Sub2Total2()
        {
            if (yahtzeebool2)
            {
                 countSub2 = score2;
                countSub2 += ytzBonus;

            }
            else
            {
                 countSub2 = score2;
            }
            return countSub2;
        }

        public int TotalCount()
        {
            countTotalPoints = countSub1 + countSub2;
            return countTotalPoints;
        }

        public void GameReset(int btncount)
        {

            if (btncount == 14)
            {
                countTotalPoints = 0;
                countSub1 = 0;
                countSub2 = 0;
                scoreSum = 0;
                score1 = 0;
                score2 = 0;

                one = 0;
                two = 0;
                three = 0;
                four = 0;
                five = 0;
                six = 0;
                threeOfAKind = 0;
                fourOfAKind = 0;
                fullHouse = 0;
                smallStraight = 0;
                largeStraight = 0;
                yahtzee = 0;
                chance = 0;
                yahtzeecount = 0;
            }
            


    }



    }

}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace Game_Software_Yahtzee
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Game Spel = new Game();
        int nbrOfTries = 0;
        int yahtzeeCount =0;
        
        int countbtn = 0;
        Image[] diceImg;
        
        int[] dice;

   




        private void Form1_Load(object sender, EventArgs e)
        {
            diceImg = new Image[7];

            diceImg[1] = Properties.Resources.dice1;
            diceImg[2] = Properties.Resources.dice2;
            diceImg[3] = Properties.Resources.dice3;
            diceImg[4] = Properties.Resources.dice4;
            diceImg[5] = Properties.Resources.dice5;
            diceImg[6] = Properties.Resources.dice6;

            dice = new int[5] { 0, 0, 0, 0, 0 };
            Spel.InitDice();
        }

        void RollDice()
        {

            dice = Spel.RollDice();
            if (nbrOfTries == 2 )
            {
                Roll.Enabled = false;
            }
            nbrOfTries++;
            PB1.Image = diceImg[dice[0]];
            PB2.Image = diceImg[dice[1]];
            PB3.Image = diceImg[dice[2]];
            PB4.Image = diceImg[dice[3]];
            PB5.Image = diceImg[dice[4]];
        }

        private void Roll_Click(object sender, EventArgs e)
        {
            RollDice();
            
        }

        private void Lock1_Click(object sender, EventArgs e)
        {
            Spel.Lockdice(0);
            Lock1.Text = "LOCKED";
        }

        private void Lock2_Click(object sender, EventArgs e)
        {
            Spel.Lockdice(1);
            Lock2.Text = "LOCKED";
        }

        private void Lock3_Click(object sender, EventArgs e)
        {
            Spel.Lockdice(2);
            Lock3.Text = "LOCKED";
        }

        private void Lock4_Click(object sender, EventArgs e)
        {
            Spel.Lockdice(3);
            Lock4.Text = "LOCKED";
        }

        private void Lock5_Click(object sender, EventArgs e)
        {
            Spel.Lockdice(4);
            Lock5.Text = "LOCKED";
        }

        private void PB3_Click(object sender, EventArgs e)
        {

        }

        private void BtnOnes_Click(object sender, EventArgs e)
        {
            label3.Text = Spel.ASumOfNbrs(1).ToString();
            BtnOnes.Enabled = false;
            ResetRoll();
            UpperPoints();
            TotalPoints();
            ResetGame();
        }

        private void BtnTwos_Click(object sender, EventArgs e)
        {
            label4.Text = Spel.ASumOfNbrs(2).ToString();
            BtnTwos.Enabled = false;
            ResetRoll();
            UpperPoints();
            TotalPoints();
            ResetGame();
        }

        private void BtnThrees_Click(object sender, EventArgs e)
        {
            label5.Text = Spel.ASumOfNbrs(3).ToString();
            BtnThrees.Enabled = false;
            ResetRoll();
            UpperPoints();
            TotalPoints();
            ResetGame();
        }

        private void BtnFours_Click(object sender, EventArgs e)
        {
            label6.Text = Spel.ASumOfNbrs(4).ToString();
            BtnFours.Enabled = false;
            ResetRoll();
            UpperPoints();
            TotalPoints();
            ResetGame();
        }

        private void BtnFives_Click(object sender, EventArgs e)
        {
            label7.Text = Spel.ASumOfNbrs(5).ToString();
            BtnFives.Enabled = false;
            ResetRoll();
            UpperPoints();
            TotalPoints();
            ResetGame();
        }

        private void BtnSix_Click(object sender, EventArgs e)
        {
            label8.Text = Spel.ASumOfNbrs(6).ToString();
            BtnSix.Enabled = false;
            ResetRoll();
            UpperPoints();
            TotalPoints();
            ResetGame();
        }

        

        private void BtnThreeOfAKind_Click(object sender, EventArgs e)
        {
            label17.Text = Spel.ThreeOfKind().ToString();
            BtnThreeOfAKind.Enabled = false;
            ResetRoll();
            LowerPoints();
            TotalPoints();
            ResetGame();
        }

        private void BtnFourOfAKind_Click(object sender, EventArgs e)
        {
            label16.Text = Spel.FourOfKind().ToString();
            BtnFourOfAKind.Enabled = false;
            ResetRoll();
            LowerPoints();
            TotalPoints();
            ResetGame();
        }

        private void BtnFullHouse_Click(object sender, EventArgs e)
        {
            label15.Text = Spel.FullHouse().ToString();
            BtnFullHouse.Enabled = false;
            ResetRoll();
            LowerPoints();
            TotalPoints();
            ResetGame();
        }

        private void BtnSmallStraight_Click(object sender, EventArgs e)
        {
            label14.Text = Spel.SmallStraight().ToString();
            BtnSmallStraight.Enabled = false;
            ResetRoll();
            LowerPoints();
            TotalPoints();
            ResetGame();
        }

        private void BtnLargeStraight_Click(object sender, EventArgs e)
        {
            label13.Text = Spel.LargeStraight().ToString();
            BtnLargeStraight.Enabled = false;
            ResetRoll();
            LowerPoints();
            TotalPoints();
            ResetGame();
        }

        private void btnYahtzee_Click(object sender, EventArgs e)
        {
            yahtzeeCount++;
            if (yahtzeeCount == 1)
            {
                label12.Text = Spel.Yahtzee().ToString();
            }
            else if (yahtzeeCount==2)
            {
                label20.Text = Spel.Yahtzee().ToString();
                btnYahtzee.Enabled = false;
            }
            ResetRoll();
            LowerPoints();
            TotalPoints();
            ResetGame();


        }

        private void btnChance_Click(object sender, EventArgs e)
        {
            label18.Text = Spel.Chance().ToString();
            btnChance.Enabled = false;
            ResetRoll();
            LowerPoints();
            TotalPoints();

        }

        public void ResetRoll()
        {
            Roll.Enabled = true;
            nbrOfTries = 0;
            for (int i = 0; i < 5; i++)
            {
                Spel.UnlockDice(i);
            }
            Lock1.Text = "LOCK";
            Lock2.Text = "LOCK";
            Lock3.Text = "LOCK";
            Lock4.Text = "LOCK";
            Lock5.Text = "LOCK";
        }

        public void UpperPoints()
        {
            label9.Text = Spel.Sub1Total1().ToString();
            if (Spel.Sub1Total1() >= 63)
            {
                label10.Text = "35";
            }
            label11.Text = Spel.Sub1Total2().ToString();
            countbtn++;

        }

        public void LowerPoints()
        {
            label21.Text = Spel.Sub2Total1().ToString();
            if (yahtzeeCount == 2)
            {
                if (Spel.Yahtzee() == 0)
                {
                    label20.Text = "0";
                }
                else
                {
                    label20.Text = "100";
                }

            }
            
            
            label19.Text = Spel.Sub2Total2().ToString();
            countbtn++;
        }

        public void TotalPoints()
        {
            label23.Text = Spel.TotalCount().ToString();
        }

        public void ResetGame()
        {
            if (countbtn == 14)
            {
                DialogResult result;

                // Displays the MessageBox.
                result = MessageBox.Show("Wil je opnieuw spelen ? ", "End Of Game", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                { 

                    Spel.GameReset(countbtn);

                    countbtn = 0;

                    label3.Text = "0";
                    label4.Text = "0";
                    label5.Text = "0";
                    label6.Text = "0";
                    label7.Text = "0";
                    label8.Text = "0";
                    label9.Text = "0";
                    label10.Text = "0";
                    label11.Text = "0";
                    label12.Text = "0";
                    label13.Text = "0";
                    label14.Text = "0";
                    label15.Text = "0";
                    label16.Text = "0";
                    label17.Text = "0";
                    label18.Text = "0";
                    label19.Text = "0";
                    label20.Text = "0";
                    label21.Text = "0";
                    label23.Text = "0";

                    BtnOnes.Enabled = true;
                    BtnTwos.Enabled = true;
                    BtnThrees.Enabled = true;
                    BtnFours.Enabled = true;
                    BtnFives.Enabled = true;
                    BtnSix.Enabled = true;
                    BtnThreeOfAKind.Enabled = true;
                    BtnFourOfAKind.Enabled = true;
                    BtnFullHouse.Enabled = true;
                    BtnSmallStraight.Enabled = true;
                    BtnLargeStraight.Enabled = true;
                    btnYahtzee.Enabled = true;
                    btnChance.Enabled = true;


                }
                else
                {
                    this.Close();
                }
            }

        }


        



        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }
        private void label21_Click(object sender, EventArgs e)
        {
            
        }

        private void label20_Click(object sender, EventArgs e)
        {
         
        }

        private void label19_Click(object sender, EventArgs e)
        {
           
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }

    public partial class MethodesForm1 : Form
    {
        public MethodesForm1()
        {
            InitializeComponent();
        }
        Game Spel = new Game();
        int nbrOfTries = 0;
        int yahtzeeCount = 0;

        int countbtn = 0;
        Image[] diceImg;

        int[] dice;






        private void Form1_Load(object sender, EventArgs e)
        {
            diceImg = new Image[7];

            diceImg[1] = Properties.Resources.dice1;
            diceImg[2] = Properties.Resources.dice2;
            diceImg[3] = Properties.Resources.dice3;
            diceImg[4] = Properties.Resources.dice4;
            diceImg[5] = Properties.Resources.dice5;
            diceImg[6] = Properties.Resources.dice6;

            dice = new int[5] { 0, 0, 0, 0, 0 };
            Spel.InitDice();
        }

        void RollDice()
        {

            dice = Spel.RollDice();
            if (nbrOfTries == 2)
            {
                Roll.Enabled = false;
            }
            nbrOfTries++;
            PB1.Image = diceImg[dice[0]];
            PB2.Image = diceImg[dice[1]];
            PB3.Image = diceImg[dice[2]];
            PB4.Image = diceImg[dice[3]];
            PB5.Image = diceImg[dice[4]];
        }

        private void Roll_Click(object sender, EventArgs e)
        {
            RollDice();

        }

        private void Lock1_Click(object sender, EventArgs e)
        {
            Spel.Lockdice(0);
            Lock1.Text = "LOCKED";
        }

        private void Lock2_Click(object sender, EventArgs e)
        {
            Spel.Lockdice(1);
            Lock2.Text = "LOCKED";
        }

        private void Lock3_Click(object sender, EventArgs e)
        {
            Spel.Lockdice(2);
            Lock3.Text = "LOCKED";
        }

        private void Lock4_Click(object sender, EventArgs e)
        {
            Spel.Lockdice(3);
            Lock4.Text = "LOCKED";
        }

        private void Lock5_Click(object sender, EventArgs e)
        {
            Spel.Lockdice(4);
            Lock5.Text = "LOCKED";
        }

        private void PB3_Click(object sender, EventArgs e)
        {

        }

        private void BtnOnes_Click(object sender, EventArgs e)
        {
            label3.Text = Spel.ASumOfNbrs(1).ToString();
            BtnOnes.Enabled = false;
            ResetRoll();
            UpperPoints();
            TotalPoints();
            ResetGame();
        }

        private void BtnTwos_Click(object sender, EventArgs e)
        {
            label4.Text = Spel.ASumOfNbrs(2).ToString();
            BtnTwos.Enabled = false;
            ResetRoll();
            UpperPoints();
            TotalPoints();
            ResetGame();
        }

        private void BtnThrees_Click(object sender, EventArgs e)
        {
            label5.Text = Spel.ASumOfNbrs(3).ToString();
            BtnThrees.Enabled = false;
            ResetRoll();
            UpperPoints();
            TotalPoints();
            ResetGame();
        }

        private void BtnFours_Click(object sender, EventArgs e)
        {
            label6.Text = Spel.ASumOfNbrs(4).ToString();
            BtnFours.Enabled = false;
            ResetRoll();
            UpperPoints();
            TotalPoints();
            ResetGame();
        }

        private void BtnFives_Click(object sender, EventArgs e)
        {
            label7.Text = Spel.ASumOfNbrs(5).ToString();
            BtnFives.Enabled = false;
            ResetRoll();
            UpperPoints();
            TotalPoints();
            ResetGame();
        }

        private void BtnSix_Click(object sender, EventArgs e)
        {
            label8.Text = Spel.ASumOfNbrs(6).ToString();
            BtnSix.Enabled = false;
            ResetRoll();
            UpperPoints();
            TotalPoints();
            ResetGame();
        }



        private void BtnThreeOfAKind_Click(object sender, EventArgs e)
        {
            label17.Text = Spel.ThreeOfKind().ToString();
            BtnThreeOfAKind.Enabled = false;
            ResetRoll();
            LowerPoints();
            TotalPoints();
            ResetGame();
        }

        private void BtnFourOfAKind_Click(object sender, EventArgs e)
        {
            label16.Text = Spel.FourOfKind().ToString();
            BtnFourOfAKind.Enabled = false;
            ResetRoll();
            LowerPoints();
            TotalPoints();
            ResetGame();
        }

        private void BtnFullHouse_Click(object sender, EventArgs e)
        {
            label15.Text = Spel.FullHouse().ToString();
            BtnFullHouse.Enabled = false;
            ResetRoll();
            LowerPoints();
            TotalPoints();
            ResetGame();
        }

        private void BtnSmallStraight_Click(object sender, EventArgs e)
        {
            label14.Text = Spel.SmallStraight().ToString();
            BtnSmallStraight.Enabled = false;
            ResetRoll();
            LowerPoints();
            TotalPoints();
            ResetGame();
        }

        private void BtnLargeStraight_Click(object sender, EventArgs e)
        {
            label13.Text = Spel.LargeStraight().ToString();
            BtnLargeStraight.Enabled = false;
            ResetRoll();
            LowerPoints();
            TotalPoints();
            ResetGame();
        }

        private void btnYahtzee_Click(object sender, EventArgs e)
        {
            yahtzeeCount++;
            if (yahtzeeCount == 1)
            {
                label12.Text = Spel.Yahtzee().ToString();
            }
            else if (yahtzeeCount == 2)
            {
                label20.Text = Spel.Yahtzee().ToString();
                btnYahtzee.Enabled = false;
            }
            ResetRoll();
            LowerPoints();
            TotalPoints();
            ResetGame();


        }

        private void btnChance_Click(object sender, EventArgs e)
        {
            label18.Text = Spel.Chance().ToString();
            btnChance.Enabled = false;
            ResetRoll();
            LowerPoints();
            TotalPoints();

        }

        public void ResetRoll()
        {
            Roll.Enabled = true;
            nbrOfTries = 0;
            for (int i = 0; i < 5; i++)
            {
                Spel.UnlockDice(i);
            }
            Lock1.Text = "LOCK";
            Lock2.Text = "LOCK";
            Lock3.Text = "LOCK";
            Lock4.Text = "LOCK";
            Lock5.Text = "LOCK";
        }

        public void UpperPoints()
        {
            label9.Text = Spel.Sub1Total1().ToString();
            if (Spel.Sub1Total1() >= 63)
            {
                label10.Text = "35";
            }
            label11.Text = Spel.Sub1Total2().ToString();
            countbtn++;

        }

        public void LowerPoints()
        {
            label21.Text = Spel.Sub2Total1().ToString();
            if (yahtzeeCount == 2)
            {
                if (Spel.Yahtzee() == 0)
                {
                    label20.Text = "0";
                }
                else
                {
                    label20.Text = "100";
                }

            }


            label19.Text = Spel.Sub2Total2().ToString();
            countbtn++;
        }

        public void TotalPoints()
        {
            label23.Text = Spel.TotalCount().ToString();
        }

        public void ResetGame()
        {
            if (countbtn == 14)
            {
                DialogResult result;

                // Displays the MessageBox.
                result = MessageBox.Show("Wil je opnieuw spelen ? ", "End Of Game", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {

                    Spel.GameReset(countbtn);

                    countbtn = 0;

                    label3.Text = "0";
                    label4.Text = "0";
                    label5.Text = "0";
                    label6.Text = "0";
                    label7.Text = "0";
                    label8.Text = "0";
                    label9.Text = "0";
                    label10.Text = "0";
                    label11.Text = "0";
                    label12.Text = "0";
                    label13.Text = "0";
                    label14.Text = "0";
                    label15.Text = "0";
                    label16.Text = "0";
                    label17.Text = "0";
                    label18.Text = "0";
                    label19.Text = "0";
                    label20.Text = "0";
                    label21.Text = "0";
                    label23.Text = "0";

                    BtnOnes.Enabled = true;
                    BtnTwos.Enabled = true;
                    BtnThrees.Enabled = true;
                    BtnFours.Enabled = true;
                    BtnFives.Enabled = true;
                    BtnSix.Enabled = true;
                    BtnThreeOfAKind.Enabled = true;
                    BtnFourOfAKind.Enabled = true;
                    BtnFullHouse.Enabled = true;
                    BtnSmallStraight.Enabled = true;
                    BtnLargeStraight.Enabled = true;
                    btnYahtzee.Enabled = true;
                    btnChance.Enabled = true;


                }
                else
                {
                    this.Close();
                }
            }

        }






        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }
        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void label20_Click(object sender, EventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

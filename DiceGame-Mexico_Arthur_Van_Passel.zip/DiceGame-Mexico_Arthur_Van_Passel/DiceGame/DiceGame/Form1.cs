﻿#region Using Statements
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
#endregion
namespace DiceGame
{
    public partial class Form1 : Form
    {

        #region Declaration

        Image[] diceImages;
        Player player;

        #endregion

        #region Initialization

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            player = new Player("Player");
            lbl_pName.Text = player.Name;
            diceImages = new Image[7];
            diceImages[0] = Properties.Resources.dice_blank;
            diceImages[1] = Properties.Resources.dice_1;
            diceImages[2] = Properties.Resources.dice_2;
            diceImages[3] = Properties.Resources.dice_3;
            diceImages[4] = Properties.Resources.dice_4;
            diceImages[5] = Properties.Resources.dice_5;
            diceImages[6] = Properties.Resources.dice_6;
        }

        #endregion

        #region Private Methods
        

        private void btn_rollDice_Click(object sender, EventArgs e)
        {
            player.RollDice();

            lbl_dice1.Image = diceImages[player.Dice[0]];
            lbl_dice2.Image = diceImages[player.Dice[1]];
            lbl_displayResults.Text = player.Result;
            lbl_displayScore.Text = player.Scoreboard;

            player.Played = true;
        }

        #endregion

        private void btn_help_Click(object sender, EventArgs e)
        {
            if (pnl_help.Visible)
            {
                pnl_help.Visible = false;
            }
            else
            {
                pnl_help.Visible = true;
            }
        }

        private void btn_restart_Click(object sender, EventArgs e)
        {
            player.ResetPlayer();
        }
    }
}

﻿namespace DiceGame
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lbl_result = new System.Windows.Forms.Label();
            this.lbl_dice1 = new System.Windows.Forms.Label();
            this.lbl_dice2 = new System.Windows.Forms.Label();
            this.btn_rollDice = new System.Windows.Forms.Button();
            this.lbl_displayResults = new System.Windows.Forms.Label();
            this.lbl_pName = new System.Windows.Forms.Label();
            this.lbl_displayScore = new System.Windows.Forms.Label();
            this.btn_help = new System.Windows.Forms.Button();
            this.pnl_help = new System.Windows.Forms.Panel();
            this.lbl_rules = new System.Windows.Forms.Label();
            this.pnl_help.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_result
            // 
            this.lbl_result.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_result.Location = new System.Drawing.Point(24, 60);
            this.lbl_result.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_result.Name = "lbl_result";
            this.lbl_result.Size = new System.Drawing.Size(466, 62);
            this.lbl_result.TabIndex = 14;
            this.lbl_result.Text = "Waiting for Roll...";
            this.lbl_result.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_dice1
            // 
            this.lbl_dice1.Image = global::DiceGame.Properties.Resources.dice_blank;
            this.lbl_dice1.Location = new System.Drawing.Point(174, 220);
            this.lbl_dice1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_dice1.Name = "lbl_dice1";
            this.lbl_dice1.Size = new System.Drawing.Size(80, 62);
            this.lbl_dice1.TabIndex = 0;
            // 
            // lbl_dice2
            // 
            this.lbl_dice2.Image = global::DiceGame.Properties.Resources.dice_blank;
            this.lbl_dice2.Location = new System.Drawing.Point(249, 220);
            this.lbl_dice2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_dice2.Name = "lbl_dice2";
            this.lbl_dice2.Size = new System.Drawing.Size(80, 62);
            this.lbl_dice2.TabIndex = 1;
            // 
            // btn_rollDice
            // 
            this.btn_rollDice.Location = new System.Drawing.Point(119, 322);
            this.btn_rollDice.Margin = new System.Windows.Forms.Padding(4);
            this.btn_rollDice.Name = "btn_rollDice";
            this.btn_rollDice.Size = new System.Drawing.Size(267, 62);
            this.btn_rollDice.TabIndex = 5;
            this.btn_rollDice.Text = "Roll the Dice";
            this.btn_rollDice.UseVisualStyleBackColor = true;
            this.btn_rollDice.Click += new System.EventHandler(this.btn_rollDice_Click);
            // 
            // lbl_displayResults
            // 
            this.lbl_displayResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_displayResults.Location = new System.Drawing.Point(81, 405);
            this.lbl_displayResults.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_displayResults.Name = "lbl_displayResults";
            this.lbl_displayResults.Size = new System.Drawing.Size(333, 88);
            this.lbl_displayResults.TabIndex = 6;
            this.lbl_displayResults.Text = "Roll The Dice";
            this.lbl_displayResults.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbl_pName
            // 
            this.lbl_pName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pName.Location = new System.Drawing.Point(73, 133);
            this.lbl_pName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_pName.Name = "lbl_pName";
            this.lbl_pName.Size = new System.Drawing.Size(375, 62);
            this.lbl_pName.TabIndex = 15;
            this.lbl_pName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_displayScore
            // 
            this.lbl_displayScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_displayScore.Location = new System.Drawing.Point(81, 493);
            this.lbl_displayScore.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_displayScore.Name = "lbl_displayScore";
            this.lbl_displayScore.Size = new System.Drawing.Size(333, 129);
            this.lbl_displayScore.TabIndex = 16;
            this.lbl_displayScore.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btn_help
            // 
            this.btn_help.Location = new System.Drawing.Point(394, 322);
            this.btn_help.Margin = new System.Windows.Forms.Padding(4);
            this.btn_help.Name = "btn_help";
            this.btn_help.Size = new System.Drawing.Size(96, 62);
            this.btn_help.TabIndex = 17;
            this.btn_help.Text = "Help";
            this.btn_help.UseVisualStyleBackColor = true;
            this.btn_help.Click += new System.EventHandler(this.btn_help_Click);
            // 
            // pnl_help
            // 
            this.pnl_help.Controls.Add(this.lbl_rules);
            this.pnl_help.Location = new System.Drawing.Point(16, 12);
            this.pnl_help.Name = "pnl_help";
            this.pnl_help.Size = new System.Drawing.Size(371, 610);
            this.pnl_help.TabIndex = 19;
            this.pnl_help.Visible = false;
            // 
            // lbl_rules
            // 
            this.lbl_rules.AllowDrop = true;
            this.lbl_rules.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_rules.Location = new System.Drawing.Point(12, 12);
            this.lbl_rules.Name = "lbl_rules";
            this.lbl_rules.Size = new System.Drawing.Size(345, 581);
            this.lbl_rules.TabIndex = 0;
            this.lbl_rules.Text = resources.GetString("lbl_rules.Text");
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(498, 681);
            this.Controls.Add(this.pnl_help);
            this.Controls.Add(this.btn_help);
            this.Controls.Add(this.lbl_displayScore);
            this.Controls.Add(this.lbl_pName);
            this.Controls.Add(this.lbl_result);
            this.Controls.Add(this.lbl_displayResults);
            this.Controls.Add(this.btn_rollDice);
            this.Controls.Add(this.lbl_dice2);
            this.Controls.Add(this.lbl_dice1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1061, 728);
            this.MinimumSize = new System.Drawing.Size(400, 400);
            this.Name = "Form1";
            this.Text = "DiceGame";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.pnl_help.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label lbl_result;
        private System.Windows.Forms.Label lbl_dice1;
        private System.Windows.Forms.Label lbl_dice2;
        private System.Windows.Forms.Button btn_rollDice;
        private System.Windows.Forms.Label lbl_displayResults;
        private System.Windows.Forms.Label lbl_pName;
        private System.Windows.Forms.Label lbl_displayScore;
        private System.Windows.Forms.Button btn_help;
        private System.Windows.Forms.Panel pnl_help;
        private System.Windows.Forms.Label lbl_rules;
    }
}


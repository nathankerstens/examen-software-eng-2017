﻿#region Using Statements
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
#endregion
namespace DiceGame
{
    public class Player
    {
        #region Declaration

        int[] dice;
        static Random rand;
        bool played = false;
        string result, name, scoreboard;
        int handRank, aantalWorpen, aantalGeworpen;

        #endregion

        #region Properties

        public int[] Dice
        {
            get { return dice; }
        }

        public string Name
        {
            set { name = value; }
            get { return name; }
        }

        public bool Played
        {
            set { played = value; }
            get { return played; }
        }

        public string Result
        {
            get { return result; }
        }

        public string Scoreboard
        {
            get { return scoreboard; }
        }

        public int HandRank
        {
            get { return handRank; }
        }
        #endregion

        #region Initialization

        public Player(string playerName)
        {
            name = playerName;

            dice = new int[2] { 0, 0 };

            rand = new Random();

            handRank = 0;

            aantalWorpen = 3;

            aantalGeworpen = 0;

            played = false;

            result = "Roll the Dice";

            scoreboard = "";
        }
        #endregion

        #region Public Methods

        public int RollDice()
        {
            for (int i = 0; i < dice.Length; i++)
            {
                dice[i] = rand.Next(1, 7);
            }
            return GetResults();
        }
        public void ResetPlayer()
        {
            for (int i = 0; i < dice.Length; i++)
            {
                dice[i] = 0;
            }
            played = false;
        }
        #endregion


        #region Private Methods
        private int GetResults()
        {
            string oldresult = result;
            result = "";
            bool buske = false,         //32    1
                snakeeyes = false,      //11    2
                castro = false,         //31    3
                eenenveertig = false,   //41    4
                tweeenveertig = false,  //42    5
                drieenveertig = false,  //43    6
                eenenvijftig = false,   //51    7
                tweeenvijftig = false,  //52    8
                drieenvijftig = false,  //53    9
                vierenvijftig = false,  //54    10
                eenenzestig = false,    //61    11
                tweeenzestig = false,   //62    12
                drieenzestig = false,   //63    13
                vierenzestig = false,   //64    14
                vijfenzestig = false,   //65    15
                tweehonderd = false,    //22    16
                driehonderd = false,    //33    17
                vierhonderd = false,    //44    18
                vijfhonderd = false,    //55    19
                zeshonderd = false,     //66    20
                mexico = false;         //21    21


            if (dice[0] == dice[1])
            {
                if (dice[0] == 1 && handRank < 2)
                {
                    snakeeyes = true;
                    result = "Snake Eyes";
                    handRank = 2;
                }
                else if (dice[0] == 2 && handRank < 16)
                {
                    tweehonderd = true;
                    result = "Twee Honderd";
                    handRank = 16;
                }
                else if (dice[0] == 3 && handRank < 17)
                {
                    driehonderd = true;
                    result = "Drie Honderd";
                    handRank = 17;
                }
                else if (dice[0] == 4 && handRank < 18)
                {
                    vierhonderd = true;
                    result = "Vier Honderd";
                    handRank = 18;
                }
                else if (dice[0] == 5 && handRank < 19)
                {
                    vijfhonderd = true;
                    result = "Vijf Honderd";
                    handRank = 19;
                }
                else if (dice[0] == 6 && handRank < 20)
                {
                    zeshonderd = true;
                    result = "Zes Honderd";
                    handRank = 20;
                }
            }
            else if (dice[0] == dice[1] + 1 || dice[0] + 1 == dice[1])
            {
                if ((dice[0] == 1 || dice[1] == 1))
                {
                    mexico = true;
                    result = "MEXICO!!! De verliezer doet een ad fundum!";
                    handRank = 21;
                    aantalGeworpen = aantalWorpen-1;

                }
                else if (dice[0] == 2 || dice[1] == 2 && dice[0] == 3 || dice[1] == 3)
                {
                    buske = true;
                    result = "Buske... Je mag niet meer gooien en moet op het einde van de ronde drinken...";
                    handRank = 1;
                    aantalGeworpen = aantalWorpen-1;
                }
                else if (dice[0] == 3 || dice[1] == 3 && dice[0] == 4 || dice[1] == 4 && handRank < 6)
                {
                    drieenveertig = true;
                    result = "Drie en veertig";
                    handRank = 6;
                }
                else if (dice[0] == 4 || dice[1] == 4 && dice[0] == 5 || dice[1] == 5 && handRank < 10)
                {
                    vierenvijftig = true;
                    result = "Vier en vijftig";
                    handRank = 10;
                }
                else if (dice[0] == 5 || dice[1] == 5 && dice[0] == 6 || dice[1] == 6 && handRank < 15)
                {
                    vijfenzestig = true;
                    result = "Vijf en zestig";
                    handRank = 15;
                }
            }
            else if (dice[0] == dice[1] + 2 || dice[0] + 2 == dice[1])
            {
                if (dice[0] == 1 || dice[1] == 1 && dice[0] == 3 || dice[1] == 3)
                {
                    castro = true;
                    result = "Castro! Je mag een halve ad fundum uitdelen en opnieuw beginnen met gooien!";
                    handRank = 0;
                    aantalGeworpen = -1;
                }
                else if ((dice[0] == 2 || dice[1] == 2 && dice[0] == 4 || dice[1] == 4) && handRank < 5)
                {
                    tweeenveertig = true;
                    result = "Twee en veertig";
                    handRank = 5;
                }
                else if ((dice[0] == 5 || dice[1] == 5 && dice[0] == 3 || dice[1] == 3) && handRank < 9)
                {
                    drieenvijftig = true;
                    result = "Drie en vijftig";
                    handRank = 9;
                }
                else if ((dice[0] == 4 || dice[1] == 4 && dice[0] == 6 || dice[1] == 6) && handRank < 14)
                {
                    vierenzestig = true;
                    result = "Vier en zestig";
                    handRank = 14;
                }
            }
            else if (dice[0] == dice[1] + 3 || dice[0] + 3 == dice[1])
            {
                if ((dice[0] == 1 || dice[1] == 1 && dice[0] == 4 || dice[1] == 4) && handRank < 4)
                {
                    eenenveertig = true;
                    result = "Een en veertig";
                    handRank = 4;
                }
                else if ((dice[0] == 2 || dice[1] == 2 && dice[0] == 5 || dice[1] == 5) && handRank < 8)
                {
                    tweeenvijftig = true;
                    result = "Twee en vijftig";
                    handRank = 8;
                }
                else if ((dice[0] == 3 || dice[1] == 3 && dice[0] == 6 || dice[1] == 6) && handRank < 13)
                {
                    drieenzestig = true;
                    result = "Drie en zestig";
                    handRank = 13;
                }
            }
            else if (dice[0] == dice[1] + 4 || dice[0] + 4 == dice[1])
            {
                if ((dice[0] == 1 || dice[1] == 1 && dice[0] == 5 || dice[1] == 5) && handRank < 7)
                {
                    eenenvijftig = true;
                    result = "Een en vijftig";
                    handRank = 7;
                }
                else if ((dice[0] == 2 || dice[1] == 2 && dice[0] == 6 || dice[1] == 6) && handRank < 12)
                    {
                    tweeenzestig = true;
                    result = "Twee en zestig";
                    handRank = 12;
                }
            }
            else if (dice[0] == dice[1] + 5 || dice[0] + 5 == dice[1] && handRank < 11)
            {
                eenenzestig = true;
                result = "Een en zestig";
                handRank = 11;
            }

            if (result == "" || result == "[Niet hoger gegooid, " + oldresult + " blijft.]")
            {
                result = "[Niet hoger gegooid, " + oldresult + " blijft.]";
            }

            aantalGeworpen++;

            scoreboard = "Aantal worpen = " + aantalWorpen;
            scoreboard += "\n Aantal keer geworpen deze beurt = " + aantalGeworpen;

            if (aantalGeworpen >= aantalWorpen)
            {
                scoreboard += "\n\nHet is nu aan de volgende persoon.";
                aantalGeworpen = 0;
                handRank = 0;
            }

            return aantalGeworpen;
        }
        #endregion
    }
}

﻿namespace Yathzeeish
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dice1_player1 = new System.Windows.Forms.Label();
            this.dice2_player1 = new System.Windows.Forms.Label();
            this.dice3_player1 = new System.Windows.Forms.Label();
            this.dice4_player1 = new System.Windows.Forms.Label();
            this.dice5_player1 = new System.Windows.Forms.Label();
            this.btn_RollTheDice_player1 = new System.Windows.Forms.Button();
            this.label_results_player1 = new System.Windows.Forms.Label();
            this.label_results_player2 = new System.Windows.Forms.Label();
            this.btn_RollTheDice_player2 = new System.Windows.Forms.Button();
            this.dice5_player2 = new System.Windows.Forms.Label();
            this.dice4_player2 = new System.Windows.Forms.Label();
            this.dice3_player2 = new System.Windows.Forms.Label();
            this.dice2_player2 = new System.Windows.Forms.Label();
            this.dice1_player2 = new System.Windows.Forms.Label();
            this.label_winnerResult = new System.Windows.Forms.Label();
            this.player1_name = new System.Windows.Forms.Label();
            this.player2_name = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // dice1_player1
            // 
            this.dice1_player1.Image = global::Yathzeeish.Properties.Resources.dice00;
            this.dice1_player1.Location = new System.Drawing.Point(29, 160);
            this.dice1_player1.Name = "dice1_player1";
            this.dice1_player1.Size = new System.Drawing.Size(50, 50);
            this.dice1_player1.TabIndex = 0;
            this.dice1_player1.Tag = "cv";
            // 
            // dice2_player1
            // 
            this.dice2_player1.Image = global::Yathzeeish.Properties.Resources.dice00;
            this.dice2_player1.Location = new System.Drawing.Point(85, 160);
            this.dice2_player1.Name = "dice2_player1";
            this.dice2_player1.Size = new System.Drawing.Size(50, 50);
            this.dice2_player1.TabIndex = 1;
            this.dice2_player1.Tag = "cv";
            // 
            // dice3_player1
            // 
            this.dice3_player1.Image = global::Yathzeeish.Properties.Resources.dice00;
            this.dice3_player1.Location = new System.Drawing.Point(141, 160);
            this.dice3_player1.Name = "dice3_player1";
            this.dice3_player1.Size = new System.Drawing.Size(50, 50);
            this.dice3_player1.TabIndex = 2;
            this.dice3_player1.Tag = "cv";
            // 
            // dice4_player1
            // 
            this.dice4_player1.Image = global::Yathzeeish.Properties.Resources.dice00;
            this.dice4_player1.Location = new System.Drawing.Point(197, 160);
            this.dice4_player1.Name = "dice4_player1";
            this.dice4_player1.Size = new System.Drawing.Size(50, 50);
            this.dice4_player1.TabIndex = 3;
            this.dice4_player1.Tag = "cv";
            // 
            // dice5_player1
            // 
            this.dice5_player1.Image = global::Yathzeeish.Properties.Resources.dice00;
            this.dice5_player1.Location = new System.Drawing.Point(253, 160);
            this.dice5_player1.Name = "dice5_player1";
            this.dice5_player1.Size = new System.Drawing.Size(50, 50);
            this.dice5_player1.TabIndex = 4;
            this.dice5_player1.Tag = "cv";
            // 
            // btn_RollTheDice_player1
            // 
            this.btn_RollTheDice_player1.Location = new System.Drawing.Point(70, 243);
            this.btn_RollTheDice_player1.Name = "btn_RollTheDice_player1";
            this.btn_RollTheDice_player1.Size = new System.Drawing.Size(200, 50);
            this.btn_RollTheDice_player1.TabIndex = 6;
            this.btn_RollTheDice_player1.Tag = "cv";
            this.btn_RollTheDice_player1.Text = "Roll The Dice";
            this.btn_RollTheDice_player1.UseVisualStyleBackColor = true;
            this.btn_RollTheDice_player1.Click += new System.EventHandler(this.btn_RollTheDice_player1_Click);
            // 
            // label_results_player1
            // 
            this.label_results_player1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_results_player1.Location = new System.Drawing.Point(43, 311);
            this.label_results_player1.Name = "label_results_player1";
            this.label_results_player1.Size = new System.Drawing.Size(250, 50);
            this.label_results_player1.TabIndex = 7;
            this.label_results_player1.Tag = "cv";
            this.label_results_player1.Text = "???";
            this.label_results_player1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_results_player2
            // 
            this.label_results_player2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_results_player2.Location = new System.Drawing.Point(434, 311);
            this.label_results_player2.Name = "label_results_player2";
            this.label_results_player2.Size = new System.Drawing.Size(250, 50);
            this.label_results_player2.TabIndex = 15;
            this.label_results_player2.Tag = "cv";
            this.label_results_player2.Text = "???";
            this.label_results_player2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_RollTheDice_player2
            // 
            this.btn_RollTheDice_player2.Location = new System.Drawing.Point(461, 243);
            this.btn_RollTheDice_player2.Name = "btn_RollTheDice_player2";
            this.btn_RollTheDice_player2.Size = new System.Drawing.Size(200, 50);
            this.btn_RollTheDice_player2.TabIndex = 14;
            this.btn_RollTheDice_player2.Tag = "cv";
            this.btn_RollTheDice_player2.Text = "Roll The Dice";
            this.btn_RollTheDice_player2.UseVisualStyleBackColor = true;
            this.btn_RollTheDice_player2.Click += new System.EventHandler(this.btn_RollTheDice_player2_Click);
            // 
            // dice5_player2
            // 
            this.dice5_player2.Image = global::Yathzeeish.Properties.Resources.dice00;
            this.dice5_player2.Location = new System.Drawing.Point(644, 160);
            this.dice5_player2.Name = "dice5_player2";
            this.dice5_player2.Size = new System.Drawing.Size(50, 50);
            this.dice5_player2.TabIndex = 12;
            this.dice5_player2.Tag = "cv";
            // 
            // dice4_player2
            // 
            this.dice4_player2.Image = global::Yathzeeish.Properties.Resources.dice00;
            this.dice4_player2.Location = new System.Drawing.Point(588, 160);
            this.dice4_player2.Name = "dice4_player2";
            this.dice4_player2.Size = new System.Drawing.Size(50, 50);
            this.dice4_player2.TabIndex = 11;
            this.dice4_player2.Tag = "cv";
            // 
            // dice3_player2
            // 
            this.dice3_player2.Image = global::Yathzeeish.Properties.Resources.dice00;
            this.dice3_player2.Location = new System.Drawing.Point(532, 160);
            this.dice3_player2.Name = "dice3_player2";
            this.dice3_player2.Size = new System.Drawing.Size(50, 50);
            this.dice3_player2.TabIndex = 10;
            this.dice3_player2.Tag = "cv";
            // 
            // dice2_player2
            // 
            this.dice2_player2.Image = global::Yathzeeish.Properties.Resources.dice00;
            this.dice2_player2.Location = new System.Drawing.Point(476, 160);
            this.dice2_player2.Name = "dice2_player2";
            this.dice2_player2.Size = new System.Drawing.Size(50, 50);
            this.dice2_player2.TabIndex = 9;
            this.dice2_player2.Tag = "cv";
            // 
            // dice1_player2
            // 
            this.dice1_player2.Image = global::Yathzeeish.Properties.Resources.dice00;
            this.dice1_player2.Location = new System.Drawing.Point(420, 160);
            this.dice1_player2.Name = "dice1_player2";
            this.dice1_player2.Size = new System.Drawing.Size(50, 50);
            this.dice1_player2.TabIndex = 8;
            this.dice1_player2.Tag = "cv";
            // 
            // label_winnerResult
            // 
            this.label_winnerResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_winnerResult.Location = new System.Drawing.Point(232, 42);
            this.label_winnerResult.Name = "label_winnerResult";
            this.label_winnerResult.Size = new System.Drawing.Size(350, 50);
            this.label_winnerResult.TabIndex = 16;
            this.label_winnerResult.Text = "Waiting for Roll!!";
            this.label_winnerResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // player1_name
            // 
            this.player1_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.player1_name.Location = new System.Drawing.Point(65, 92);
            this.player1_name.Name = "player1_name";
            this.player1_name.Size = new System.Drawing.Size(250, 50);
            this.player1_name.TabIndex = 17;
            this.player1_name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // player2_name
            // 
            this.player2_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.player2_name.Location = new System.Drawing.Point(465, 92);
            this.player2_name.Name = "player2_name";
            this.player2_name.Size = new System.Drawing.Size(250, 50);
            this.player2_name.TabIndex = 18;
            this.player2_name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.player2_name);
            this.Controls.Add(this.player1_name);
            this.Controls.Add(this.label_winnerResult);
            this.Controls.Add(this.label_results_player2);
            this.Controls.Add(this.btn_RollTheDice_player2);
            this.Controls.Add(this.dice5_player2);
            this.Controls.Add(this.dice4_player2);
            this.Controls.Add(this.dice3_player2);
            this.Controls.Add(this.dice2_player2);
            this.Controls.Add(this.dice1_player2);
            this.Controls.Add(this.label_results_player1);
            this.Controls.Add(this.btn_RollTheDice_player1);
            this.Controls.Add(this.dice5_player1);
            this.Controls.Add(this.dice4_player1);
            this.Controls.Add(this.dice3_player1);
            this.Controls.Add(this.dice2_player1);
            this.Controls.Add(this.dice1_player1);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Dice Game";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label dice1_player1;
        private System.Windows.Forms.Label dice2_player1;
        private System.Windows.Forms.Label dice3_player1;
        private System.Windows.Forms.Label dice4_player1;
        private System.Windows.Forms.Label dice5_player1;
        private System.Windows.Forms.Button btn_RollTheDice_player1;
        private System.Windows.Forms.Label label_results_player1;
        private System.Windows.Forms.Label label_results_player2;
        private System.Windows.Forms.Button btn_RollTheDice_player2;
        private System.Windows.Forms.Label dice5_player2;
        private System.Windows.Forms.Label dice4_player2;
        private System.Windows.Forms.Label dice3_player2;
        private System.Windows.Forms.Label dice2_player2;
        private System.Windows.Forms.Label dice1_player2;
        private System.Windows.Forms.Label label_winnerResult;
        private System.Windows.Forms.Label player1_name;
        private System.Windows.Forms.Label player2_name;
    }
}


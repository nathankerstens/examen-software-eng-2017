﻿namespace ShootTargets_Game
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblZombie = new System.Windows.Forms.Label();
            this.lblMissed = new System.Windows.Forms.Label();
            this.lblEnemy = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnRestart = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblGameOver = new System.Windows.Forms.Label();
            this.lblBom = new System.Windows.Forms.Label();
            this.picCharacter = new System.Windows.Forms.PictureBox();
            this.btnDifficulty = new System.Windows.Forms.Button();
            this.btnInstructions = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picCharacter)).BeginInit();
            this.SuspendLayout();
            // 
            // lblZombie
            // 
            this.lblZombie.AutoSize = true;
            this.lblZombie.BackColor = System.Drawing.Color.Transparent;
            this.lblZombie.Font = new System.Drawing.Font("Mechfire", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblZombie.ForeColor = System.Drawing.Color.Lime;
            this.lblZombie.Location = new System.Drawing.Point(13, 13);
            this.lblZombie.Name = "lblZombie";
            this.lblZombie.Size = new System.Drawing.Size(285, 28);
            this.lblZombie.TabIndex = 1;
            this.lblZombie.Text = "Zombie kills = 0";
            // 
            // lblMissed
            // 
            this.lblMissed.AutoSize = true;
            this.lblMissed.BackColor = System.Drawing.Color.Transparent;
            this.lblMissed.Font = new System.Drawing.Font("Mechfire", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMissed.ForeColor = System.Drawing.Color.Lime;
            this.lblMissed.Location = new System.Drawing.Point(13, 99);
            this.lblMissed.Name = "lblMissed";
            this.lblMissed.Size = new System.Drawing.Size(302, 28);
            this.lblMissed.TabIndex = 2;
            this.lblMissed.Text = "Missed shots = 0";
            // 
            // lblEnemy
            // 
            this.lblEnemy.AutoSize = true;
            this.lblEnemy.BackColor = System.Drawing.Color.Transparent;
            this.lblEnemy.Font = new System.Drawing.Font("Mechfire", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEnemy.ForeColor = System.Drawing.Color.Lime;
            this.lblEnemy.Location = new System.Drawing.Point(13, 142);
            this.lblEnemy.Name = "lblEnemy";
            this.lblEnemy.Size = new System.Drawing.Size(139, 28);
            this.lblEnemy.TabIndex = 3;
            this.lblEnemy.Text = "Enemy: ";
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Black;
            this.btnExit.Font = new System.Drawing.Font("Mechfire", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.Lime;
            this.btnExit.Location = new System.Drawing.Point(720, 408);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(118, 57);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnRestart
            // 
            this.btnRestart.BackColor = System.Drawing.Color.Black;
            this.btnRestart.Font = new System.Drawing.Font("Mechfire", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRestart.ForeColor = System.Drawing.Color.Lime;
            this.btnRestart.Location = new System.Drawing.Point(566, 13);
            this.btnRestart.Name = "btnRestart";
            this.btnRestart.Size = new System.Drawing.Size(272, 56);
            this.btnRestart.TabIndex = 5;
            this.btnRestart.Text = "Restart";
            this.btnRestart.UseVisualStyleBackColor = false;
            this.btnRestart.Click += new System.EventHandler(this.btnRestart_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 800;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lblGameOver
            // 
            this.lblGameOver.AutoSize = true;
            this.lblGameOver.BackColor = System.Drawing.Color.Transparent;
            this.lblGameOver.Font = new System.Drawing.Font("Mechfire", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGameOver.ForeColor = System.Drawing.Color.Lime;
            this.lblGameOver.Location = new System.Drawing.Point(188, 424);
            this.lblGameOver.Name = "lblGameOver";
            this.lblGameOver.Size = new System.Drawing.Size(0, 50);
            this.lblGameOver.TabIndex = 6;
            // 
            // lblBom
            // 
            this.lblBom.AutoSize = true;
            this.lblBom.BackColor = System.Drawing.Color.Transparent;
            this.lblBom.Font = new System.Drawing.Font("Mechfire", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBom.ForeColor = System.Drawing.Color.Lime;
            this.lblBom.Location = new System.Drawing.Point(13, 57);
            this.lblBom.Name = "lblBom";
            this.lblBom.Size = new System.Drawing.Size(235, 28);
            this.lblBom.TabIndex = 7;
            this.lblBom.Text = "Bom kills = 0";
            // 
            // picCharacter
            // 
            this.picCharacter.BackColor = System.Drawing.Color.Transparent;
            this.picCharacter.Image = global::ShootTargets_Game.Properties.Resources.Enemy;
            this.picCharacter.Location = new System.Drawing.Point(270, 209);
            this.picCharacter.Name = "picCharacter";
            this.picCharacter.Size = new System.Drawing.Size(170, 150);
            this.picCharacter.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCharacter.TabIndex = 0;
            this.picCharacter.TabStop = false;
            this.picCharacter.Click += new System.EventHandler(this.picCharacter_Click);
            // 
            // btnDifficulty
            // 
            this.btnDifficulty.BackColor = System.Drawing.Color.Black;
            this.btnDifficulty.Font = new System.Drawing.Font("Mechfire", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDifficulty.ForeColor = System.Drawing.Color.Lime;
            this.btnDifficulty.Location = new System.Drawing.Point(566, 75);
            this.btnDifficulty.Name = "btnDifficulty";
            this.btnDifficulty.Size = new System.Drawing.Size(272, 57);
            this.btnDifficulty.TabIndex = 8;
            this.btnDifficulty.Text = "Difficulty";
            this.btnDifficulty.UseVisualStyleBackColor = false;
            this.btnDifficulty.Click += new System.EventHandler(this.btnDifficulty_Click);
            // 
            // btnInstructions
            // 
            this.btnInstructions.BackColor = System.Drawing.Color.Black;
            this.btnInstructions.Font = new System.Drawing.Font("Mechfire", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInstructions.ForeColor = System.Drawing.Color.Lime;
            this.btnInstructions.Location = new System.Drawing.Point(510, 138);
            this.btnInstructions.Name = "btnInstructions";
            this.btnInstructions.Size = new System.Drawing.Size(328, 57);
            this.btnInstructions.TabIndex = 9;
            this.btnInstructions.Text = "Instructions";
            this.btnInstructions.UseVisualStyleBackColor = false;
            this.btnInstructions.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ShootTargets_Game.Properties.Resources.Background;
            this.ClientSize = new System.Drawing.Size(850, 477);
            this.Controls.Add(this.btnInstructions);
            this.Controls.Add(this.btnDifficulty);
            this.Controls.Add(this.lblBom);
            this.Controls.Add(this.lblGameOver);
            this.Controls.Add(this.btnRestart);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblEnemy);
            this.Controls.Add(this.lblMissed);
            this.Controls.Add(this.lblZombie);
            this.Controls.Add(this.picCharacter);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DoubleBuffered = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Shooting Targets Game";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseClick);
            ((System.ComponentModel.ISupportInitialize)(this.picCharacter)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picCharacter;
        private System.Windows.Forms.Label lblZombie;
        private System.Windows.Forms.Label lblMissed;
        private System.Windows.Forms.Label lblEnemy;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnRestart;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblGameOver;
        private System.Windows.Forms.Label lblBom;
        private System.Windows.Forms.Button btnDifficulty;
        private System.Windows.Forms.Button btnInstructions;
    }
}


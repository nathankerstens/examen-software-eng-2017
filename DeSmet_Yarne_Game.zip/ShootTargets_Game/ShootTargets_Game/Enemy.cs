﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShootTargets_Game
{
    class Enemy
    {

        protected string name;

        public string EnemyName
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }

        public string GetEnemyName()
        {
            string result = "Enemy: ";
            result += name;
            return result;
        }

    }
}

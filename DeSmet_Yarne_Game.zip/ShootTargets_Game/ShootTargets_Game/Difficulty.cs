﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShootTargets_Game
{
    public partial class Difficulty : Form
    {
        int number;
        DifficultyClass waarde = new DifficultyClass();

        public Difficulty()
        {
            InitializeComponent();
        }

        private void btnEasy_Click(object sender, EventArgs e)
        {
            number = 1;
            waarde.Number = number;
            Properties.Settings.Default.name = waarde.Number;
            Form MainMenu = new Form1();
            MainMenu.Show();
            Close();
        }

        private void btnMedium_Click(object sender, EventArgs e)
        {
            number = 2;
            waarde.Number = number;
            Properties.Settings.Default.name = waarde.Number;
            Form MainMenu = new Form1();
            MainMenu.Show();
            Close();
        }

        private void btnHard_Click(object sender, EventArgs e)
        {
            number = 3;
            waarde.Number = number;
            Properties.Settings.Default.name = waarde.Number;
            Form MainMenu = new Form1();
            MainMenu.Show();
            Close();
        }
    }
}

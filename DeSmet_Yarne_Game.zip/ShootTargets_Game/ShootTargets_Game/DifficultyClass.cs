﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShootTargets_Game
{
    class DifficultyClass
    {

        protected int number;

        public int Number
        {
            get
            {
                return number;
            }
            set
            {
                number = value;
            }
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShootTargets_Game
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnRestart_Click(object sender, EventArgs e)
        {
            Restart();
        }

        Enemy zombie = new Enemy();
        Enemy bom = new Enemy();

        Random r = new Random();
        Random randomEnemy = new Random();
        int zombieKills = 0;
        int bomKills = 0;
        int missed_shots = 0;
        int getal;

        bool zombieValue = false;
        bool bomValue = false;

        void Sound_Shot()
        {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"D:\School\KdG\MCT2\Module_1\Software_Engeneering\ShootTargets_Game\ShootTargets_Game\Sounds\Shot.wav");
            player.Play();
        }
        
        void Shot()
        {
            if (zombieValue == true)
            {
                zombieKills++;
                lblZombie.Text = "Zombie kills = " + zombieKills;
            } else if (bomValue == true)
            {
                bomKills++;
                lblBom.Text = "Bom kills = " + bomKills;
            }
            
            Sound_Shot();
        }

        void Miss()
        {
            missed_shots++;
            lblMissed.Text = "Missed shots = " + missed_shots;

            Sound_Shot();
        }

        void Restart()
        {
            zombieKills = 0;
            lblZombie.Text = "Zombie kills = " + zombieKills;
            bomKills = 0;
            lblBom.Text = "Bom kills = " + bomKills;
            missed_shots = 0;
            lblMissed.Text = "Missed shots = " + missed_shots;
            timer1.Start();
            lblGameOver.Text = "";
        }
        
        private void timer1_Tick(object sender, EventArgs e)
        {
            int x, y;
            x = r.Next(50, 400);
            y = r.Next(125, 300);

            getal = Properties.Settings.Default.name;
            if (getal == 1)
            {
                timer1.Interval = 800;
            } else if (getal == 2)
            {
                timer1.Interval = 600;
            } else if (getal == 3)
            {
                timer1.Interval = 400;
            }

            int number = randomEnemy.Next(1, 3);
                        
            if (number == 1)
            {
                zombie.EnemyName = "Zombie";
                bomValue = false;
                zombieValue = true;
                lblEnemy.Text = zombie.GetEnemyName();
                picCharacter.Image = Image.FromFile("D:/School/KdG/MCT2/Module_1/Software_Engeneering/ShootTargets_Game/ShootTargets_Game/Images/Enemy.png");
                picCharacter.Location = new Point(x, y);
            }
            else
            {
                bom.EnemyName = "Bom";
                bomValue = true;
                zombieValue = false;
                lblEnemy.Text = bom.GetEnemyName();
                picCharacter.Image = Image.FromFile("D:/School/KdG/MCT2/Module_1/Software_Engeneering/ShootTargets_Game/ShootTargets_Game/Images/Bom.png");
                picCharacter.Location = new Point(x, y);
            }

            if (missed_shots >= 10)
            {
                timer1.Stop();
                lblGameOver.Text = "Game Over";
            }
        }

        private void picCharacter_Click(object sender, EventArgs e)
        {
            Shot();
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            Miss();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnDifficulty_Click(object sender, EventArgs e)
        {
            Form DifficultyForm = new Difficulty();
            DifficultyForm.Show();
            Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form InstructionForm = new Instructions();
            InstructionForm.Show();
            Hide();
        }
    }
}

﻿using System;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace game
{
    class Spel
    {
        int mNbrOfPlayers ;
        int nbrOfTurns = 0;
        int currentPlayer =1;
        bool lastplayer = false;
        

        int[] diceNumbers = new int[5];
        string[] names;

        Player[] player;
        Dobbelsteen[] Dice = new Dobbelsteen[5];
        Random randomDice = new Random();

        public Spel(string[] name, int nbrPlayers)
        {
            mNbrOfPlayers = nbrPlayers;
            names = name;
        }
        public void MakePlayers()
        {
            player = new Player[mNbrOfPlayers];
            
            for (int i = 0; i < mNbrOfPlayers; i++)
            {player[i] = new Player(names[i]);}
        }
        public void MakeDice()
        {
            for (int i = 0; i < Dice.Length; i++)
            {Dice[i] = new Dobbelsteen();}
        }
        public int[] RollDice()
        {

            for (int i = 0; i < 5; i++)
            { diceNumbers[i] = Dice[i].RndDice(randomDice);}
            return diceNumbers;
        }

        public string GetPlayername()
        {
            return player[currentPlayer - 1].GetName();
        }

        public void SetDice(int set)
        {
            Dice[set].SetDice();
        }
        public void UnsetDice(int unset)
        {
            Dice[unset].UnsetDice();
        }
        public int Turns()
        {
            nbrOfTurns++;
            return nbrOfTurns;
        }
        public int ResetTurns()
        {
            nbrOfTurns = 0;
            return nbrOfTurns;
        }
        
        public int CalculateScore(string kindOfScore)
        {
          return  player[currentPlayer - 1].Score(diceNumbers, kindOfScore);
        }
        public bool PlayerUp()
        {
            if (currentPlayer == mNbrOfPlayers )
            {
                lastplayer = true;
                
            }
            else
            {
                currentPlayer += 1;

            }
            return lastplayer;

        }
        public int GetCurrentPlayerCount()
        {
            return currentPlayer;
        }
        public int GetTotal()
        {
            return player[currentPlayer-1].CalculateScore();
        }
        public void ResetGame()
        {
            nbrOfTurns = 0;
            for (int i = 0; i < diceNumbers.Length; i++)
            {
                diceNumbers[i] = 0;
            }
            for (int i = 0; i < Dice.Length; i++)
            {
                Dice[i].ResetDice();
            }
            for (int i = 0; i < player.Length; i++)
            {
                player[i].ResetPlayer(); 
            }
            for (int i = 0; i < names.Length; i++)
            {
                names[i] = "Player" + i;
            }
            for (int i = 0; i < player.Length; i++)
            {
                player[i].SetName(names[i]);
            }
            lastplayer = false;
            currentPlayer = 1;
        }
    }
}

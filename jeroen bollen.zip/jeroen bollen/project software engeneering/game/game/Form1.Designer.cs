﻿namespace game
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.rolldice = new System.Windows.Forms.Button();
            this.currentplayer = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Dice1 = new System.Windows.Forms.PictureBox();
            this.Dice2 = new System.Windows.Forms.PictureBox();
            this.Dice3 = new System.Windows.Forms.PictureBox();
            this.Dice4 = new System.Windows.Forms.PictureBox();
            this.Dice5 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.playername1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.playername2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.playername3 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.setNames = new System.Windows.Forms.Button();
            this.Dice1button = new System.Windows.Forms.Button();
            this.dice2button = new System.Windows.Forms.Button();
            this.dice4button = new System.Windows.Forms.Button();
            this.dice3button = new System.Windows.Forms.Button();
            this.dice5button = new System.Windows.Forms.Button();
            this.nextPlayer = new System.Windows.Forms.Button();
            this.calculatescore = new System.Windows.Forms.Button();
            this.Ones = new System.Windows.Forms.CheckBox();
            this.scoreones = new System.Windows.Forms.Label();
            this.twos = new System.Windows.Forms.CheckBox();
            this.scoreTwos = new System.Windows.Forms.Label();
            this.threes = new System.Windows.Forms.CheckBox();
            this.scoreThrees = new System.Windows.Forms.Label();
            this.Fours = new System.Windows.Forms.CheckBox();
            this.scoreFours = new System.Windows.Forms.Label();
            this.fives = new System.Windows.Forms.CheckBox();
            this.scoreFives = new System.Windows.Forms.Label();
            this.sixes = new System.Windows.Forms.CheckBox();
            this.scoreSixes = new System.Windows.Forms.Label();
            this.Threeofakind = new System.Windows.Forms.CheckBox();
            this.Fourofakind = new System.Windows.Forms.CheckBox();
            this.FullHouse = new System.Windows.Forms.CheckBox();
            this.SmallStraight = new System.Windows.Forms.CheckBox();
            this.Largestraight = new System.Windows.Forms.CheckBox();
            this.chance = new System.Windows.Forms.CheckBox();
            this.scoreThreeofakind = new System.Windows.Forms.Label();
            this.scoreFourofakind = new System.Windows.Forms.Label();
            this.scoreFullHouse = new System.Windows.Forms.Label();
            this.scoreSmallStraight = new System.Windows.Forms.Label();
            this.scoreLargestraight = new System.Windows.Forms.Label();
            this.scorechance = new System.Windows.Forms.Label();
            this.TotalScore = new System.Windows.Forms.Label();
            this.Total = new System.Windows.Forms.Label();
            this.Yahtzee = new System.Windows.Forms.CheckBox();
            this.scoreYahtzee = new System.Windows.Forms.Label();
            this.scorePlayer1 = new System.Windows.Forms.Label();
            this.scorePlayer2 = new System.Windows.Forms.Label();
            this.scorePlayer3 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lbl13 = new System.Windows.Forms.Label();
            this.Player1Nbr = new System.Windows.Forms.Button();
            this.Player2Nbr = new System.Windows.Forms.Button();
            this.Player3Nbr = new System.Windows.Forms.Button();
            this.newGame = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Dice1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice5)).BeginInit();
            this.SuspendLayout();
            // 
            // rolldice
            // 
            this.rolldice.Location = new System.Drawing.Point(611, 350);
            this.rolldice.Name = "rolldice";
            this.rolldice.Size = new System.Drawing.Size(75, 23);
            this.rolldice.TabIndex = 0;
            this.rolldice.Text = "roll dice";
            this.rolldice.UseVisualStyleBackColor = true;
            this.rolldice.Click += new System.EventHandler(this.Button1_Click);
            // 
            // currentplayer
            // 
            this.currentplayer.Location = new System.Drawing.Point(107, 111);
            this.currentplayer.Name = "currentplayer";
            this.currentplayer.Size = new System.Drawing.Size(147, 20);
            this.currentplayer.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 114);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "currentplayer";
            // 
            // Dice1
            // 
            this.Dice1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Dice1.Image = ((System.Drawing.Image)(resources.GetObject("Dice1.Image")));
            this.Dice1.Location = new System.Drawing.Point(310, 181);
            this.Dice1.Name = "Dice1";
            this.Dice1.Size = new System.Drawing.Size(129, 116);
            this.Dice1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Dice1.TabIndex = 3;
            this.Dice1.TabStop = false;
            this.Dice1.Click += new System.EventHandler(this.Dice1_Click);
            // 
            // Dice2
            // 
            this.Dice2.Image = ((System.Drawing.Image)(resources.GetObject("Dice2.Image")));
            this.Dice2.Location = new System.Drawing.Point(445, 181);
            this.Dice2.Name = "Dice2";
            this.Dice2.Size = new System.Drawing.Size(129, 116);
            this.Dice2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Dice2.TabIndex = 3;
            this.Dice2.TabStop = false;
            this.Dice2.Click += new System.EventHandler(this.Dice2_Click);
            // 
            // Dice3
            // 
            this.Dice3.Image = ((System.Drawing.Image)(resources.GetObject("Dice3.Image")));
            this.Dice3.Location = new System.Drawing.Point(580, 181);
            this.Dice3.Name = "Dice3";
            this.Dice3.Size = new System.Drawing.Size(129, 116);
            this.Dice3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Dice3.TabIndex = 3;
            this.Dice3.TabStop = false;
            // 
            // Dice4
            // 
            this.Dice4.Image = ((System.Drawing.Image)(resources.GetObject("Dice4.Image")));
            this.Dice4.Location = new System.Drawing.Point(715, 181);
            this.Dice4.Name = "Dice4";
            this.Dice4.Size = new System.Drawing.Size(129, 116);
            this.Dice4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Dice4.TabIndex = 3;
            this.Dice4.TabStop = false;
            // 
            // Dice5
            // 
            this.Dice5.Image = ((System.Drawing.Image)(resources.GetObject("Dice5.Image")));
            this.Dice5.Location = new System.Drawing.Point(850, 181);
            this.Dice5.Name = "Dice5";
            this.Dice5.Size = new System.Drawing.Size(129, 116);
            this.Dice5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Dice5.TabIndex = 3;
            this.Dice5.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "number of players";
            // 
            // playername1
            // 
            this.playername1.Location = new System.Drawing.Point(106, 60);
            this.playername1.Name = "playername1";
            this.playername1.Size = new System.Drawing.Size(141, 20);
            this.playername1.TabIndex = 6;
            this.playername1.Text = "Player1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "player name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(82, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(13, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "1";
            // 
            // playername2
            // 
            this.playername2.Location = new System.Drawing.Point(364, 60);
            this.playername2.Name = "playername2";
            this.playername2.Size = new System.Drawing.Size(141, 20);
            this.playername2.TabIndex = 6;
            this.playername2.Text = "Player2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(270, 60);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "player name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(340, 60);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(13, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "2";
            // 
            // playername3
            // 
            this.playername3.Location = new System.Drawing.Point(621, 60);
            this.playername3.Name = "playername3";
            this.playername3.Size = new System.Drawing.Size(141, 20);
            this.playername3.TabIndex = 6;
            this.playername3.Text = "Player3";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(527, 60);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "player name";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(597, 60);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(13, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "3";
            // 
            // setNames
            // 
            this.setNames.Location = new System.Drawing.Point(768, 57);
            this.setNames.Name = "setNames";
            this.setNames.Size = new System.Drawing.Size(75, 23);
            this.setNames.TabIndex = 10;
            this.setNames.Text = "setnames";
            this.setNames.UseVisualStyleBackColor = true;
            this.setNames.Click += new System.EventHandler(this.Setnames_Click);
            // 
            // Dice1button
            // 
            this.Dice1button.Location = new System.Drawing.Point(349, 307);
            this.Dice1button.Name = "Dice1button";
            this.Dice1button.Size = new System.Drawing.Size(59, 20);
            this.Dice1button.TabIndex = 11;
            this.Dice1button.Text = "set";
            this.Dice1button.UseVisualStyleBackColor = true;
            this.Dice1button.Click += new System.EventHandler(this.Dice1button_Click);
            // 
            // dice2button
            // 
            this.dice2button.Location = new System.Drawing.Point(477, 307);
            this.dice2button.Name = "dice2button";
            this.dice2button.Size = new System.Drawing.Size(59, 20);
            this.dice2button.TabIndex = 11;
            this.dice2button.Text = "set";
            this.dice2button.UseVisualStyleBackColor = true;
            this.dice2button.Click += new System.EventHandler(this.Dice2button_Click);
            // 
            // dice4button
            // 
            this.dice4button.Location = new System.Drawing.Point(755, 307);
            this.dice4button.Name = "dice4button";
            this.dice4button.Size = new System.Drawing.Size(59, 20);
            this.dice4button.TabIndex = 11;
            this.dice4button.Text = "set";
            this.dice4button.UseVisualStyleBackColor = true;
            this.dice4button.Click += new System.EventHandler(this.Dice4button_Click);
            // 
            // dice3button
            // 
            this.dice3button.Location = new System.Drawing.Point(611, 307);
            this.dice3button.Name = "dice3button";
            this.dice3button.Size = new System.Drawing.Size(71, 21);
            this.dice3button.TabIndex = 12;
            this.dice3button.Text = "set";
            this.dice3button.UseVisualStyleBackColor = true;
            this.dice3button.Click += new System.EventHandler(this.Dice3button_Click);
            // 
            // dice5button
            // 
            this.dice5button.Location = new System.Drawing.Point(889, 307);
            this.dice5button.Name = "dice5button";
            this.dice5button.Size = new System.Drawing.Size(66, 24);
            this.dice5button.TabIndex = 13;
            this.dice5button.Text = "set";
            this.dice5button.UseVisualStyleBackColor = true;
            this.dice5button.Click += new System.EventHandler(this.Dice5button_Click);
            // 
            // nextPlayer
            // 
            this.nextPlayer.Location = new System.Drawing.Point(611, 402);
            this.nextPlayer.Name = "nextPlayer";
            this.nextPlayer.Size = new System.Drawing.Size(77, 23);
            this.nextPlayer.TabIndex = 15;
            this.nextPlayer.Text = "next player";
            this.nextPlayer.UseVisualStyleBackColor = true;
            this.nextPlayer.Click += new System.EventHandler(this.NextPlayer_Click);
            // 
            // calculatescore
            // 
            this.calculatescore.Location = new System.Drawing.Point(62, 375);
            this.calculatescore.Name = "calculatescore";
            this.calculatescore.Size = new System.Drawing.Size(98, 29);
            this.calculatescore.TabIndex = 16;
            this.calculatescore.Text = "calculate score";
            this.calculatescore.UseVisualStyleBackColor = true;
            this.calculatescore.Click += new System.EventHandler(this.Calculatescore_Click);
            // 
            // Ones
            // 
            this.Ones.AutoSize = true;
            this.Ones.Location = new System.Drawing.Point(51, 166);
            this.Ones.Name = "Ones";
            this.Ones.Size = new System.Drawing.Size(51, 17);
            this.Ones.TabIndex = 17;
            this.Ones.Text = "Ones";
            this.Ones.UseVisualStyleBackColor = true;
            this.Ones.CheckedChanged += new System.EventHandler(this.Ones_CheckedChanged);
            // 
            // scoreones
            // 
            this.scoreones.AutoSize = true;
            this.scoreones.Location = new System.Drawing.Point(23, 167);
            this.scoreones.Name = "scoreones";
            this.scoreones.Size = new System.Drawing.Size(13, 13);
            this.scoreones.TabIndex = 18;
            this.scoreones.Text = "0";
            // 
            // twos
            // 
            this.twos.AutoSize = true;
            this.twos.Location = new System.Drawing.Point(51, 189);
            this.twos.Name = "twos";
            this.twos.Size = new System.Drawing.Size(52, 17);
            this.twos.TabIndex = 17;
            this.twos.Text = "Twos";
            this.twos.UseVisualStyleBackColor = true;
            this.twos.CheckedChanged += new System.EventHandler(this.Twos_CheckedChanged);
            // 
            // scoreTwos
            // 
            this.scoreTwos.AutoSize = true;
            this.scoreTwos.Location = new System.Drawing.Point(23, 190);
            this.scoreTwos.Name = "scoreTwos";
            this.scoreTwos.Size = new System.Drawing.Size(13, 13);
            this.scoreTwos.TabIndex = 18;
            this.scoreTwos.Text = "0";
            // 
            // threes
            // 
            this.threes.AutoSize = true;
            this.threes.Location = new System.Drawing.Point(51, 212);
            this.threes.Name = "threes";
            this.threes.Size = new System.Drawing.Size(59, 17);
            this.threes.TabIndex = 17;
            this.threes.Text = "Threes";
            this.threes.UseVisualStyleBackColor = true;
            this.threes.CheckedChanged += new System.EventHandler(this.Threes_CheckedChanged);
            // 
            // scoreThrees
            // 
            this.scoreThrees.AutoSize = true;
            this.scoreThrees.Location = new System.Drawing.Point(23, 213);
            this.scoreThrees.Name = "scoreThrees";
            this.scoreThrees.Size = new System.Drawing.Size(13, 13);
            this.scoreThrees.TabIndex = 18;
            this.scoreThrees.Text = "0";
            // 
            // Fours
            // 
            this.Fours.AutoSize = true;
            this.Fours.Location = new System.Drawing.Point(51, 235);
            this.Fours.Name = "Fours";
            this.Fours.Size = new System.Drawing.Size(52, 17);
            this.Fours.TabIndex = 17;
            this.Fours.Text = "Fours";
            this.Fours.UseVisualStyleBackColor = true;
            this.Fours.CheckedChanged += new System.EventHandler(this.Fours_CheckedChanged);
            // 
            // scoreFours
            // 
            this.scoreFours.AutoSize = true;
            this.scoreFours.Location = new System.Drawing.Point(23, 236);
            this.scoreFours.Name = "scoreFours";
            this.scoreFours.Size = new System.Drawing.Size(13, 13);
            this.scoreFours.TabIndex = 18;
            this.scoreFours.Text = "0";
            // 
            // fives
            // 
            this.fives.AutoSize = true;
            this.fives.Location = new System.Drawing.Point(51, 258);
            this.fives.Name = "fives";
            this.fives.Size = new System.Drawing.Size(51, 17);
            this.fives.TabIndex = 17;
            this.fives.Text = "Fives";
            this.fives.UseVisualStyleBackColor = true;
            this.fives.CheckedChanged += new System.EventHandler(this.Fives_CheckedChanged);
            // 
            // scoreFives
            // 
            this.scoreFives.AutoSize = true;
            this.scoreFives.Location = new System.Drawing.Point(23, 259);
            this.scoreFives.Name = "scoreFives";
            this.scoreFives.Size = new System.Drawing.Size(13, 13);
            this.scoreFives.TabIndex = 18;
            this.scoreFives.Text = "0";
            // 
            // sixes
            // 
            this.sixes.AutoSize = true;
            this.sixes.Location = new System.Drawing.Point(51, 281);
            this.sixes.Name = "sixes";
            this.sixes.Size = new System.Drawing.Size(51, 17);
            this.sixes.TabIndex = 17;
            this.sixes.Text = "Sixes";
            this.sixes.UseVisualStyleBackColor = true;
            this.sixes.CheckedChanged += new System.EventHandler(this.Sixes_CheckedChanged);
            // 
            // scoreSixes
            // 
            this.scoreSixes.AutoSize = true;
            this.scoreSixes.Location = new System.Drawing.Point(23, 282);
            this.scoreSixes.Name = "scoreSixes";
            this.scoreSixes.Size = new System.Drawing.Size(13, 13);
            this.scoreSixes.TabIndex = 18;
            this.scoreSixes.Text = "0";
            // 
            // Threeofakind
            // 
            this.Threeofakind.AutoSize = true;
            this.Threeofakind.Location = new System.Drawing.Point(152, 166);
            this.Threeofakind.Name = "Threeofakind";
            this.Threeofakind.Size = new System.Drawing.Size(102, 17);
            this.Threeofakind.TabIndex = 17;
            this.Threeofakind.Text = "Three Of A Kind";
            this.Threeofakind.UseVisualStyleBackColor = true;
            this.Threeofakind.CheckedChanged += new System.EventHandler(this.Threeofakind_CheckedChanged);
            // 
            // Fourofakind
            // 
            this.Fourofakind.AutoSize = true;
            this.Fourofakind.Location = new System.Drawing.Point(152, 189);
            this.Fourofakind.Name = "Fourofakind";
            this.Fourofakind.Size = new System.Drawing.Size(98, 17);
            this.Fourofakind.TabIndex = 17;
            this.Fourofakind.Text = "Four Of A Kind ";
            this.Fourofakind.UseVisualStyleBackColor = true;
            this.Fourofakind.CheckedChanged += new System.EventHandler(this.Fourofakind_CheckedChanged);
            // 
            // FullHouse
            // 
            this.FullHouse.AutoSize = true;
            this.FullHouse.Location = new System.Drawing.Point(152, 212);
            this.FullHouse.Name = "FullHouse";
            this.FullHouse.Size = new System.Drawing.Size(73, 17);
            this.FullHouse.TabIndex = 17;
            this.FullHouse.Text = "Full Hous ";
            this.FullHouse.UseVisualStyleBackColor = true;
            this.FullHouse.CheckedChanged += new System.EventHandler(this.FullHouse_CheckedChanged);
            // 
            // SmallStraight
            // 
            this.SmallStraight.AutoSize = true;
            this.SmallStraight.Location = new System.Drawing.Point(152, 235);
            this.SmallStraight.Name = "SmallStraight";
            this.SmallStraight.Size = new System.Drawing.Size(88, 17);
            this.SmallStraight.TabIndex = 17;
            this.SmallStraight.Text = "Small straight";
            this.SmallStraight.UseVisualStyleBackColor = true;
            this.SmallStraight.CheckedChanged += new System.EventHandler(this.SmallStraight_CheckedChanged);
            // 
            // Largestraight
            // 
            this.Largestraight.AutoSize = true;
            this.Largestraight.Location = new System.Drawing.Point(152, 258);
            this.Largestraight.Name = "Largestraight";
            this.Largestraight.Size = new System.Drawing.Size(89, 17);
            this.Largestraight.TabIndex = 17;
            this.Largestraight.Text = "LargeStraight";
            this.Largestraight.UseVisualStyleBackColor = true;
            this.Largestraight.CheckedChanged += new System.EventHandler(this.Largestraight_CheckedChanged);
            // 
            // chance
            // 
            this.chance.AutoSize = true;
            this.chance.Location = new System.Drawing.Point(152, 284);
            this.chance.Name = "chance";
            this.chance.Size = new System.Drawing.Size(63, 17);
            this.chance.TabIndex = 17;
            this.chance.Text = "Chance";
            this.chance.UseVisualStyleBackColor = true;
            this.chance.CheckedChanged += new System.EventHandler(this.Chance_CheckedChanged);
            // 
            // scoreThreeofakind
            // 
            this.scoreThreeofakind.AutoSize = true;
            this.scoreThreeofakind.Location = new System.Drawing.Point(124, 167);
            this.scoreThreeofakind.Name = "scoreThreeofakind";
            this.scoreThreeofakind.Size = new System.Drawing.Size(13, 13);
            this.scoreThreeofakind.TabIndex = 18;
            this.scoreThreeofakind.Text = "0";
            // 
            // scoreFourofakind
            // 
            this.scoreFourofakind.AutoSize = true;
            this.scoreFourofakind.Location = new System.Drawing.Point(124, 190);
            this.scoreFourofakind.Name = "scoreFourofakind";
            this.scoreFourofakind.Size = new System.Drawing.Size(13, 13);
            this.scoreFourofakind.TabIndex = 18;
            this.scoreFourofakind.Text = "0";
            // 
            // scoreFullHouse
            // 
            this.scoreFullHouse.AutoSize = true;
            this.scoreFullHouse.Location = new System.Drawing.Point(124, 213);
            this.scoreFullHouse.Name = "scoreFullHouse";
            this.scoreFullHouse.Size = new System.Drawing.Size(13, 13);
            this.scoreFullHouse.TabIndex = 18;
            this.scoreFullHouse.Text = "0";
            // 
            // scoreSmallStraight
            // 
            this.scoreSmallStraight.AutoSize = true;
            this.scoreSmallStraight.Location = new System.Drawing.Point(124, 236);
            this.scoreSmallStraight.Name = "scoreSmallStraight";
            this.scoreSmallStraight.Size = new System.Drawing.Size(13, 13);
            this.scoreSmallStraight.TabIndex = 18;
            this.scoreSmallStraight.Text = "0";
            // 
            // scoreLargestraight
            // 
            this.scoreLargestraight.AutoSize = true;
            this.scoreLargestraight.Location = new System.Drawing.Point(124, 259);
            this.scoreLargestraight.Name = "scoreLargestraight";
            this.scoreLargestraight.Size = new System.Drawing.Size(13, 13);
            this.scoreLargestraight.TabIndex = 18;
            this.scoreLargestraight.Text = "0";
            // 
            // scorechance
            // 
            this.scorechance.AutoSize = true;
            this.scorechance.Location = new System.Drawing.Point(124, 285);
            this.scorechance.Name = "scorechance";
            this.scorechance.Size = new System.Drawing.Size(13, 13);
            this.scorechance.TabIndex = 18;
            this.scorechance.Text = "0";
            // 
            // TotalScore
            // 
            this.TotalScore.AutoSize = true;
            this.TotalScore.Location = new System.Drawing.Point(77, 350);
            this.TotalScore.Name = "TotalScore";
            this.TotalScore.Size = new System.Drawing.Size(13, 13);
            this.TotalScore.TabIndex = 18;
            this.TotalScore.Text = "0";
            // 
            // Total
            // 
            this.Total.AutoSize = true;
            this.Total.Location = new System.Drawing.Point(109, 350);
            this.Total.Name = "Total";
            this.Total.Size = new System.Drawing.Size(31, 13);
            this.Total.TabIndex = 19;
            this.Total.Text = "Total";
            // 
            // Yahtzee
            // 
            this.Yahtzee.AutoSize = true;
            this.Yahtzee.Location = new System.Drawing.Point(152, 307);
            this.Yahtzee.Name = "Yahtzee";
            this.Yahtzee.Size = new System.Drawing.Size(65, 17);
            this.Yahtzee.TabIndex = 17;
            this.Yahtzee.Text = "Yahtzee";
            this.Yahtzee.UseVisualStyleBackColor = true;
            this.Yahtzee.CheckedChanged += new System.EventHandler(this.Yahtzee_CheckedChanged);
            // 
            // scoreYahtzee
            // 
            this.scoreYahtzee.AutoSize = true;
            this.scoreYahtzee.Location = new System.Drawing.Point(124, 308);
            this.scoreYahtzee.Name = "scoreYahtzee";
            this.scoreYahtzee.Size = new System.Drawing.Size(13, 13);
            this.scoreYahtzee.TabIndex = 18;
            this.scoreYahtzee.Text = "0";
            // 
            // scorePlayer1
            // 
            this.scorePlayer1.AutoSize = true;
            this.scorePlayer1.Location = new System.Drawing.Point(104, 86);
            this.scorePlayer1.Name = "scorePlayer1";
            this.scorePlayer1.Size = new System.Drawing.Size(13, 13);
            this.scorePlayer1.TabIndex = 20;
            this.scorePlayer1.Text = "0";
            // 
            // scorePlayer2
            // 
            this.scorePlayer2.AutoSize = true;
            this.scorePlayer2.Location = new System.Drawing.Point(361, 86);
            this.scorePlayer2.Name = "scorePlayer2";
            this.scorePlayer2.Size = new System.Drawing.Size(13, 13);
            this.scorePlayer2.TabIndex = 20;
            this.scorePlayer2.Text = "0";
            // 
            // scorePlayer3
            // 
            this.scorePlayer3.AutoSize = true;
            this.scorePlayer3.Location = new System.Drawing.Point(618, 86);
            this.scorePlayer3.Name = "scorePlayer3";
            this.scorePlayer3.Size = new System.Drawing.Size(13, 13);
            this.scorePlayer3.TabIndex = 20;
            this.scorePlayer3.Text = "0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(23, 86);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 13);
            this.label12.TabIndex = 21;
            this.label12.Text = "scoreplayer1";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(286, 86);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(67, 13);
            this.label13.TabIndex = 21;
            this.label13.Text = "scoreplayer2";
            // 
            // lbl13
            // 
            this.lbl13.AutoSize = true;
            this.lbl13.Location = new System.Drawing.Point(537, 86);
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(73, 13);
            this.lbl13.TabIndex = 21;
            this.lbl13.Text = "score player 3";
            // 
            // Player1Nbr
            // 
            this.Player1Nbr.Location = new System.Drawing.Point(112, 24);
            this.Player1Nbr.Name = "Player1Nbr";
            this.Player1Nbr.Size = new System.Drawing.Size(113, 27);
            this.Player1Nbr.TabIndex = 22;
            this.Player1Nbr.Text = "1 player";
            this.Player1Nbr.UseVisualStyleBackColor = true;
            this.Player1Nbr.Click += new System.EventHandler(this.Player1Nbr_Click);
            // 
            // Player2Nbr
            // 
            this.Player2Nbr.Location = new System.Drawing.Point(240, 24);
            this.Player2Nbr.Name = "Player2Nbr";
            this.Player2Nbr.Size = new System.Drawing.Size(113, 27);
            this.Player2Nbr.TabIndex = 22;
            this.Player2Nbr.Text = "2 players";
            this.Player2Nbr.UseVisualStyleBackColor = true;
            this.Player2Nbr.Click += new System.EventHandler(this.Player2Nbr_Click);
            // 
            // Player3Nbr
            // 
            this.Player3Nbr.Location = new System.Drawing.Point(374, 24);
            this.Player3Nbr.Name = "Player3Nbr";
            this.Player3Nbr.Size = new System.Drawing.Size(113, 27);
            this.Player3Nbr.TabIndex = 22;
            this.Player3Nbr.Text = "3 players";
            this.Player3Nbr.UseVisualStyleBackColor = true;
            this.Player3Nbr.Click += new System.EventHandler(this.Player3Nbr_Click);
            // 
            // newGame
            // 
            this.newGame.Location = new System.Drawing.Point(781, 367);
            this.newGame.Name = "newGame";
            this.newGame.Size = new System.Drawing.Size(145, 58);
            this.newGame.TabIndex = 23;
            this.newGame.Text = "New Game";
            this.newGame.UseVisualStyleBackColor = true;
            this.newGame.Click += new System.EventHandler(this.newGame_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(999, 491);
            this.Controls.Add(this.newGame);
            this.Controls.Add(this.Player3Nbr);
            this.Controls.Add(this.Player2Nbr);
            this.Controls.Add(this.Player1Nbr);
            this.Controls.Add(this.lbl13);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.scorePlayer3);
            this.Controls.Add(this.scorePlayer2);
            this.Controls.Add(this.scorePlayer1);
            this.Controls.Add(this.Total);
            this.Controls.Add(this.TotalScore);
            this.Controls.Add(this.scoreYahtzee);
            this.Controls.Add(this.scorechance);
            this.Controls.Add(this.scoreSixes);
            this.Controls.Add(this.scoreLargestraight);
            this.Controls.Add(this.scoreFives);
            this.Controls.Add(this.scoreSmallStraight);
            this.Controls.Add(this.scoreFours);
            this.Controls.Add(this.scoreFullHouse);
            this.Controls.Add(this.scoreThrees);
            this.Controls.Add(this.scoreFourofakind);
            this.Controls.Add(this.scoreTwos);
            this.Controls.Add(this.scoreThreeofakind);
            this.Controls.Add(this.scoreones);
            this.Controls.Add(this.Yahtzee);
            this.Controls.Add(this.chance);
            this.Controls.Add(this.sixes);
            this.Controls.Add(this.Largestraight);
            this.Controls.Add(this.SmallStraight);
            this.Controls.Add(this.fives);
            this.Controls.Add(this.FullHouse);
            this.Controls.Add(this.Fours);
            this.Controls.Add(this.Fourofakind);
            this.Controls.Add(this.threes);
            this.Controls.Add(this.Threeofakind);
            this.Controls.Add(this.twos);
            this.Controls.Add(this.Ones);
            this.Controls.Add(this.calculatescore);
            this.Controls.Add(this.nextPlayer);
            this.Controls.Add(this.dice5button);
            this.Controls.Add(this.dice3button);
            this.Controls.Add(this.dice4button);
            this.Controls.Add(this.dice2button);
            this.Controls.Add(this.Dice1button);
            this.Controls.Add(this.setNames);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.playername3);
            this.Controls.Add(this.playername2);
            this.Controls.Add(this.playername1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Dice5);
            this.Controls.Add(this.Dice4);
            this.Controls.Add(this.Dice3);
            this.Controls.Add(this.Dice2);
            this.Controls.Add(this.Dice1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.currentplayer);
            this.Controls.Add(this.rolldice);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Dice1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button rolldice;
        private System.Windows.Forms.TextBox currentplayer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox Dice1;
        private System.Windows.Forms.PictureBox Dice2;
        private System.Windows.Forms.PictureBox Dice3;
        private System.Windows.Forms.PictureBox Dice4;
        private System.Windows.Forms.PictureBox Dice5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox playername1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox playername2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox playername3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button setNames;
        private System.Windows.Forms.Button Dice1button;
        private System.Windows.Forms.Button dice2button;
        private System.Windows.Forms.Button dice4button;
        private System.Windows.Forms.Button dice3button;
        private System.Windows.Forms.Button dice5button;
        private System.Windows.Forms.Button nextPlayer;
        private System.Windows.Forms.Button calculatescore;
        private System.Windows.Forms.CheckBox Ones;
        private System.Windows.Forms.Label scoreones;
        private System.Windows.Forms.CheckBox twos;
        private System.Windows.Forms.Label scoreTwos;
        private System.Windows.Forms.CheckBox threes;
        private System.Windows.Forms.Label scoreThrees;
        private System.Windows.Forms.CheckBox Fours;
        private System.Windows.Forms.Label scoreFours;
        private System.Windows.Forms.CheckBox fives;
        private System.Windows.Forms.Label scoreFives;
        private System.Windows.Forms.CheckBox sixes;
        private System.Windows.Forms.Label scoreSixes;
        private System.Windows.Forms.CheckBox Threeofakind;
        private System.Windows.Forms.CheckBox Fourofakind;
        private System.Windows.Forms.CheckBox FullHouse;
        private System.Windows.Forms.CheckBox SmallStraight;
        private System.Windows.Forms.CheckBox Largestraight;
        private System.Windows.Forms.CheckBox chance;
        private System.Windows.Forms.Label scoreThreeofakind;
        private System.Windows.Forms.Label scoreFourofakind;
        private System.Windows.Forms.Label scoreFullHouse;
        private System.Windows.Forms.Label scoreSmallStraight;
        private System.Windows.Forms.Label scoreLargestraight;
        private System.Windows.Forms.Label scorechance;
        private System.Windows.Forms.Label TotalScore;
        private System.Windows.Forms.Label Total;
        private System.Windows.Forms.CheckBox Yahtzee;
        private System.Windows.Forms.Label scoreYahtzee;
        private System.Windows.Forms.Label scorePlayer1;
        private System.Windows.Forms.Label scorePlayer2;
        private System.Windows.Forms.Label scorePlayer3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lbl13;
        private System.Windows.Forms.Button Player1Nbr;
        private System.Windows.Forms.Button Player2Nbr;
        private System.Windows.Forms.Button Player3Nbr;
        private System.Windows.Forms.Button newGame;
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace game
{
    class Dobbelsteen
    {
        
        bool setDice= false;
        int settedDice;
       
        public int RndDice(Random diceRnd)
        {
            // calculate the value of each dice 
            if (!setDice)
            {
                settedDice = diceRnd.Next(1, 7);
                return settedDice;
            }
            else
            {
                return settedDice;
            }
            
        }
        public void SetDice()
        {
            setDice = true;
        }
        public void UnsetDice()
        {
            setDice = false;
        }
        public void ResetDice()
        {
            settedDice = 0;
            setDice = false;
        }
    }
    
}

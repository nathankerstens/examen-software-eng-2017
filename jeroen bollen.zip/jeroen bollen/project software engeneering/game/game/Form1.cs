﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace game
{
    public partial class Form1 : Form
    {
        Spel spel;
        int nbrOfTurns = 0;
        bool lastplayerturn = false;
        int currentplayercount = 1;
        int nbrOfPlayers = 1;

        int[] diceNumbers = new int[5];
        bool[] settedDice = new bool[5];
        string[] playerNames;

        PictureBox[] dicesImages = new PictureBox[5];
        CheckBox[] typeOfscore = new CheckBox[13];
        Button[] diceButtons = new Button[5];
        Label[] scores = new Label[14];
        Label[] currentplayersum = new Label[3];

        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            diceButtons[0] = Dice1button;
            diceButtons[1] = dice2button;
            diceButtons[2] = dice3button;
            diceButtons[3] = dice4button;
            diceButtons[4] = dice5button;

            for (int i = 0; i < diceButtons.Length; i++)
            {
                diceButtons[i].Enabled = false;
            }

            dicesImages[0] = Dice1;
            dicesImages[1] = Dice2;
            dicesImages[2] = Dice3;
            dicesImages[3] = Dice4;
            dicesImages[4] = Dice5;


            typeOfscore[0] = Ones;
            typeOfscore[1] = twos;
            typeOfscore[2] = threes;
            typeOfscore[3] = Fours;
            typeOfscore[4] = fives;
            typeOfscore[5] = sixes;
            typeOfscore[6] = Threeofakind;
            typeOfscore[7] = Fourofakind;
            typeOfscore[8] = FullHouse;
            typeOfscore[9] = SmallStraight;
            typeOfscore[10] = Largestraight;
            typeOfscore[11] = chance;
            typeOfscore[12] = Yahtzee;
           

            scores[0] = scoreones;
            scores[1] = scoreTwos;
            scores[2] = scoreThrees;
            scores[3] = scoreFours;
            scores[4] = scoreFives;
            scores[5] = scoreSixes;
            scores[6] = scoreThreeofakind;
            scores[7] = scoreFourofakind;
            scores[8] = scoreFullHouse;
            scores[9] = scoreSmallStraight;
            scores[10] = scoreLargestraight;
            scores[11] = scorechance;
            scores[12] = scoreYahtzee;
            scores[13] = TotalScore;

            currentplayersum[0] = scorePlayer1;
            currentplayersum[1] = scorePlayer2;
            currentplayersum[2] = scorePlayer3;

            setNames.Enabled = false;
            rolldice.Enabled = false;
            nextPlayer.Enabled = false;
            calculatescore.Enabled = false;
            newGame.Enabled = false;

        }
        private void Button1_Click(object sender, EventArgs e)
        {


            nbrOfTurns = spel.Turns();
            if (nbrOfTurns == 3) { rolldice.Enabled = false; }
            diceNumbers = spel.RollDice();
            for (int i = 0; i < diceNumbers.Length; i++)
            {
                switch (diceNumbers[i])
                {
                    case 1:
                        dicesImages[i].Image = Properties.Resources._1c;
                        break;
                    case 2:
                        dicesImages[i].Image = Properties.Resources._2c;
                        break;
                    case 3:
                        dicesImages[i].Image = Properties.Resources._3c;
                        break;

                    case 4:
                        dicesImages[i].Image = Properties.Resources.Dobbelsteen4;
                        break;

                    case 5:
                        dicesImages[i].Image = Properties.Resources._5c;
                        break;

                    case 6:
                        dicesImages[i].Image = Properties.Resources.dobbel6;
                        break;
                }
            }
            for (int i = 0; i < diceButtons.Length; i++)
            {
                diceButtons[i].Enabled = true;
            }


        }


        private void Setnames_Click(object sender, EventArgs e)
        {
            
            rolldice.Enabled = true;
            newGame.Enabled = true;
            playerNames = new string[nbrOfPlayers];

            if (nbrOfPlayers >= 1)
            {
                playerNames[0] = playername1.Text;
            }
            if (nbrOfPlayers >= 2)
            {
                playerNames[1] = playername2.Text;
            }
            if (nbrOfPlayers == 3)
            {
                playerNames[2] = playername3.Text;
            }
            for (int i = 0; i < settedDice.Length; i++)
            {
                settedDice[i] = false;
            }
            spel = new Spel(playerNames, nbrOfPlayers);
            spel.MakeDice();
            spel.MakePlayers();
            currentplayer.Text = spel.GetPlayername();
        }





        private void Dice1button_Click(object sender, EventArgs e)
        {
            Dice1button.Text = "saved";
            spel.SetDice(0);
        }
        private void Dice2button_Click(object sender, EventArgs e)
        {
            dice2button.Text = "saved";
            spel.SetDice(1);
        }
        private void Dice3button_Click(object sender, EventArgs e)
        {
            dice3button.Text = "saved";
            spel.SetDice(2);
        }
        private void Dice4button_Click(object sender, EventArgs e)
        {
            dice4button.Text = "saved";
            spel.SetDice(3);
        }
        private void Dice5button_Click(object sender, EventArgs e)
        {
            dice5button.Text = "saved";
            spel.SetDice(4);
        }
        private void Dice1_Click(object sender, EventArgs e)
        {

        }
        private void Dice2_Click(object sender, EventArgs e)
        {

        }

        private void Calculatescore_Click(object sender, EventArgs e)
        {

            if (Ones.Checked)
            {
                scoreones.Text = spel.CalculateScore("ones").ToString();
                Ones.Checked = false;
                Ones.Enabled = false;
                nbrOfTurns = spel.ResetTurns();
                rolldice.Enabled = true;
                calculatescore.Enabled = false;
            }
            else if (twos.Checked)
            {
                scoreTwos.Text = spel.CalculateScore("twos").ToString();
                twos.Checked = false;
                twos.Enabled = false;
                nbrOfTurns = spel.ResetTurns();
                rolldice.Enabled = true;
                calculatescore.Enabled = false;
            }
            else if (threes.Checked)
            {
                scoreThrees.Text = spel.CalculateScore("threes").ToString();
                threes.Checked = false;
                threes.Enabled = false;
                nbrOfTurns = spel.ResetTurns();
                rolldice.Enabled = true;
                calculatescore.Enabled = false;
            }
            else if (Fours.Checked)
            {
                scoreFours.Text = spel.CalculateScore("fours").ToString();
                Fours.Checked = false;
                Fours.Enabled = false;
                nbrOfTurns = spel.ResetTurns();
                rolldice.Enabled = true;
                calculatescore.Enabled = false;
            }
            else if (fives.Checked)
            {
                scoreFives.Text = spel.CalculateScore("fives").ToString();
                fives.Checked = false;
                fives.Enabled = false;
                nbrOfTurns = spel.ResetTurns();
                rolldice.Enabled = true;
                calculatescore.Enabled = false;

            }
            else if (sixes.Checked)
            {
                scoreSixes.Text = spel.CalculateScore("sixes").ToString();
                sixes.Checked = false;
                sixes.Enabled = false;
                nbrOfTurns = spel.ResetTurns();
                rolldice.Enabled = true;
                calculatescore.Enabled = false;
            }
            else if (Threeofakind.Checked)
            {
                scoreThreeofakind.Text = spel.CalculateScore("threeofakind").ToString();
                Threeofakind.Checked = false;
                Threeofakind.Enabled = false;
                nbrOfTurns = spel.ResetTurns();
                rolldice.Enabled = true;
                calculatescore.Enabled = false;
            }
            else if (Fourofakind.Checked)
            {
                scoreFourofakind.Text = spel.CalculateScore("fourofakind").ToString();
                Fourofakind.Checked = false;
                Fourofakind.Enabled = false;
                nbrOfTurns = spel.ResetTurns();
                rolldice.Enabled = true;
                calculatescore.Enabled = false;
            }
            else if (FullHouse.Checked)
            {
                scoreFullHouse.Text = spel.CalculateScore("fullhous").ToString();
                FullHouse.Checked = false;
                FullHouse.Enabled = false;
                nbrOfTurns = spel.ResetTurns();
                rolldice.Enabled = true;
                calculatescore.Enabled = false;
            }
            else if (SmallStraight.Checked)
            {
                scoreSmallStraight.Text = spel.CalculateScore("smallstraight").ToString();
                SmallStraight.Checked = false;
                SmallStraight.Enabled = false;
                nbrOfTurns = spel.ResetTurns();
                rolldice.Enabled = true;
                calculatescore.Enabled = false;
            }
            else if (Largestraight.Checked)
            {
                scoreLargestraight.Text = spel.CalculateScore("largestraight").ToString();
                Largestraight.Checked = false;
                Largestraight.Enabled = false;
                nbrOfTurns = spel.ResetTurns();
                rolldice.Enabled = true;
                calculatescore.Enabled = false;
            }
            else if (chance.Checked)
            {
                scorechance.Text = spel.CalculateScore("chance").ToString();
                chance.Checked = false;
                chance.Enabled = false;
                nbrOfTurns = spel.ResetTurns();
                rolldice.Enabled = true;
                calculatescore.Enabled = false;
            }
            else if (Yahtzee.Checked)
            {
                scoreYahtzee.Text = spel.CalculateScore("yahtzee").ToString();
                Yahtzee.Checked = false;
                Yahtzee.Enabled = false;
                nbrOfTurns = spel.ResetTurns();
                rolldice.Enabled = true;
                calculatescore.Enabled = false;
            }
            for (int i = 0; i < diceButtons.Length; i++)
            {
                spel.UnsetDice(i);
                diceButtons[i].Text = "set";
                diceButtons[i].Enabled = false;
            }

            TotalScore.Text = spel.GetTotal().ToString();
            currentplayersum[currentplayercount - 1].Text = spel.GetTotal().ToString();
            nextPlayer.Enabled = true;
        }

        private void Ones_CheckedChanged(object sender, EventArgs e)
        {
            if (Ones.Checked)
            {
                calculatescore.Enabled = true;
            }
        }

        private void Twos_CheckedChanged(object sender, EventArgs e)
        {
            if (twos.Checked)
            {
                calculatescore.Enabled = true;
            }
        }

        private void Threes_CheckedChanged(object sender, EventArgs e)
        {
            if (threes.Checked)
            {
                calculatescore.Enabled = true;
            }
        }

        private void Fours_CheckedChanged(object sender, EventArgs e)
        {
            if (Fours.Checked)
            {
                calculatescore.Enabled = true;
            }
        }

        private void Fives_CheckedChanged(object sender, EventArgs e)
        {
            if (fives.Checked)
            {
                calculatescore.Enabled = true;
            }
        }

        private void Sixes_CheckedChanged(object sender, EventArgs e)
        {
            if (sixes.Checked)
            {
                calculatescore.Enabled = true;
            }
        }

        private void Threeofakind_CheckedChanged(object sender, EventArgs e)
        {
            if (Threeofakind.Checked)
            {
                calculatescore.Enabled = true;
            }
        }

        private void Fourofakind_CheckedChanged(object sender, EventArgs e)
        {
            if (Fourofakind.Checked)
            {
                calculatescore.Enabled = true;
            }
        }

        private void FullHouse_CheckedChanged(object sender, EventArgs e)
        {
            if (FullHouse.Checked)
            {
                calculatescore.Enabled = true;
            }
        }

        private void SmallStraight_CheckedChanged(object sender, EventArgs e)
        {
            if (SmallStraight.Checked)
            {
                calculatescore.Enabled = true;
            }
        }

        private void Largestraight_CheckedChanged(object sender, EventArgs e)
        {
            if (Largestraight.Checked)
            {
                calculatescore.Enabled = true;
            }
        }

        private void Chance_CheckedChanged(object sender, EventArgs e)
        {
            if (chance.Checked)
            {
                calculatescore.Enabled = true;
            }
        }

        private void Yahtzee_CheckedChanged(object sender, EventArgs e)
        {
            if (Yahtzee.Checked)
            {
                calculatescore.Enabled = true;
            }
        }

        private void NextPlayer_Click(object sender, EventArgs e)
        {
            lastplayerturn = spel.PlayerUp();
            if (lastplayerturn)
            {
                MessageBox.Show("spel is gedaan");
                rolldice.Enabled = false;
            }
            else
            {
                resetScoreLabels();
                currentplayer.Text = spel.GetPlayername();
            }


            currentplayercount = spel.GetCurrentPlayerCount();
            nextPlayer.Enabled = false;

        }

        private void Player1Nbr_Click(object sender, EventArgs e)
        {
            nbrOfPlayers = 1;

            Player1Nbr.BackColor = Color.Yellow;
            setNames.Enabled = true;
            DisablePlayerNbr();
        }

        private void Player2Nbr_Click(object sender, EventArgs e)
        {
            nbrOfPlayers = 2;
            Player2Nbr.BackColor = Color.Yellow;
            setNames.Enabled = true;
            DisablePlayerNbr();
        }

        private void Player3Nbr_Click(object sender, EventArgs e)
        {
            nbrOfPlayers = 3;
            Player3Nbr.BackColor = Color.Yellow;
            setNames.Enabled = true;
            DisablePlayerNbr();
            
        }

        private void newGame_Click(object sender, EventArgs e)
        {
            setNames.Enabled = false;
            newGame.Enabled = false;
            scorePlayer1.Text = "0";
            scorePlayer2.Text = "0";
            scorePlayer3.Text = "0";
            spel.ResetGame();
            resetScoreLabels();
            EnablePlayerNbr();
        }
        private void resetScoreLabels()
        {
            for (int i = 0; i < typeOfscore.Length; i++)
            {
                typeOfscore[i].Enabled = true;
            }
            for (int i = 0; i < scores.Length; i++)
            {
                scores[i].Text = "0";
            }
        }
        private void resetSet()
        {
            for (int i = 0; i < diceButtons.Length; i++)
            {
                spel.UnsetDice(i);
                diceButtons[i].Text = "set";
                diceButtons[i].Enabled = false;
            }
        }
        private void DisablePlayerNbr()
        {
            Player1Nbr.Enabled = false;
            Player2Nbr.Enabled = false;
            Player3Nbr.Enabled = false;
        }
        private void EnablePlayerNbr()
        {
            Player1Nbr.Enabled = true;
            Player2Nbr.Enabled = true;
            Player3Nbr.Enabled = true;
            Player1Nbr.BackColor = default(Color);
            Player2Nbr.BackColor = default(Color);
            Player3Nbr.BackColor = default(Color);
        }
    }
}

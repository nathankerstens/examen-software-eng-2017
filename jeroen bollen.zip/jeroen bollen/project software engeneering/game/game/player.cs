﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace game
{
    class Player
    {
        string mPlayername;
        int ones, twos, threes, fours, fives, sixes, threeOfAKind, FourOfAKind, smallStraight, LargeStraight, fullHous, chance, Yahtzee, sum = 0;
        bool threeOfAKindBool, FourOfAKindBool, yahtzeebool;

        int[] numberBuffer = new int[5];

        public Player(string name )
        {
            //constructor
            mPlayername = name;
        }
        public  string GetName()
        {
            // return the name of the player
            return mPlayername;
        }
        public void SetName(string name)
        {
            mPlayername = name;
        }
        public int Score(int[] numbers, string kindOfScore)
        {
            // punten berekenen van welk type score er is ingegeven , zijn standaard 0 als -1 word teruggegeven , fout met berekenen 
            if (kindOfScore == "ones")
            {
                for (int i = 0; i < numbers.Length; i++)
                {
                    if (numbers[i] == 1){ones += numbers[i];}
                }
                return ones;
            }

            if (kindOfScore == "twos")
            {
                for (int i = 0; i < numbers.Length; i++)
                {
                    if (numbers[i] == 2){twos += numbers[i];}
                }
                return twos;
            }

            if (kindOfScore == "threes")
            {
                for (int i = 0; i < numbers.Length; i++)
                {
                    if (numbers[i] == 3)
                    {threes += numbers[i];}
                }
                return threes;
            }

            if (kindOfScore == "fours")
            {
                for (int i = 0; i < numbers.Length; i++)
                {
                    if (numbers[i] == 4)
                    {fours += numbers[i];}
                }
                return fours;
            }

            if (kindOfScore == "fives")
            {
                for (int i = 0; i < numbers.Length; i++)
                {
                    if (numbers[i] == 5)
                    {fives += numbers[i];}
                }
                return fives;
            }

            if (kindOfScore == "sixes")
            {
                for (int i = 0; i < numbers.Length; i++)
                {
                    if (numbers[i] == 6)
                    {sixes += numbers[i];}
                }
                return sixes;
            }

            if (kindOfScore == "threeofakind")
            {
                for (int i = 1; i <= 6; i++)
                {
                    int count = 0;
                    for (int j = 0; j < 5; j++)
                    {
                        if (numbers[j] == i)
                        {count++;}
                        if (count > 2)
                        {threeOfAKindBool = true;}
                    }
                }

                if (threeOfAKindBool)
                {
                    for (int i = 0; i < numbers.Length; i++)
                    {threeOfAKind += numbers[i];}
                }
                return threeOfAKind;
            }
            if (kindOfScore == "fourofakind")
            {
                for (int i = 1; i <= 6; i++)
                {
                    int count = 0;
                    for (int j = 0; j < 5; j++)
                    {
                        if (numbers[j] == i)
                        {count++;}
                        if (count > 3)
                        { FourOfAKindBool = true; }
                    }
                }
                if (FourOfAKindBool)
                {
                    for (int i = 0; i < numbers.Length; i++)
                    {
                        FourOfAKind += numbers[i];
                    }
                }
                return FourOfAKind;
            }
            if (kindOfScore == "fullhous")
            {
                for (int i = 0; i < numbers.Length; i++)
                {
                    numberBuffer[i] = numbers[i];
                }
                Array.Sort(numberBuffer);
                if ((((numberBuffer[0] == numberBuffer[1]) && (numberBuffer[1] == numberBuffer[2])) && // Three of a Kind
                        (numberBuffer[3] == numberBuffer[4]) && // Two of a Kind
                        (numberBuffer[2] != numberBuffer[3])) ||
                        ((numberBuffer[0] == numberBuffer[1]) && // Two of a Kind
                        ((numberBuffer[2] == numberBuffer[3]) && (numberBuffer[3] == numberBuffer[4])) && // Three of a Kind
                        (numberBuffer[1] != numberBuffer[2])))
                {
                    fullHous = 25;
                }
                return fullHous;
            }
            if (kindOfScore == "smallstraight")
            {
                for (int i = 0; i < numbers.Length; i++)
                {
                    numberBuffer[i] = numbers[i];
                }
                Array.Sort(numberBuffer);

                for (int j = 0; j < 4; j++)
                {
                    int temp = 0;
                    if (numberBuffer[j] == numberBuffer[j + 1])
                    {
                        temp = numberBuffer[j];

                        for (int k = j; k < 4; k++)
                        {
                            numberBuffer[k] = numberBuffer[k + 1];
                        }

                        numberBuffer[4] = temp;
                    }
                }

                if (((numberBuffer[0] == 1) && (numberBuffer[1] == 2) && (numberBuffer[2] == 3) && (numberBuffer[3] == 4)) ||
                    ((numberBuffer[0] == 2) && (numberBuffer[1] == 3) && (numberBuffer[2] == 4) && (numberBuffer[3] == 5)) ||
                    ((numberBuffer[0] == 3) && (numberBuffer[1] == 4) && (numberBuffer[2] == 5) && (numberBuffer[3] == 6)) ||
                    ((numberBuffer[1] == 1) && (numberBuffer[2] == 2) && (numberBuffer[3] == 3) && (numberBuffer[4] == 4)) ||
                    ((numberBuffer[1] == 2) && (numberBuffer[2] == 3) && (numberBuffer[3] == 4) && (numberBuffer[4] == 5)) ||
                    ((numberBuffer[1] == 3) && (numberBuffer[2] == 4) && (numberBuffer[3] == 5) && (numberBuffer[4] == 6)))
                {
                    smallStraight = 30;
                }
                return smallStraight;
            }
            if (kindOfScore == "largestraight")
            {
                for (int i = 0; i < numbers.Length; i++)
                {
                    numberBuffer[i] = numbers[i];
                }
                Array.Sort(numberBuffer);

                if (((numberBuffer[0] == 1) &&
                    (numberBuffer[1] == 2) &&
                    (numberBuffer[2] == 3) &&
                    (numberBuffer[3] == 4) &&
                    (numberBuffer[4] == 5)) ||
                    ((numberBuffer[0] == 2) &&
                    (numberBuffer[1] == 3) &&
                    (numberBuffer[2] == 4) &&
                    (numberBuffer[3] == 5) &&
                    (numberBuffer[4] == 6)))
                {
                    LargeStraight = 40;
                }
                return LargeStraight;
            }
            if (kindOfScore == "chance")
            {
                for (int i = 0; i < numbers.Length; i++)
                {
                    chance += numbers[i];
                }
                return chance;
            }
            if (kindOfScore == "yahtzee")
            {
                for (int i = 1; i <= 6; i++)
                {
                    int count = 0;
                    for (int j = 0; j < 5; j++)
                    {
                        if (numbers[j] == i)
                        { count++; }
                        if (count == 5)
                        { yahtzeebool = true; }
                    }
                }

                if (yahtzeebool)
                {
                     Yahtzee  = 50; 
                }
                return Yahtzee;
            }
            return -1;
         }

        public int CalculateScore()
        {
            //totale waarde megeeven van de juiste speler 
            sum = ones + twos + threes + fours + fives + sixes + threeOfAKind + FourOfAKind + fullHous + smallStraight + LargeStraight + chance + Yahtzee;
            return sum;
        }
        public void ResetPlayer()
        {
            // reset values
            ones = 0;
            twos = 0;
            threes = 0;
            fours = 0;
            fives = 0;
            sixes = 0;
            threeOfAKind = 0;
            FourOfAKind = 0;
            fullHous = 0;
            smallStraight = 0;
            LargeStraight = 0;
            chance = 0;
            Yahtzee = 0;
            sum = 0;

            threeOfAKindBool = false;
            FourOfAKindBool = false;
            yahtzeebool = false;

        }

    }
    
}

﻿using System;
using System.Windows.Forms;

namespace Pingpong
{
    static class Program                                                //Main in aparte class
    {
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}

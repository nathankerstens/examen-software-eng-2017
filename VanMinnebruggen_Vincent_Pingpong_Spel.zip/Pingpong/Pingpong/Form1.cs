﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Pingpong
{
    public partial class Form1 : Form                                   //Naam (Form1) vergeten te wijzigen en met verdergewerkt
    {
        public Form1()
        {
            InitializeComponent();
            this.KeyPreview = true;
        }

        PictureBox[] Score_Player = new PictureBox[5];                  //Array om score bij te houden
        PictureBox[] Score_Enemy = new PictureBox[5];   
        Color ScoreColor = Color.Silver;                                //Om achtergrondkleur in te stellen
        Random rng = new Random();                                      //Bij veranderen: ook op design wijzigen !!!
        Boolean Player_Up, Player_Down = false;                         //Gaat de speler naar boven of naar beneden
        Boolean BallGoingLeft = true;                                   //Gaat de bal naar links of rechts
        Boolean GameOn = false;                                         //Play of pause

        int Speed_Player;                                               //Enkel bewerken in settings pagina
        int Speed_Enemy;                            
        int BallSpeed;
        int BallForce;
        int Round = 0;

        public Boolean Collision_Left(PictureBox obj)
        {
            if (obj.Location.X <= 0)                                    //Als de "obj" picturebox achter de scene is ...
            {
                return true;
            }
            return false;
        }

        public Boolean Collision_Right(PictureBox obj)
        {
            if (obj.Location.X + obj.Width >= WorldFrame.Width)         //Als het Obj verder weg is van het scherm ...
            {
                return true;
            }
            return false;
        }

        public Boolean Collision_Up(PictureBox obj)
        {
            if (obj.Location.Y <= 0)                                    //Als Y boven het scherm is ...
            {
                return true;
            }
            return false;
        }

        public Boolean Collision_Down(PictureBox obj)
        {
            if (obj.Location.Y + obj.Height >= WorldFrame.Height)       //Als Y onder het scherm is ...
            {
                return true;
            }
            return false;
        }

        public Boolean Collision_Enemy(PictureBox tar)
        {
                    PictureBox temp1 = new PictureBox();                //Verschillende punten
                    temp1.Bounds = pb_Enemy.Bounds;                     //Waar het op de rechthoek wordt geschoten + snelheid
                                                                        //Rechthoek voor de enemy
                    temp1.SetBounds(temp1.Location.X - 1, temp1.Location.Y, 1, 10);
                    if (tar.Bounds.IntersectsWith(temp1.Bounds))        //Grootte van rechthoeken wijzigen tot 10px van de kant
                    {
                        BallForce = 3;                                  //Als de bal hier botst wordt Ballforce 3
                        return true;
                    }
                    temp1.SetBounds(temp1.Location.X, temp1.Location.Y + 5, 1, 10);
                    if (tar.Bounds.IntersectsWith(temp1.Bounds))        //Verplaatst rechthoek 5px naar beneden
                    {
                        BallForce = 2;                                  //Minder Ballforce
                        return true;
                    }
                    temp1.SetBounds(temp1.Location.X, temp1.Location.Y + 10, 1, 10);
                    if (tar.Bounds.IntersectsWith(temp1.Bounds))        //...
                    {
                        BallForce = 1;
                        return true;
                    }
                    temp1.SetBounds(temp1.Location.X, temp1.Location.Y + 10, 1, 10);
                    if (tar.Bounds.IntersectsWith(temp1.Bounds))
                    {
                        BallForce = 0;
                        return true;
                    }
                    temp1.SetBounds(temp1.Location.X, temp1.Location.Y + 10, 1, 10);
                    if (tar.Bounds.IntersectsWith(temp1.Bounds))
                    {
                        BallForce = -1;
                        return true;
                    }
                    temp1.SetBounds(temp1.Location.X, temp1.Location.Y + 10, 1, 10);
                    if (tar.Bounds.IntersectsWith(temp1.Bounds))
                    {
                        BallForce = -2;
                        return true;
                    }
                    temp1.SetBounds(temp1.Location.X, temp1.Location.Y + 10, 1, 10);
                    if (tar.Bounds.IntersectsWith(temp1.Bounds))
                    {
                        BallForce = -3;
                        return true;
                    }
            return false;
        }

        public Boolean Collision_Player(PictureBox tar)
        {
            if (tar.Bounds.IntersectsWith(pb_Player.Bounds))            //Zelfde als hierboven (voor player)
            {
                PictureBox temp1 = new PictureBox();
                temp1.Bounds = pb_Player.Bounds;
                temp1.SetBounds(temp1.Location.X + temp1.Width, temp1.Location.Y, 1, 10);
                
                if (tar.Bounds.IntersectsWith(temp1.Bounds))
                {
                    BallForce = 3;
                    return true;
                }
                temp1.SetBounds(temp1.Location.X, temp1.Location.Y + 5, 1, 10);
                
                if (tar.Bounds.IntersectsWith(temp1.Bounds))
                {
                    BallForce = 2;
                    return true;
                }
                temp1.SetBounds(temp1.Location.X, temp1.Location.Y + 10, 1, 10);
                
                if (tar.Bounds.IntersectsWith(temp1.Bounds))
                {
                    BallForce = 1;
                    return true;
                }
                temp1.SetBounds(temp1.Location.X, temp1.Location.Y + 10, 1, 10);
                
                if (tar.Bounds.IntersectsWith(temp1.Bounds))
                {
                    BallForce = 0;
                    return true;
                }
                temp1.SetBounds(temp1.Location.X, temp1.Location.Y + 10, 1, 10);
                
                if (tar.Bounds.IntersectsWith(temp1.Bounds))
                {
                    BallForce = -1;
                    return true;
                }
                temp1.SetBounds(temp1.Location.X, temp1.Location.Y + 10, 1, 10);
                
                if (tar.Bounds.IntersectsWith(temp1.Bounds))
                {
                    BallForce = -2;
                    return true;
                }
                temp1.SetBounds(temp1.Location.X, temp1.Location.Y + 10, 1, 10);
                
                if (tar.Bounds.IntersectsWith(temp1.Bounds))
                {
                    BallForce = -3;
                    return true;
                }
            }
            return false;
        }

        public void PaintBox(int X, int Y, int W, int H, Color C)
        {
            PictureBox Temp = new PictureBox();
            Temp.BackColor = C;
            Temp.Size = new Size(W, H);
            Temp.Location = new Point(X, Y);
            WorldFrame.Controls.Add(Temp);
        }

        public void ApplySettings()
        {                                                               //Om de 1ms wordt de kleur van de settings page ingesteld
            pb_Player.BackColor = Properties.Settings.Default.Color_Player;
            pb_Enemy.BackColor = Properties.Settings.Default.Color_Enemy;
            pb_Ball.BackColor = Properties.Settings.Default.Color_Ball;
            WorldFrame.BackColor = Properties.Settings.Default.Color_Frame;
            BallSpeed = Properties.Settings.Default.BallSpeed;
            timer_Moveball.Interval = Properties.Settings.Default.Timer_Movement;
            timer_Enemy.Interval = Properties.Settings.Default.Timer_Enemy;
            Speed_Enemy = Properties.Settings.Default.EnemySpeed;
            Speed_Player = Properties.Settings.Default.Speed_Player;
        }

        public int ReverseInt(int x, Boolean Force = false, Boolean Negative = false)
        {
            if (Force)                                                  
            {
                if (Negative)                                           //Als de bool negatief is geeft het een negatieve waarde
                {
                    if (x > 0)                                          
                    {
                        x = ~x + 1;                                     //Veel problemen mee gehad, komt van het internet
                    }          
                }
                else
                {
                    x = x - (x * 2);
                }
            }
            else
            {
                if (x > 0)
                {
                    x = x - (x * 2);
                }
                else
                {           
                    x = ~x + 1;
                }
            }
            return x;
        }

        public void RandomStart(Boolean x)
        {
            for (int i = 0; i < rng.Next(5, 10); i++)
            {                                                           //Bal start random
                if (x)
                {
                    x = false;
                }
                else
                {
                    x = true;
                }
            }
        }

        private void timer_Moveball_Tick(object sender, EventArgs e)
        {
            ApplySettings();                                            //Elke ms worden de settings ingesteld

            if (GameOn)                                                 //Er is alleen beweging wanneer de game is gestart (niet pause)
            {
                if (Player_Up && !Collision_Up(pb_Player))
                {                                                       //Als player naar boven wil (en niet collide met top) ...
                    pb_Player.Top -= Speed_Player;
                }
                if (Player_Down && !Collision_Down(pb_Player))
                {                                                       //Als player naar beneden wil (en niet collid met bottom) ...
                    pb_Player.Top += Speed_Player;
                }

                if (BallForce > 0)
                {                                                       //Als Ballforce positief is, bal naar boven
                    pb_Ball.Top -= BallForce;
                }
                if (BallForce < 0)
                {                                                       //Als Ballforce negatief is, bal naar beneden
                    pb_Ball.Top -= BallForce;
                }

                if (pb_Ball.Location.Y <= 1)
                {                                                       //Als de bal collide met de top ...
                    BallForce = ReverseInt(BallForce, true, true);      //Ballforce wordt omgedraaid
                }
                                                                                   
                if (pb_Ball.Location.Y + pb_Ball.Height >= WorldFrame.Height - 1)
                {                                                       //Als de bal collide met de bottom ...
                    BallForce = ReverseInt(BallForce, true, false);     //Ballforce wordt omgedraaid
                }

                if (BallGoingLeft)                                      //Als de bal naar links gaat ...
                {
                    if (Collision_Left(pb_Ball))                        //Als de bal tegen de linkerkant komt ...
                    {
                        AddScore(Score_Player);                         //Box (beneden) bij player wordt ingevuld (= leven minder) + Bal reset
                        pb_Ball.Location = new Point(206, 67);
                        RandomStart(BallGoingLeft);
                        BallForce = 0;
                    }
                    if (!Collision_Player(pb_Ball))                     //Als de bal naar links gaat EN niet met de linkerkant collide EN niet met de player collide...
                    {
                        pb_Ball.Left -= BallSpeed;                      //Bal gaat naar links
                    }
                    else                                                //Als de bal collide met de player ...
                    {
                        BallGoingLeft = false;                          //Bal gaat naar rechts
                    }
                }
                else
                {
                    if (Collision_Right(pb_Ball))                       //Zelfde als hierboven (voor enemy (rechterkant))
                    {
                        AddScore(Score_Enemy);
                        pb_Ball.Location = new Point(206, 67);
                        RandomStart(BallGoingLeft);
                        BallForce = 0;
                    }
                    if (!Collision_Enemy(pb_Ball))
                    {
                        pb_Ball.Left += BallSpeed;
                    }
                    else
                    {
                        BallGoingLeft = true;
                    }
                }
            }
        }

        public void CircleThis(PictureBox pic)                          //Functie om de bal te hertekenen in een cirkel (internet)
        {
            System.Drawing.Drawing2D.GraphicsPath gp = new System.Drawing.Drawing2D.GraphicsPath();
            gp.AddEllipse(0, 0, pic.Width - 3, pic.Height - 3);
            Region rg = new Region(gp);
            pic.Region = rg;
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)                                          //Key input: Als de juiste keys worden ingedrukt komt er beweging
            {
                case Keys.Z:
                case Keys.Up:
                    Player_Down = false;
                    Player_Up = true;
                    break;
                case Keys.S:
                case Keys.Down:
                    Player_Up = false;
                    Player_Down = true;
                    break;
                case Keys.Space:                                        //Spatie om de game te starten OF pauseren
                    if (GameOn)
                    {
                        GameOn = false;
                        RandomStart(BallGoingLeft);
                        label_Start.Visible = false;
                    }
                    else
                    {
                        GameOn = true;
                        RandomStart(BallGoingLeft);
                        label_Start.Visible = false;
                    }
                    break;
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Z:
                case Keys.Up:
                    Player_Up = false;
                    break;
                case Keys.S:
                case Keys.Down:
                    Player_Down = false;
                    break;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                Score_Player[i] = PicID(i + 1);                         //Voegt de "score" picturebox toe aan een array
                Score_Enemy[i] = PicID(i + 1, true);
            }
            CircleThis(pb_Ball);                                        //Bal wordt cirkel
            ApplySettings();                                            //Alle globale settings worden toegepast (sowieso om de 1ms)
            pb_Ball.Location = new Point(208, rng.Next(10, 190));       //Zet de bal op zijn plaats
            RandomStart(BallGoingLeft);                                 //Richting van de bal is random
        }        

        public void AddScore(PictureBox[] Arr)
        {
            for (int i = 0; i < Arr.Length; i++)
            {                                                           //Gaat door de hele array, kijkt waar de eerste "niet zwarte" box is
                if (Arr[i].BackColor == ScoreColor)
                {
                    Arr[i].BackColor = Color.Black;                     //Veranderd eerste box naar zwart
                    break;
                }
            }

            if (Arr[4].BackColor == Color.Black)
            {                                                           //Als ze allemaal zwart zijn is het spel gedaan
                GameOn = false;
                label_Start.Visible = true;
                RestoreScore();
                pb_Ball.Location = new Point(208, rng.Next(10, 190));
                pb_Player.Location = new Point(3, 67);
                pb_Enemy.Location = new Point(409, 67);
                Round = 0;
                label_Time.Visible = false;
            }
        }

        public void RestoreScore()
        {
            for (int i = 0; i <= 5; i++)
            {                                                           //Alle score boxen worden naar originele kleur gezet
                PicID(i).BackColor = ScoreColor;
                PicID(i, true).BackColor = ScoreColor;
            }
        }

        public PictureBox PicID(int i, Boolean Enemy = false)
        {
            if (Enemy)
            {                                                           //Om het makkelijker te maken gebruik ik een loop om erdoor te gaan
                switch (i)
                {
                    case 1:
                        return enemy_1;
                    case 2:
                        return enemy_2;
                    case 3:
                        return enemy_3;
                    case 4:
                        return enemy_4;
                    case 5:
                        return enemy_5;
                }
            }
            else
            {
                switch (i)
                {
                    case 1:
                        return player_1;
                    case 2:
                        return player_2;
                    case 3:
                        return player_3;
                    case 4:
                        return player_4;
                    case 5:
                        return player_5;
                }
            }
            return pb_Ball;
        }

        private void timer_Enemy_Tick(object sender, EventArgs e)
        {
            if (GameOn)                                                 //Timer om de enemy te verplaatsen
            {                                                           //Probeert altijd in het midden te zijn (ongeveer 28px onder Y)
                if (pb_Enemy.Location.Y + 28 < pb_Ball.Location.Y)
                {
                    pb_Enemy.Top += Speed_Enemy;
                }
                else
                {
                    pb_Enemy.Top -= Speed_Enemy;
                }
            }
        }

        private void settingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SettingsForm sF = new SettingsForm();
            sF.Show();
        }

        private void timer_Sec_Tick(object sender, EventArgs e)
        {
            if (GameOn)
            {
                Round++;
                label_Time.Visible = true;

                TimeSpan time = TimeSpan.FromSeconds(Round);

                string str = time.ToString(@"mm\:ss");
                label_Time.Text = "Time: " + str;
            }
        }
    }
}
﻿using System;
using System.Windows.Forms;

namespace yahtzeeV1
{
    public partial class Form1 : Form
    {
        Game game = new Game();
        int[] numberOfDice = new int[5];
        PictureBox[] arrPicturebox = new PictureBox[5];
        Button[] holdButton = new Button[5];
        CheckBox[] checkBoxes = new CheckBox[13];
        Label[] labelsRegularScore = new Label[16];
        

        int rollCount;
        int scoreCheckBox = 0;
        int subTotal1 = 0;
        int subTotal2 = 0;
        int total = 0;

        int highScore = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            game.MakeDice();

            arrPicturebox[0] = pb1show;
            arrPicturebox[1] = pb2show;
            arrPicturebox[2] = pb3show;
            arrPicturebox[3] = pb4show;
            arrPicturebox[4] = pb5show;

            holdButton[0] = hold1;
            holdButton[1] = hold2;
            holdButton[2] = hold3;
            holdButton[3] = hold4;
            holdButton[4] = hold5;

            checkBoxes[0] = checkBox1;
            checkBoxes[1] = checkBox2;
            checkBoxes[2] = checkBox3;
            checkBoxes[3] = checkBox4;
            checkBoxes[4] = checkBox5;
            checkBoxes[5] = checkBox6;
            checkBoxes[6] = checkBox7;
            checkBoxes[7] = checkBox8;
            checkBoxes[8] = checkBox9;
            checkBoxes[9] = checkBox10;
            checkBoxes[10] = checkBox11;
            checkBoxes[11] = checkBox12;
            checkBoxes[12] = checkBox13;

            labelsRegularScore[0] = label1;
            labelsRegularScore[1] = label2;
            labelsRegularScore[2] = label3;
            labelsRegularScore[3] = label4;
            labelsRegularScore[4] = label5;
            labelsRegularScore[5] = label6;
            labelsRegularScore[6] = label17;
            labelsRegularScore[7] = label14;
            labelsRegularScore[8] = label13;
            labelsRegularScore[9] = label12;
            labelsRegularScore[10] = label11;
            labelsRegularScore[11] = label10;
            labelsRegularScore[12] = label9;
            labelsRegularScore[13] = label19;
            labelsRegularScore[14] = label18;
            labelsRegularScore[15] = label15;

            for (int i = 0; i < holdButton.Length; i++)
            {
                holdButton[i].Enabled = false;
            }
        }

        //roll button
        private void button1_Click(object sender, EventArgs e)
        {
            rollCount++;

            if (rollCount >2)
            {
                Roll_Btn.Enabled = false;
                rollCount = 0;
            }

            for (int i = 0; i < holdButton.Length; i++)
            {
                holdButton[i].Enabled = true;
            }

            numberOfDice = game.AddNumber();

            for (int i = 0; i < 5; i++)
            {

                switch (numberOfDice[i])
                {
                    case 1:
                        arrPicturebox[i].Image = Properties.Resources.dice1;
                        break;
                    case 2:
                        arrPicturebox[i].Image = Properties.Resources.dice2;
                        break;
                    case 3:
                        arrPicturebox[i].Image = Properties.Resources.dice3;
                        break;
                    case 4:
                        arrPicturebox[i].Image = Properties.Resources.dice4;
                        break;
                    case 5:
                        arrPicturebox[i].Image = Properties.Resources.dice5;
                        break;
                    case 6:
                        arrPicturebox[i].Image = Properties.Resources.dice6;
                        break;
                    default:
                        break;
                }
            }

        }

        private void hold1_Click(object sender, EventArgs e)
        {
            game.diceIsSet[0] = true;
            arrPicturebox[0].BorderStyle = BorderStyle.None;
        }

        //hold2
        private void button3_Click(object sender, EventArgs e)
        {
            game.diceIsSet[1] = true;
            arrPicturebox[1].BorderStyle = BorderStyle.None;
        }

        private void hold3_Click(object sender, EventArgs e)
        {
            game.diceIsSet[2] = true;
            arrPicturebox[2].BorderStyle = BorderStyle.None;
        }

        private void hold4_Click(object sender, EventArgs e)
        {
            game.diceIsSet[3] = true;
            arrPicturebox[3].BorderStyle = BorderStyle.None;
        }

        private void hold5_Click(object sender, EventArgs e)
        {
            game.diceIsSet[4] = true;
            arrPicturebox[4].BorderStyle = BorderStyle.None;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            scoreCheckBox = game.ScoreSameDices(1, numberOfDice);
            subTotal1 += scoreCheckBox;
            label1.Text = scoreCheckBox.ToString();
            label17.Text = subTotal1.ToString();

            total = subTotal1 + subTotal2;
            label15.Text = total.ToString();

            checkBox1.Enabled = false;
            Roll_Btn.Enabled = true;

            rollCount = 0;

            for (int i = 0; i < holdButton.Length; i++)
            {
                game.diceIsSet[i] = false;
                holdButton[i].Enabled = false;
                arrPicturebox[i].BorderStyle = BorderStyle.Fixed3D;  
            }

            Roll_Btn.PerformClick();

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            scoreCheckBox = game.ScoreSameDices(2, numberOfDice);
            subTotal1 += scoreCheckBox;
            label2.Text = scoreCheckBox.ToString();
            label17.Text = subTotal1.ToString();

            total = subTotal1 + subTotal2;
            label15.Text = total.ToString();

            checkBox2.Enabled = false;

            rollCount = 0;

            Roll_Btn.Enabled = true;

            for (int i = 0; i < holdButton.Length; i++)
            {
                game.diceIsSet[i] = false;
                holdButton[i].Enabled = false;
                arrPicturebox[i].BorderStyle = BorderStyle.Fixed3D;
            }

            Roll_Btn.PerformClick();
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            scoreCheckBox = game.ScoreSameDices(3, numberOfDice);
            subTotal1 += scoreCheckBox;
            label3.Text = scoreCheckBox.ToString();
            label17.Text = subTotal1.ToString();

            total = subTotal1 + subTotal2;
            label15.Text = total.ToString();

            checkBox3.Enabled = false;

            rollCount = 0;

            Roll_Btn.Enabled = true;

            for (int i = 0; i < holdButton.Length; i++)
            {
                game.diceIsSet[i] = false;
                holdButton[i].Enabled = false;
                arrPicturebox[i].BorderStyle = BorderStyle.Fixed3D;
            }

            Roll_Btn.PerformClick();
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            scoreCheckBox = game.ScoreSameDices(4, numberOfDice);
            subTotal1 += scoreCheckBox;
            label4.Text = scoreCheckBox.ToString();
            label17.Text = subTotal1.ToString();

            total = subTotal1 + subTotal2;
            label15.Text = total.ToString();

            checkBox4.Enabled = false;

            rollCount = 0;

            Roll_Btn.Enabled = true;

            for (int i = 0; i < holdButton.Length; i++)
            {
                game.diceIsSet[i] = false;
                holdButton[i].Enabled = false;
                arrPicturebox[i].BorderStyle = BorderStyle.Fixed3D;
            }

            Roll_Btn.PerformClick();
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            scoreCheckBox = game.ScoreSameDices(5, numberOfDice);
            subTotal1 += scoreCheckBox;
            label5.Text = scoreCheckBox.ToString();
            label17.Text = subTotal1.ToString();

            total = subTotal1 + subTotal2;
            label15.Text = total.ToString();

            checkBox5.Enabled = false;

            rollCount = 0;

            Roll_Btn.Enabled = true;

            for (int i = 0; i < holdButton.Length; i++)
            {
                game.diceIsSet[i] = false;
                holdButton[i].Enabled = false;
                arrPicturebox[i].BorderStyle = BorderStyle.Fixed3D;
            }

            Roll_Btn.PerformClick();
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            scoreCheckBox = game.ScoreSameDices(6, numberOfDice);
            subTotal1 += scoreCheckBox;
            label6.Text = scoreCheckBox.ToString();
            label17.Text = subTotal1.ToString();

            total = subTotal1 + subTotal2;
            label15.Text = total.ToString();

            checkBox6.Enabled = false;

            rollCount = 0;

            Roll_Btn.Enabled = true;

            for (int i = 0; i < holdButton.Length; i++)
            {
                game.diceIsSet[i] = false;
                holdButton[i].Enabled = false;
                arrPicturebox[i].BorderStyle = BorderStyle.Fixed3D;
            }

            Roll_Btn.PerformClick();
        }

        private void checkBox12_CheckedChanged(object sender, EventArgs e)
        {
            scoreCheckBox = game.ScoreThreeOfAKind(numberOfDice);
            subTotal2 += scoreCheckBox;
            label14.Text = scoreCheckBox.ToString();
            label18.Text = subTotal2.ToString();

            total = subTotal1 + subTotal2;
            label15.Text = total.ToString();

            checkBox12.Enabled = false;

            rollCount = 0;

            Roll_Btn.Enabled = true;

            for (int i = 0; i < holdButton.Length; i++)
            {
                game.diceIsSet[i] = false;
                holdButton[i].Enabled = false;
                arrPicturebox[i].BorderStyle = BorderStyle.Fixed3D;
            }

            Roll_Btn.PerformClick();
        }

        private void checkBox11_CheckedChanged(object sender, EventArgs e)
        {
            scoreCheckBox = game.ScoreFourOfAKind(numberOfDice);
            subTotal2 += scoreCheckBox;
            label13.Text = scoreCheckBox.ToString();
            label18.Text = subTotal2.ToString();

            total = subTotal1 + subTotal2;
            label15.Text = total.ToString();

            checkBox11.Enabled = false;

            rollCount = 0;

            Roll_Btn.Enabled = true;

            for (int i = 0; i < holdButton.Length; i++)
            {
                game.diceIsSet[i] = false;
                holdButton[i].Enabled = false;
                arrPicturebox[i].BorderStyle = BorderStyle.Fixed3D;
            }

            Roll_Btn.PerformClick();
        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {
            scoreCheckBox = game.ScoreSmallStraight(numberOfDice);
            subTotal2 += scoreCheckBox;
            label12.Text = scoreCheckBox.ToString();
            label18.Text = subTotal2.ToString();

            total = subTotal1 + subTotal2;
            label15.Text = total.ToString();

            checkBox10.Enabled = false;

            rollCount = 0;

            Roll_Btn.Enabled = true;

            for (int i = 0; i < holdButton.Length; i++)
            {
                game.diceIsSet[i] = false;
                holdButton[i].Enabled = false;
                arrPicturebox[i].BorderStyle = BorderStyle.Fixed3D;
            }

            Roll_Btn.PerformClick();
        }

        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {
            scoreCheckBox = game.ScoreLargeStraight(numberOfDice);
            subTotal2 += scoreCheckBox;
            label11.Text = scoreCheckBox.ToString();
            label18.Text = subTotal2.ToString();

            total = subTotal1 + subTotal2;
            label15.Text = total.ToString();

            checkBox9.Enabled = false;

            rollCount = 0;

            Roll_Btn.Enabled = true;

            for (int i = 0; i < holdButton.Length; i++)
            {
                game.diceIsSet[i] = false;
                holdButton[i].Enabled = false;
                arrPicturebox[i].BorderStyle = BorderStyle.Fixed3D;
            }

            Roll_Btn.PerformClick();
        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {
            scoreCheckBox = game.ScoreFullHouse(numberOfDice);
            subTotal2 += scoreCheckBox;
            label10.Text = scoreCheckBox.ToString();
            label18.Text = subTotal2.ToString();

            total = subTotal1 + subTotal2;
            label15.Text = total.ToString();

            checkBox8.Enabled = false;

            rollCount = 0;

            Roll_Btn.Enabled = true;

            for (int i = 0; i < holdButton.Length; i++)
            {
                game.diceIsSet[i] = false;
                holdButton[i].Enabled = false;
                arrPicturebox[i].BorderStyle = BorderStyle.Fixed3D;
            }

            Roll_Btn.PerformClick();
        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            scoreCheckBox = game.ScoreChance(numberOfDice);
            subTotal2 += scoreCheckBox;
            label9.Text = scoreCheckBox.ToString();
            label18.Text = subTotal2.ToString();

            total = subTotal1 + subTotal2;
            label15.Text = total.ToString();

            checkBox7.Enabled = false;

            rollCount = 0;

            Roll_Btn.Enabled = true;

            for (int i = 0; i < holdButton.Length; i++)
            {
                game.diceIsSet[i] = false;
                holdButton[i].Enabled = false;
                arrPicturebox[i].BorderStyle = BorderStyle.Fixed3D;
            }

            Roll_Btn.PerformClick();
        }

        private void checkBox13_CheckedChanged(object sender, EventArgs e)
        {
            scoreCheckBox = game.ScoreYahtzee(numberOfDice);
            subTotal2 += scoreCheckBox;
            label19.Text = scoreCheckBox.ToString();
            label18.Text = subTotal2.ToString();
            total = subTotal1 + subTotal2;
            label15.Text = total.ToString();


            checkBox13.Enabled = false;

            rollCount = 0;

            Roll_Btn.Enabled = true;

            for (int i = 0; i < holdButton.Length; i++)
            {
                game.diceIsSet[i] = false;
                holdButton[i].Enabled = false;
                arrPicturebox[i].BorderStyle = BorderStyle.Fixed3D;
            }

            Roll_Btn.PerformClick();
        }

        private void newGameButton_Click(object sender, EventArgs e)
        {
            if (total > highScore)
            {
                highScore = total;
                label20.Text = highScore.ToString();
            }

            for (int i = 0; i < checkBoxes.Length; i++)
            {
                checkBoxes[i].Checked = false;
                checkBoxes[i].Enabled = true;
            }

            for (int i = 0; i < labelsRegularScore.Length; i++)
            {
                labelsRegularScore[i].Text = "0";
            }

            total = 0;
            subTotal1 = 0;
            subTotal2 = 0;
            scoreCheckBox = 0;

            Roll_Btn.PerformClick();
        }
    }
}

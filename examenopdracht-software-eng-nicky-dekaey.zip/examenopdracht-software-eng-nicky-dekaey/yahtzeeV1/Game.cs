﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace yahtzeeV1
{
    class Game
    {        
        Random rnd = new Random();
        Dice[] arrDice = new Dice[5];
        int[] numberOfDice = new int[5];
        public bool[] diceIsSet = new bool[5];


        public void MakeDice()
        {
            for (int i = 0; i < 5; i++)
            {
                arrDice[i] = new Dice();
            }
        }

        public int[] AddNumber()
        {
            for (int i = 0; i < numberOfDice.Length; i++)
            {
                bool diceSet = diceIsSet[i];

                if (diceSet == false)
                {
                    numberOfDice[i] = arrDice[i].RndNummer(rnd);
                }
            }
            return numberOfDice;
        }
        
        public int ScoreSameDices(int diceNumber, int[] arrNumberOfDice)
        {
            int sum=0;

            for (int i = 0; i < arrNumberOfDice.Length; i++)
            {
                if (arrNumberOfDice[i] == diceNumber)
                {
                    sum += diceNumber;
                }
            }
            return sum;
        }

        public int ScoreThreeOfAKind(int[] arrNumberOfDice)
        {
            int sum = 0;

            bool threeOfAKind = false;

            for (int i = 1; i <= 6; i++)
            {
                int count = 0;
                for (int j = 0; j < 5; j++)
                {
                    if (arrNumberOfDice[j] == i)
                    {
                        count++;
                    }
                    if (count > 2)
                    {
                        threeOfAKind = true;
                    }                        
                }
            }

            if (threeOfAKind)
            {
                for (int i = 0; i < 5; i++)
                {
                    sum += arrNumberOfDice[i];
                }
            }

            return sum;
        }

        public int ScoreFourOfAKind(int[] arrNumberOfDice)
        {
            int sum = 0;

            bool fourOfAKind = false;

            for (int i = 1; i <= 6; i++)
            {
                int count = 0;
                for (int j = 0; j < 5; j++)
                {
                    if (arrNumberOfDice[j] == i)
                    {
                        count++;
                    }
                    if (count > 3)
                    {
                        fourOfAKind = true;
                    }                        
                }
            }

            if (fourOfAKind)
            {
                for (int i = 0; i < 5; i++)
                {
                    sum += arrNumberOfDice[i];
                }
            }

            return sum;
        }

        public int ScoreSmallStraight(int[] arrNumberOfDice)
        {
            int sum = 0;

            int[] fHDices = new int[5];
            fHDices[0] = arrNumberOfDice[0];
            fHDices[1] = arrNumberOfDice[1];
            fHDices[2] = arrNumberOfDice[2];
            fHDices[3] = arrNumberOfDice[3];
            fHDices[4] = arrNumberOfDice[4];

            Array.Sort(fHDices);

            //to avoid problems when 2dice have the same number
            for (int j = 0; j < 4; j++)
            {
                int temp = 0;
                if (fHDices[j] == fHDices[j + 1])
                {
                    temp = fHDices[j];

                    for (int k = j; k < 4; k++)
                    {
                        fHDices[k] = fHDices[k + 1]; //moves everything up
                    }

                    fHDices[4] = temp;
                }
            }

            if (((fHDices[0] == 1) && (fHDices[1] == 2) && (fHDices[2] == 3) && (fHDices[3] == 4)) ||
                ((fHDices[0] == 2) && (fHDices[1] == 3) && (fHDices[2] == 4) && (fHDices[3] == 5)) ||
                ((fHDices[0] == 3) && (fHDices[1] == 4) && (fHDices[2] == 5) && (fHDices[3] == 6)) ||
                ((fHDices[1] == 1) && (fHDices[2] == 2) && (fHDices[3] == 3) && (fHDices[4] == 4)) ||
                ((fHDices[1] == 2) && (fHDices[2] == 3) && (fHDices[3] == 4) && (fHDices[4] == 5)) ||
                ((fHDices[1] == 3) && (fHDices[2] == 4) && (fHDices[3] == 5) && (fHDices[4] == 6)))
            {
                sum = 30;
            }
            return sum;
        }

        public int ScoreLargeStraight(int[] arrNumberOfDice)
        {
            int sum = 0;

            int[] fHDices = new int[5];
            fHDices[0] = arrNumberOfDice[0];
            fHDices[1] = arrNumberOfDice[1];
            fHDices[2] = arrNumberOfDice[2];
            fHDices[3] = arrNumberOfDice[3];
            fHDices[4] = arrNumberOfDice[4];

            Array.Sort(fHDices);

            if ((fHDices[0] == 1) &&
                (fHDices[1] == 2) &&
                (fHDices[2] == 3) &&
                (fHDices[3] == 4) &&
                (fHDices[4] == 5) ||
                (fHDices[0] == 2) &&
                (fHDices[1] == 3) &&
                (fHDices[2] == 4) &&
                (fHDices[3] == 5) &&
                (fHDices[4] == 6))
            {
                sum = 40;
            }

            return sum;
        }

        public int ScoreFullHouse(int [] arrNumberOfDice)
        {
            int sum =0;

            int[] fHDices = new int[5];
            fHDices[0] = arrNumberOfDice[0];
            fHDices[1] = arrNumberOfDice[1];
            fHDices[2] = arrNumberOfDice[2];
            fHDices[3] = arrNumberOfDice[3];
            fHDices[4] = arrNumberOfDice[4];

            Array.Sort(fHDices);

            if ((((fHDices[0] == fHDices[1]) && (fHDices[1] == fHDices[2])) && // Three of a Kind
                  (fHDices[3] == fHDices[4]) && // Two of a Kind
                  (fHDices[2] != fHDices[3])) ||
                 ((fHDices[0] == fHDices[1]) && // Two of a Kind
                 ((fHDices[2] == fHDices[3]) && (fHDices[3] == fHDices[4])) && // Three of a Kind
                  (fHDices[1] != fHDices[2])))
            {
                sum = 25;
            }

            return sum;
        }

        public int ScoreChance(int[] arrNumberOfDice)
        {
            int sum = 0;

            for (int i = 0; i < arrNumberOfDice.Length; i++)
            {
                sum += arrNumberOfDice[i];
            }
            return sum;
        }

        public int ScoreYahtzee(int[] arrNumberOfDice)
        {
            int sum = 0;

            for (int i = 1; i <= 6; i++)
            {
                int count = 0;
                for (int j = 0; j < 5; j++)
                {
                    if (arrNumberOfDice[j] == i)
                        count++;

                    if (count > 4)
                        sum = 50;
                }
            }

            return sum;
        }        
    }
}

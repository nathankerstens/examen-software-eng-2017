﻿namespace yahtzeeV1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Roll_Btn = new System.Windows.Forms.Button();
            this.pb1show = new System.Windows.Forms.PictureBox();
            this.pb2show = new System.Windows.Forms.PictureBox();
            this.pb3show = new System.Windows.Forms.PictureBox();
            this.pb4show = new System.Windows.Forms.PictureBox();
            this.pb5show = new System.Windows.Forms.PictureBox();
            this.hold1 = new System.Windows.Forms.Button();
            this.hold2 = new System.Windows.Forms.Button();
            this.hold3 = new System.Windows.Forms.Button();
            this.hold4 = new System.Windows.Forms.Button();
            this.hold5 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.label19 = new System.Windows.Forms.Label();
            this.newGameButton = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pb1show)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb2show)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb3show)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb4show)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb5show)).BeginInit();
            this.SuspendLayout();
            // 
            // Roll_Btn
            // 
            this.Roll_Btn.Location = new System.Drawing.Point(183, 376);
            this.Roll_Btn.Name = "Roll_Btn";
            this.Roll_Btn.Size = new System.Drawing.Size(328, 52);
            this.Roll_Btn.TabIndex = 5;
            this.Roll_Btn.Text = "Roll";
            this.Roll_Btn.UseVisualStyleBackColor = true;
            this.Roll_Btn.Click += new System.EventHandler(this.button1_Click);
            // 
            // pb1show
            // 
            this.pb1show.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pb1show.Location = new System.Drawing.Point(35, 163);
            this.pb1show.Name = "pb1show";
            this.pb1show.Size = new System.Drawing.Size(119, 120);
            this.pb1show.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb1show.TabIndex = 6;
            this.pb1show.TabStop = false;
            // 
            // pb2show
            // 
            this.pb2show.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pb2show.Location = new System.Drawing.Point(170, 163);
            this.pb2show.Name = "pb2show";
            this.pb2show.Size = new System.Drawing.Size(119, 120);
            this.pb2show.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb2show.TabIndex = 7;
            this.pb2show.TabStop = false;
            // 
            // pb3show
            // 
            this.pb3show.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pb3show.Location = new System.Drawing.Point(304, 163);
            this.pb3show.Name = "pb3show";
            this.pb3show.Size = new System.Drawing.Size(119, 120);
            this.pb3show.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb3show.TabIndex = 8;
            this.pb3show.TabStop = false;
            // 
            // pb4show
            // 
            this.pb4show.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pb4show.Location = new System.Drawing.Point(438, 163);
            this.pb4show.Name = "pb4show";
            this.pb4show.Size = new System.Drawing.Size(119, 120);
            this.pb4show.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb4show.TabIndex = 9;
            this.pb4show.TabStop = false;
            // 
            // pb5show
            // 
            this.pb5show.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pb5show.Location = new System.Drawing.Point(577, 163);
            this.pb5show.Name = "pb5show";
            this.pb5show.Size = new System.Drawing.Size(119, 120);
            this.pb5show.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb5show.TabIndex = 10;
            this.pb5show.TabStop = false;
            // 
            // hold1
            // 
            this.hold1.Location = new System.Drawing.Point(57, 289);
            this.hold1.Name = "hold1";
            this.hold1.Size = new System.Drawing.Size(75, 23);
            this.hold1.TabIndex = 12;
            this.hold1.Text = "Hold";
            this.hold1.UseVisualStyleBackColor = true;
            this.hold1.Click += new System.EventHandler(this.hold1_Click);
            // 
            // hold2
            // 
            this.hold2.Location = new System.Drawing.Point(199, 289);
            this.hold2.Name = "hold2";
            this.hold2.Size = new System.Drawing.Size(75, 23);
            this.hold2.TabIndex = 13;
            this.hold2.Text = "Hold";
            this.hold2.UseVisualStyleBackColor = true;
            this.hold2.Click += new System.EventHandler(this.button3_Click);
            // 
            // hold3
            // 
            this.hold3.Location = new System.Drawing.Point(334, 289);
            this.hold3.Name = "hold3";
            this.hold3.Size = new System.Drawing.Size(75, 23);
            this.hold3.TabIndex = 14;
            this.hold3.Text = "Hold";
            this.hold3.UseVisualStyleBackColor = true;
            this.hold3.Click += new System.EventHandler(this.hold3_Click);
            // 
            // hold4
            // 
            this.hold4.Location = new System.Drawing.Point(461, 289);
            this.hold4.Name = "hold4";
            this.hold4.Size = new System.Drawing.Size(75, 23);
            this.hold4.TabIndex = 15;
            this.hold4.Text = "Hold";
            this.hold4.UseVisualStyleBackColor = true;
            this.hold4.Click += new System.EventHandler(this.hold4_Click);
            // 
            // hold5
            // 
            this.hold5.Location = new System.Drawing.Point(604, 289);
            this.hold5.Name = "hold5";
            this.hold5.Size = new System.Drawing.Size(75, 23);
            this.hold5.TabIndex = 16;
            this.hold5.Text = "Hold";
            this.hold5.UseVisualStyleBackColor = true;
            this.hold5.Click += new System.EventHandler(this.hold5_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(916, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 17);
            this.label1.TabIndex = 17;
            this.label1.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(916, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 17);
            this.label2.TabIndex = 18;
            this.label2.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(916, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(16, 17);
            this.label3.TabIndex = 19;
            this.label3.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(916, 94);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(16, 17);
            this.label4.TabIndex = 20;
            this.label4.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(916, 121);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(16, 17);
            this.label5.TabIndex = 21;
            this.label5.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(916, 148);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(16, 17);
            this.label6.TabIndex = 22;
            this.label6.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(782, 179);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 17);
            this.label7.TabIndex = 23;
            this.label7.Text = "Sub-Total";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(657, 9);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(85, 17);
            this.label16.TabIndex = 32;
            this.label16.Text = "Total Score:";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(809, 12);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(64, 21);
            this.checkBox1.TabIndex = 33;
            this.checkBox1.Text = "Ones";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(809, 40);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(63, 21);
            this.checkBox2.TabIndex = 34;
            this.checkBox2.Text = "Twos";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(809, 67);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(75, 21);
            this.checkBox3.TabIndex = 35;
            this.checkBox3.Text = "Threes";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(809, 94);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(66, 21);
            this.checkBox4.TabIndex = 36;
            this.checkBox4.Text = "Fours";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(809, 121);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(63, 21);
            this.checkBox5.TabIndex = 37;
            this.checkBox5.Text = "Fives";
            this.checkBox5.UseVisualStyleBackColor = true;
            this.checkBox5.CheckedChanged += new System.EventHandler(this.checkBox5_CheckedChanged);
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(809, 148);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(63, 21);
            this.checkBox6.TabIndex = 38;
            this.checkBox6.Text = "Sixes";
            this.checkBox6.UseVisualStyleBackColor = true;
            this.checkBox6.CheckedChanged += new System.EventHandler(this.checkBox6_CheckedChanged);
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(809, 347);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(78, 21);
            this.checkBox7.TabIndex = 51;
            this.checkBox7.Text = "Chance";
            this.checkBox7.UseVisualStyleBackColor = true;
            this.checkBox7.CheckedChanged += new System.EventHandler(this.checkBox7_CheckedChanged);
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(809, 320);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(97, 21);
            this.checkBox8.TabIndex = 50;
            this.checkBox8.Text = "Full House";
            this.checkBox8.UseVisualStyleBackColor = true;
            this.checkBox8.CheckedChanged += new System.EventHandler(this.checkBox8_CheckedChanged);
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(809, 293);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(120, 21);
            this.checkBox9.TabIndex = 49;
            this.checkBox9.Text = "Large Straight";
            this.checkBox9.UseVisualStyleBackColor = true;
            this.checkBox9.CheckedChanged += new System.EventHandler(this.checkBox9_CheckedChanged);
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Location = new System.Drawing.Point(809, 266);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(117, 21);
            this.checkBox10.TabIndex = 48;
            this.checkBox10.Text = "Small Straight";
            this.checkBox10.UseVisualStyleBackColor = true;
            this.checkBox10.CheckedChanged += new System.EventHandler(this.checkBox10_CheckedChanged);
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Location = new System.Drawing.Point(809, 240);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(123, 21);
            this.checkBox11.TabIndex = 47;
            this.checkBox11.Text = "Four Of A Kind";
            this.checkBox11.UseVisualStyleBackColor = true;
            this.checkBox11.CheckedChanged += new System.EventHandler(this.checkBox11_CheckedChanged);
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Location = new System.Drawing.Point(809, 212);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(132, 21);
            this.checkBox12.TabIndex = 46;
            this.checkBox12.Text = "Three Of A Kind";
            this.checkBox12.UseVisualStyleBackColor = true;
            this.checkBox12.CheckedChanged += new System.EventHandler(this.checkBox12_CheckedChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(782, 407);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 17);
            this.label8.TabIndex = 45;
            this.label8.Text = "Sub-Total";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(945, 347);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(16, 17);
            this.label9.TabIndex = 44;
            this.label9.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(945, 320);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(16, 17);
            this.label10.TabIndex = 43;
            this.label10.Text = "0";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(945, 293);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(16, 17);
            this.label11.TabIndex = 42;
            this.label11.Text = "0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(945, 266);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(16, 17);
            this.label12.TabIndex = 41;
            this.label12.Text = "0";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(945, 239);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(16, 17);
            this.label13.TabIndex = 40;
            this.label13.Text = "0";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(945, 213);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(16, 17);
            this.label14.TabIndex = 39;
            this.label14.Text = "0";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(748, 9);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(16, 17);
            this.label15.TabIndex = 52;
            this.label15.Text = "0";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(859, 179);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(16, 17);
            this.label17.TabIndex = 53;
            this.label17.Text = "0";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(859, 407);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(16, 17);
            this.label18.TabIndex = 54;
            this.label18.Text = "0";
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Location = new System.Drawing.Point(809, 374);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(82, 21);
            this.checkBox13.TabIndex = 57;
            this.checkBox13.Text = "Yahtzee";
            this.checkBox13.UseVisualStyleBackColor = true;
            this.checkBox13.CheckedChanged += new System.EventHandler(this.checkBox13_CheckedChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(945, 374);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(16, 17);
            this.label19.TabIndex = 56;
            this.label19.Text = "0";
            // 
            // newGameButton
            // 
            this.newGameButton.Location = new System.Drawing.Point(13, 422);
            this.newGameButton.Name = "newGameButton";
            this.newGameButton.Size = new System.Drawing.Size(95, 40);
            this.newGameButton.TabIndex = 58;
            this.newGameButton.Text = "New Game";
            this.newGameButton.UseVisualStyleBackColor = true;
            this.newGameButton.Click += new System.EventHandler(this.newGameButton_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(748, 40);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(16, 17);
            this.label20.TabIndex = 60;
            this.label20.Text = "0";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(657, 40);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(76, 17);
            this.label21.TabIndex = 59;
            this.label21.Text = "Highscore:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(978, 266);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(76, 17);
            this.label23.TabIndex = 62;
            this.label23.Text = "eg. 1 2 3 4";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(978, 294);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(88, 17);
            this.label24.TabIndex = 63;
            this.label24.Text = "eg. 1 2 3 4 5";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(978, 320);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(88, 17);
            this.label25.TabIndex = 64;
            this.label25.Text = "eg. 1 1 2 2 2";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(978, 374);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(88, 17);
            this.label26.TabIndex = 65;
            this.label26.Text = "eg. 1 1 1 1 1";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(978, 347);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(111, 17);
            this.label27.TabIndex = 66;
            this.label27.Text = "any combination";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(32, 13);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(221, 17);
            this.label22.TabIndex = 67;
            this.label22.Text = "Rules: press roll to start the game";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(74, 67);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(193, 17);
            this.label28.TabIndex = 68;
            this.label28.Text = "you can roll up to 3times total";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(74, 84);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(349, 17);
            this.label29.TabIndex = 69;
            this.label29.Text = "after checking a box the first roll will start automatically";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(74, 30);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(179, 17);
            this.label30.TabIndex = 70;
            this.label30.Text = "press hold to keep the dice";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(74, 101);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(622, 17);
            this.label31.TabIndex = 71;
            this.label31.Text = "if none of your dice match the open checkboxes, just select one you don\'t mind ge" +
    "tting 0points for";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(74, 50);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(224, 17);
            this.label32.TabIndex = 72;
            this.label32.Text = "once hold a dice can\'t be put back";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1106, 479);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.newGameButton);
            this.Controls.Add(this.checkBox13);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.checkBox7);
            this.Controls.Add(this.checkBox8);
            this.Controls.Add(this.checkBox9);
            this.Controls.Add(this.checkBox10);
            this.Controls.Add(this.checkBox11);
            this.Controls.Add(this.checkBox12);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.checkBox6);
            this.Controls.Add(this.checkBox5);
            this.Controls.Add(this.checkBox4);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.hold5);
            this.Controls.Add(this.hold4);
            this.Controls.Add(this.hold3);
            this.Controls.Add(this.hold2);
            this.Controls.Add(this.hold1);
            this.Controls.Add(this.pb5show);
            this.Controls.Add(this.pb4show);
            this.Controls.Add(this.pb3show);
            this.Controls.Add(this.pb2show);
            this.Controls.Add(this.pb1show);
            this.Controls.Add(this.Roll_Btn);
            this.Name = "Form1";
            this.Text = "DiceRolling";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pb1show)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb2show)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb3show)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb4show)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb5show)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Roll_Btn;
        private System.Windows.Forms.PictureBox pb1show;
        private System.Windows.Forms.PictureBox pb2show;
        private System.Windows.Forms.PictureBox pb3show;
        private System.Windows.Forms.PictureBox pb4show;
        private System.Windows.Forms.PictureBox pb5show;
        private System.Windows.Forms.Button hold1;
        private System.Windows.Forms.Button hold2;
        private System.Windows.Forms.Button hold3;
        private System.Windows.Forms.Button hold4;
        private System.Windows.Forms.Button hold5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button newGameButton;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
    }
}


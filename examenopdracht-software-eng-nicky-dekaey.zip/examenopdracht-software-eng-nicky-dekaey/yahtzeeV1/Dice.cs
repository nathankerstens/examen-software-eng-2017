﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace yahtzeeV1
{
    class Dice
    {
        public int setDice;

        public int RndNummer(Random nr)
        {
            setDice = nr.Next(1, 7);
            return setDice;
        }
    }
}

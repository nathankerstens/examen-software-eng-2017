﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.gameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonRoll = new System.Windows.Forms.Button();
            this.buttonAces = new System.Windows.Forms.Button();
            this.buttonTwos = new System.Windows.Forms.Button();
            this.buttonThrees = new System.Windows.Forms.Button();
            this.buttonFours = new System.Windows.Forms.Button();
            this.buttonFives = new System.Windows.Forms.Button();
            this.buttonSixes = new System.Windows.Forms.Button();
            this.buttonTOAK = new System.Windows.Forms.Button();
            this.buttonFOAK = new System.Windows.Forms.Button();
            this.buttonFH = new System.Windows.Forms.Button();
            this.buttonSmallStraight = new System.Windows.Forms.Button();
            this.buttonLargeStraight = new System.Windows.Forms.Button();
            this.buttonYahtzee = new System.Windows.Forms.Button();
            this.buttonChance = new System.Windows.Forms.Button();
            this.labelRolls = new System.Windows.Forms.Label();
            this.labelAces = new System.Windows.Forms.Label();
            this.labelTwos = new System.Windows.Forms.Label();
            this.labelThrees = new System.Windows.Forms.Label();
            this.labelFours = new System.Windows.Forms.Label();
            this.labelFives = new System.Windows.Forms.Label();
            this.labelSixes = new System.Windows.Forms.Label();
            this.labelTop = new System.Windows.Forms.Label();
            this.labelBonus = new System.Windows.Forms.Label();
            this.labelTopTotal = new System.Windows.Forms.Label();
            this.labelTOAK = new System.Windows.Forms.Label();
            this.labelFOAK = new System.Windows.Forms.Label();
            this.labelFH = new System.Windows.Forms.Label();
            this.labelSmallStraight = new System.Windows.Forms.Label();
            this.labelLargeStraight = new System.Windows.Forms.Label();
            this.labelChance = new System.Windows.Forms.Label();
            this.labelYahtzee = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(12, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 100);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(12, 133);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(62, 17);
            this.checkBox1.TabIndex = 1;
            this.checkBox1.Text = "Locked";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(12, 262);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(62, 17);
            this.checkBox2.TabIndex = 3;
            this.checkBox2.Text = "Locked";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(12, 156);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 100);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(12, 391);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(62, 17);
            this.checkBox3.TabIndex = 5;
            this.checkBox3.Text = "Locked";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(12, 285);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 100);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(12, 520);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(62, 17);
            this.checkBox4.TabIndex = 7;
            this.checkBox4.Text = "Locked";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Location = new System.Drawing.Point(12, 414);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(100, 100);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 6;
            this.pictureBox4.TabStop = false;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(12, 649);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(62, 17);
            this.checkBox5.TabIndex = 9;
            this.checkBox5.Text = "Locked";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Location = new System.Drawing.Point(12, 543);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(100, 100);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 8;
            this.pictureBox5.TabStop = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gameToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(361, 24);
            this.menuStrip1.TabIndex = 10;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // gameToolStripMenuItem
            // 
            this.gameToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.closeToolStripMenuItem});
            this.gameToolStripMenuItem.Name = "gameToolStripMenuItem";
            this.gameToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.gameToolStripMenuItem.Text = "Game";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.newToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.newToolStripMenuItem.Text = "New";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // buttonRoll
            // 
            this.buttonRoll.Location = new System.Drawing.Point(258, 620);
            this.buttonRoll.Name = "buttonRoll";
            this.buttonRoll.Size = new System.Drawing.Size(75, 23);
            this.buttonRoll.TabIndex = 11;
            this.buttonRoll.Text = "Roll dice";
            this.buttonRoll.UseVisualStyleBackColor = true;
            this.buttonRoll.Click += new System.EventHandler(this.buttonRoll_Click);
            // 
            // buttonAces
            // 
            this.buttonAces.Enabled = false;
            this.buttonAces.Location = new System.Drawing.Point(199, 27);
            this.buttonAces.Name = "buttonAces";
            this.buttonAces.Size = new System.Drawing.Size(50, 23);
            this.buttonAces.TabIndex = 12;
            this.buttonAces.Tag = "1";
            this.buttonAces.UseVisualStyleBackColor = true;
            this.buttonAces.Click += new System.EventHandler(this.TagIsDiceValue_Click);
            // 
            // buttonTwos
            // 
            this.buttonTwos.Enabled = false;
            this.buttonTwos.Location = new System.Drawing.Point(199, 57);
            this.buttonTwos.Name = "buttonTwos";
            this.buttonTwos.Size = new System.Drawing.Size(50, 23);
            this.buttonTwos.TabIndex = 13;
            this.buttonTwos.Tag = "2";
            this.buttonTwos.UseVisualStyleBackColor = true;
            this.buttonTwos.Click += new System.EventHandler(this.TagIsDiceValue_Click);
            // 
            // buttonThrees
            // 
            this.buttonThrees.Enabled = false;
            this.buttonThrees.Location = new System.Drawing.Point(199, 86);
            this.buttonThrees.Name = "buttonThrees";
            this.buttonThrees.Size = new System.Drawing.Size(50, 23);
            this.buttonThrees.TabIndex = 14;
            this.buttonThrees.Tag = "3";
            this.buttonThrees.UseVisualStyleBackColor = true;
            this.buttonThrees.Click += new System.EventHandler(this.TagIsDiceValue_Click);
            // 
            // buttonFours
            // 
            this.buttonFours.Enabled = false;
            this.buttonFours.Location = new System.Drawing.Point(199, 115);
            this.buttonFours.Name = "buttonFours";
            this.buttonFours.Size = new System.Drawing.Size(50, 23);
            this.buttonFours.TabIndex = 15;
            this.buttonFours.Tag = "4";
            this.buttonFours.UseVisualStyleBackColor = true;
            this.buttonFours.Click += new System.EventHandler(this.TagIsDiceValue_Click);
            // 
            // buttonFives
            // 
            this.buttonFives.Enabled = false;
            this.buttonFives.Location = new System.Drawing.Point(199, 144);
            this.buttonFives.Name = "buttonFives";
            this.buttonFives.Size = new System.Drawing.Size(50, 23);
            this.buttonFives.TabIndex = 16;
            this.buttonFives.Tag = "5";
            this.buttonFives.UseVisualStyleBackColor = true;
            this.buttonFives.Click += new System.EventHandler(this.TagIsDiceValue_Click);
            // 
            // buttonSixes
            // 
            this.buttonSixes.Enabled = false;
            this.buttonSixes.Location = new System.Drawing.Point(199, 173);
            this.buttonSixes.Name = "buttonSixes";
            this.buttonSixes.Size = new System.Drawing.Size(50, 23);
            this.buttonSixes.TabIndex = 17;
            this.buttonSixes.Tag = "6";
            this.buttonSixes.UseVisualStyleBackColor = true;
            this.buttonSixes.Click += new System.EventHandler(this.TagIsDiceValue_Click);
            // 
            // buttonTOAK
            // 
            this.buttonTOAK.Enabled = false;
            this.buttonTOAK.Location = new System.Drawing.Point(199, 317);
            this.buttonTOAK.Name = "buttonTOAK";
            this.buttonTOAK.Size = new System.Drawing.Size(50, 23);
            this.buttonTOAK.TabIndex = 18;
            this.buttonTOAK.Tag = "";
            this.buttonTOAK.UseVisualStyleBackColor = true;
            this.buttonTOAK.Click += new System.EventHandler(this.TagIsScore_Click);
            // 
            // buttonFOAK
            // 
            this.buttonFOAK.Enabled = false;
            this.buttonFOAK.Location = new System.Drawing.Point(199, 346);
            this.buttonFOAK.Name = "buttonFOAK";
            this.buttonFOAK.Size = new System.Drawing.Size(50, 23);
            this.buttonFOAK.TabIndex = 19;
            this.buttonFOAK.Tag = "";
            this.buttonFOAK.UseVisualStyleBackColor = true;
            this.buttonFOAK.Click += new System.EventHandler(this.TagIsScore_Click);
            // 
            // buttonFH
            // 
            this.buttonFH.Enabled = false;
            this.buttonFH.Location = new System.Drawing.Point(199, 375);
            this.buttonFH.Name = "buttonFH";
            this.buttonFH.Size = new System.Drawing.Size(50, 23);
            this.buttonFH.TabIndex = 20;
            this.buttonFH.Tag = "";
            this.buttonFH.UseVisualStyleBackColor = true;
            this.buttonFH.Click += new System.EventHandler(this.TagIsScore_Click);
            // 
            // buttonSmallStraight
            // 
            this.buttonSmallStraight.Enabled = false;
            this.buttonSmallStraight.Location = new System.Drawing.Point(199, 404);
            this.buttonSmallStraight.Name = "buttonSmallStraight";
            this.buttonSmallStraight.Size = new System.Drawing.Size(50, 23);
            this.buttonSmallStraight.TabIndex = 21;
            this.buttonSmallStraight.Tag = "";
            this.buttonSmallStraight.UseVisualStyleBackColor = true;
            this.buttonSmallStraight.Click += new System.EventHandler(this.TagIsScore_Click);
            // 
            // buttonLargeStraight
            // 
            this.buttonLargeStraight.Enabled = false;
            this.buttonLargeStraight.Location = new System.Drawing.Point(199, 433);
            this.buttonLargeStraight.Name = "buttonLargeStraight";
            this.buttonLargeStraight.Size = new System.Drawing.Size(50, 23);
            this.buttonLargeStraight.TabIndex = 22;
            this.buttonLargeStraight.Tag = "";
            this.buttonLargeStraight.UseVisualStyleBackColor = true;
            this.buttonLargeStraight.Click += new System.EventHandler(this.TagIsScore_Click);
            // 
            // buttonYahtzee
            // 
            this.buttonYahtzee.Enabled = false;
            this.buttonYahtzee.Location = new System.Drawing.Point(199, 462);
            this.buttonYahtzee.Name = "buttonYahtzee";
            this.buttonYahtzee.Size = new System.Drawing.Size(50, 23);
            this.buttonYahtzee.TabIndex = 23;
            this.buttonYahtzee.Tag = "";
            this.buttonYahtzee.UseVisualStyleBackColor = true;
            this.buttonYahtzee.Click += new System.EventHandler(this.TagIsScore_Click);
            // 
            // buttonChance
            // 
            this.buttonChance.Enabled = false;
            this.buttonChance.Location = new System.Drawing.Point(199, 491);
            this.buttonChance.Name = "buttonChance";
            this.buttonChance.Size = new System.Drawing.Size(50, 23);
            this.buttonChance.TabIndex = 24;
            this.buttonChance.Tag = "";
            this.buttonChance.UseVisualStyleBackColor = true;
            this.buttonChance.Click += new System.EventHandler(this.TagIsScore_Click);
            // 
            // labelRolls
            // 
            this.labelRolls.AutoSize = true;
            this.labelRolls.Location = new System.Drawing.Point(259, 646);
            this.labelRolls.Name = "labelRolls";
            this.labelRolls.Size = new System.Drawing.Size(50, 13);
            this.labelRolls.TabIndex = 33;
            this.labelRolls.Text = "Rolls left:";
            // 
            // labelAces
            // 
            this.labelAces.AutoSize = true;
            this.labelAces.Location = new System.Drawing.Point(255, 32);
            this.labelAces.Name = "labelAces";
            this.labelAces.Size = new System.Drawing.Size(53, 13);
            this.labelAces.TabIndex = 34;
            this.labelAces.Text = "labelAces";
            // 
            // labelTwos
            // 
            this.labelTwos.AutoSize = true;
            this.labelTwos.Location = new System.Drawing.Point(255, 62);
            this.labelTwos.Name = "labelTwos";
            this.labelTwos.Size = new System.Drawing.Size(55, 13);
            this.labelTwos.TabIndex = 35;
            this.labelTwos.Text = "labelTwos";
            // 
            // labelThrees
            // 
            this.labelThrees.AutoSize = true;
            this.labelThrees.Location = new System.Drawing.Point(255, 91);
            this.labelThrees.Name = "labelThrees";
            this.labelThrees.Size = new System.Drawing.Size(62, 13);
            this.labelThrees.TabIndex = 36;
            this.labelThrees.Text = "labelThrees";
            // 
            // labelFours
            // 
            this.labelFours.AutoSize = true;
            this.labelFours.Location = new System.Drawing.Point(255, 120);
            this.labelFours.Name = "labelFours";
            this.labelFours.Size = new System.Drawing.Size(55, 13);
            this.labelFours.TabIndex = 37;
            this.labelFours.Text = "labelFours";
            // 
            // labelFives
            // 
            this.labelFives.AutoSize = true;
            this.labelFives.Location = new System.Drawing.Point(255, 149);
            this.labelFives.Name = "labelFives";
            this.labelFives.Size = new System.Drawing.Size(54, 13);
            this.labelFives.TabIndex = 38;
            this.labelFives.Text = "labelFives";
            // 
            // labelSixes
            // 
            this.labelSixes.AutoSize = true;
            this.labelSixes.Location = new System.Drawing.Point(255, 178);
            this.labelSixes.Name = "labelSixes";
            this.labelSixes.Size = new System.Drawing.Size(54, 13);
            this.labelSixes.TabIndex = 39;
            this.labelSixes.Text = "labelSixes";
            // 
            // labelTop
            // 
            this.labelTop.AutoSize = true;
            this.labelTop.Location = new System.Drawing.Point(255, 224);
            this.labelTop.Name = "labelTop";
            this.labelTop.Size = new System.Drawing.Size(48, 13);
            this.labelTop.TabIndex = 40;
            this.labelTop.Text = "labelTop";
            // 
            // labelBonus
            // 
            this.labelBonus.AutoSize = true;
            this.labelBonus.Location = new System.Drawing.Point(255, 253);
            this.labelBonus.Name = "labelBonus";
            this.labelBonus.Size = new System.Drawing.Size(59, 13);
            this.labelBonus.TabIndex = 41;
            this.labelBonus.Text = "labelBonus";
            // 
            // labelTopTotal
            // 
            this.labelTopTotal.AutoSize = true;
            this.labelTopTotal.Location = new System.Drawing.Point(255, 282);
            this.labelTopTotal.Name = "labelTopTotal";
            this.labelTopTotal.Size = new System.Drawing.Size(72, 13);
            this.labelTopTotal.TabIndex = 42;
            this.labelTopTotal.Text = "labelTopTotal";
            // 
            // labelTOAK
            // 
            this.labelTOAK.AutoSize = true;
            this.labelTOAK.Location = new System.Drawing.Point(255, 322);
            this.labelTOAK.Name = "labelTOAK";
            this.labelTOAK.Size = new System.Drawing.Size(58, 13);
            this.labelTOAK.TabIndex = 43;
            this.labelTOAK.Text = "labelTOAK";
            // 
            // labelFOAK
            // 
            this.labelFOAK.AutoSize = true;
            this.labelFOAK.Location = new System.Drawing.Point(255, 351);
            this.labelFOAK.Name = "labelFOAK";
            this.labelFOAK.Size = new System.Drawing.Size(57, 13);
            this.labelFOAK.TabIndex = 44;
            this.labelFOAK.Text = "labelFOAK";
            // 
            // labelFH
            // 
            this.labelFH.AutoSize = true;
            this.labelFH.Location = new System.Drawing.Point(255, 380);
            this.labelFH.Name = "labelFH";
            this.labelFH.Size = new System.Drawing.Size(43, 13);
            this.labelFH.TabIndex = 45;
            this.labelFH.Text = "labelFH";
            // 
            // labelSmallStraight
            // 
            this.labelSmallStraight.AutoSize = true;
            this.labelSmallStraight.Location = new System.Drawing.Point(255, 409);
            this.labelSmallStraight.Name = "labelSmallStraight";
            this.labelSmallStraight.Size = new System.Drawing.Size(90, 13);
            this.labelSmallStraight.TabIndex = 46;
            this.labelSmallStraight.Text = "labelSmallStraight";
            // 
            // labelLargeStraight
            // 
            this.labelLargeStraight.AutoSize = true;
            this.labelLargeStraight.Location = new System.Drawing.Point(255, 438);
            this.labelLargeStraight.Name = "labelLargeStraight";
            this.labelLargeStraight.Size = new System.Drawing.Size(92, 13);
            this.labelLargeStraight.TabIndex = 47;
            this.labelLargeStraight.Text = "labelLargeStraight";
            // 
            // labelChance
            // 
            this.labelChance.AutoSize = true;
            this.labelChance.Location = new System.Drawing.Point(255, 496);
            this.labelChance.Name = "labelChance";
            this.labelChance.Size = new System.Drawing.Size(66, 13);
            this.labelChance.TabIndex = 48;
            this.labelChance.Text = "labelChance";
            // 
            // labelYahtzee
            // 
            this.labelYahtzee.AutoSize = true;
            this.labelYahtzee.Location = new System.Drawing.Point(255, 467);
            this.labelYahtzee.Name = "labelYahtzee";
            this.labelYahtzee.Size = new System.Drawing.Size(68, 13);
            this.labelYahtzee.TabIndex = 49;
            this.labelYahtzee.Text = "labelYahtzee";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(160, 224);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 13);
            this.label1.TabIndex = 50;
            this.label1.Text = "Score of top:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(160, 253);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 13);
            this.label2.TabIndex = 51;
            this.label2.Text = "Bonus? (>=63)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(160, 282);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 52;
            this.label3.Text = "Total top:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(156, 32);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 13);
            this.label4.TabIndex = 53;
            this.label4.Text = "Aces: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(160, 62);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 13);
            this.label5.TabIndex = 54;
            this.label5.Text = "Twos:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(150, 91);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 13);
            this.label6.TabIndex = 55;
            this.label6.Text = "Threes:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(157, 120);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 13);
            this.label7.TabIndex = 56;
            this.label7.Text = "Fours:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(158, 149);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 13);
            this.label8.TabIndex = 57;
            this.label8.Text = "Fives:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(158, 178);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 13);
            this.label9.TabIndex = 58;
            this.label9.Text = "Sixes:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(133, 322);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 13);
            this.label10.TabIndex = 59;
            this.label10.Text = "3 of a kind:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(133, 351);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 13);
            this.label11.TabIndex = 60;
            this.label11.Text = "4 of a kind:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(133, 380);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(60, 13);
            this.label12.TabIndex = 61;
            this.label12.Text = "Full House:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(119, 409);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(74, 13);
            this.label13.TabIndex = 62;
            this.label13.Text = "Small Straight:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(117, 438);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(76, 13);
            this.label14.TabIndex = 63;
            this.label14.Text = "Large Straight:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(144, 467);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(49, 13);
            this.label15.TabIndex = 64;
            this.label15.Text = "Yahtzee:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(146, 496);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(47, 13);
            this.label16.TabIndex = 65;
            this.label16.Text = "Chance:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(210, 534);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(63, 13);
            this.label17.TabIndex = 66;
            this.label17.Text = "Total score:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(361, 673);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelYahtzee);
            this.Controls.Add(this.labelChance);
            this.Controls.Add(this.labelLargeStraight);
            this.Controls.Add(this.labelSmallStraight);
            this.Controls.Add(this.labelFH);
            this.Controls.Add(this.labelFOAK);
            this.Controls.Add(this.labelTOAK);
            this.Controls.Add(this.labelTopTotal);
            this.Controls.Add(this.labelBonus);
            this.Controls.Add(this.labelTop);
            this.Controls.Add(this.labelSixes);
            this.Controls.Add(this.labelFives);
            this.Controls.Add(this.labelFours);
            this.Controls.Add(this.labelThrees);
            this.Controls.Add(this.labelTwos);
            this.Controls.Add(this.labelAces);
            this.Controls.Add(this.labelRolls);
            this.Controls.Add(this.buttonChance);
            this.Controls.Add(this.buttonYahtzee);
            this.Controls.Add(this.buttonLargeStraight);
            this.Controls.Add(this.buttonSmallStraight);
            this.Controls.Add(this.buttonFH);
            this.Controls.Add(this.buttonFOAK);
            this.Controls.Add(this.buttonTOAK);
            this.Controls.Add(this.buttonSixes);
            this.Controls.Add(this.buttonFives);
            this.Controls.Add(this.buttonFours);
            this.Controls.Add(this.buttonThrees);
            this.Controls.Add(this.buttonTwos);
            this.Controls.Add(this.buttonAces);
            this.Controls.Add(this.buttonRoll);
            this.Controls.Add(this.checkBox5);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.checkBox4);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Yahtzee";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem gameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.Button buttonRoll;
        private System.Windows.Forms.Button buttonAces;
        private System.Windows.Forms.Button buttonTwos;
        private System.Windows.Forms.Button buttonThrees;
        private System.Windows.Forms.Button buttonFours;
        private System.Windows.Forms.Button buttonFives;
        private System.Windows.Forms.Button buttonSixes;
        private System.Windows.Forms.Button buttonTOAK;
        private System.Windows.Forms.Button buttonFOAK;
        private System.Windows.Forms.Button buttonFH;
        private System.Windows.Forms.Button buttonSmallStraight;
        private System.Windows.Forms.Button buttonLargeStraight;
        private System.Windows.Forms.Button buttonYahtzee;
        private System.Windows.Forms.Button buttonChance;
        private System.Windows.Forms.Label labelRolls;
        private System.Windows.Forms.Label labelAces;
        private System.Windows.Forms.Label labelTwos;
        private System.Windows.Forms.Label labelThrees;
        private System.Windows.Forms.Label labelFours;
        private System.Windows.Forms.Label labelFives;
        private System.Windows.Forms.Label labelSixes;
        private System.Windows.Forms.Label labelTop;
        private System.Windows.Forms.Label labelBonus;
        private System.Windows.Forms.Label labelTopTotal;
        private System.Windows.Forms.Label labelTOAK;
        private System.Windows.Forms.Label labelFOAK;
        private System.Windows.Forms.Label labelFH;
        private System.Windows.Forms.Label labelSmallStraight;
        private System.Windows.Forms.Label labelLargeStraight;
        private System.Windows.Forms.Label labelChance;
        private System.Windows.Forms.Label labelYahtzee;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
    }
}


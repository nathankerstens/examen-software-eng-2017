﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1.Properties;

namespace WindowsFormsApp1
{
    class Game
    {
        public int amountOfRolls = 3;
        Form1 form;
        Dice[] dices = new Dice[5];
        CheckBox[] boxes = new CheckBox[5];

        public Game(Form1 form)
        {
            this.form = form;
            for (int i = 0; i < dices.Length; i++)
            {
                dices[i] = new Dice();
                boxes[i] = new CheckBox();
                dices[i].imgPath = new Bitmap(Resources.dice0);
            }
        }
        public Dice[] GetDices()
        {
            return dices;
        }

        public void CheckChecked(List<CheckBox> cBoxes)
        {
            for (int i = 0; i < cBoxes.Count; i++)
            {
                if (cBoxes[i].Checked)
                {
                    dices[i].isLocked = true;
                }
                else
                {
                    dices[i].isLocked = false;
                }
            }
        }
        public void RollDices()
        {            
            Random rnd = new Random();
            for (int i = 0; i < dices.Length; i++)
            {
                if (dices[i].isLocked == false)
                {
                    dices[i].value = rnd.Next(1, 7);
                }

            }
            form.RefreshBoxes();
        }
        public void UpdateRolls()
        {
            amountOfRolls--;
        }
        public void ResetRolls()
        {
            amountOfRolls = 3;
        }
        public int SumOfDice()
        {
            int sumOfDice = 0;
            foreach (Dice d in dices)
            {
                sumOfDice += d.value;
            }
            return sumOfDice;
        }
        public int CheckValue(int value)
        {
            int count = 0;
            for (int i = 0; i < dices.Length; i++)
            {
                if (dices[i].value == value)
                {
                    count ++;
                }
            }
            return count;
        }
        public int CheckXOAK(int xOfAKind, int ignoreDice = 0)
        {
            for (int diceValue = 1; diceValue <= 6; diceValue++)//Loop through the 6 possible values
            {
                
                if (diceValue == ignoreDice) continue; //Only continue for the values that aren't ignoreDice
                int diceCount = 0;//Keep track of the amount of times value x returns

                for (int diceIndex = 0; diceIndex < 5; diceIndex++)//Check each dice
                {
                    if (dices[diceIndex].value == diceValue)//If the value searched for returns, add to the count
                        diceCount++;

                    if (diceCount >= xOfAKind)//If a value returns the amount of times desired, return the amount of times
                    {
                        return diceValue;
                    }
                    
                }
                
            }
            return 0;
        }
        public int CheckStreet()
        {
            
            int[] allValues = new int[5];
            for (int i = 0; i < dices.Length; i++)
            {
                allValues[i] = dices[i].value;
            }
            Array.Sort(allValues);
            int count=1;
            for (int i = 1; i < allValues.Length; i++)
            {
                if (allValues[i] == allValues[i - 1]+1)
                {
                    count++;
                }
            }
            return count;
        }
    }
}

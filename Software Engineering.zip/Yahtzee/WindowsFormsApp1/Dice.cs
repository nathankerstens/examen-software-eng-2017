﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsApp1.Properties;

namespace WindowsFormsApp1
{
    class Dice 
    {
        public int value;
        public Bitmap imgPath;
        public bool isLocked;


        public void setValue(int value)
        {
            imgPath = new Bitmap(Resources.dice0);
        }
    }
}

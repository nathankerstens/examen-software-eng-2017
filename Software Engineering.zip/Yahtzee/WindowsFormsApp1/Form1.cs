﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1.Properties;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        Game game;
        public List<PictureBox> pBoxes = new List<PictureBox>();
        public List<CheckBox> cBoxes = new List<CheckBox>();
        public List<Button> buttons = new List<Button>();
        public List<Label> labels = new List<Label>();
        private Dictionary<Button, Label> _ButtonsAndLabels = new Dictionary<Button, Label>();

        bool isChanceUsed = false;
        bool hasBonus = false;
        bool hasOption = true;

        public Form1()
        {
            InitializeComponent();
            game = new Game(this);

            pBoxes.Add(pictureBox1);
            pBoxes.Add(pictureBox2);
            pBoxes.Add(pictureBox3);
            pBoxes.Add(pictureBox4);
            pBoxes.Add(pictureBox5);

            cBoxes.Add(checkBox1);
            cBoxes.Add(checkBox2);
            cBoxes.Add(checkBox3);
            cBoxes.Add(checkBox4);
            cBoxes.Add(checkBox5);
            for (int i = 0; i < cBoxes.Count; i++)
            {
                cBoxes[i].Enabled = false;
            }

            buttons.Add(buttonAces);
            buttons.Add(buttonTwos);
            buttons.Add(buttonThrees);
            buttons.Add(buttonFours);
            buttons.Add(buttonFives);
            buttons.Add(buttonSixes);
            buttons.Add(buttonTOAK);
            buttons.Add(buttonFOAK);
            buttons.Add(buttonFH);
            buttons.Add(buttonSmallStraight);
            buttons.Add(buttonLargeStraight);
            buttons.Add(buttonYahtzee);
            buttons.Add(buttonChance);

            labels.Add(labelAces);
            labels.Add(labelTwos);
            labels.Add(labelThrees);
            labels.Add(labelFours);
            labels.Add(labelFives);
            labels.Add(labelSixes);
            labels.Add(labelTop);
            labels.Add(labelBonus);
            labels.Add(labelTopTotal);
            labels.Add(labelTOAK);
            labels.Add(labelFOAK);
            labels.Add(labelFH);
            labels.Add(labelSmallStraight);
            labels.Add(labelLargeStraight);
            labels.Add(labelYahtzee);
            labels.Add(labelChance);
            
            _ButtonsAndLabels.Add(buttonAces, labelAces);
            _ButtonsAndLabels.Add(buttonTwos, labelTwos);
            _ButtonsAndLabels.Add(buttonThrees, labelThrees);
            _ButtonsAndLabels.Add(buttonFours, labelFours);
            _ButtonsAndLabels.Add(buttonFives, labelFives);
            _ButtonsAndLabels.Add(buttonSixes, labelSixes);
            _ButtonsAndLabels.Add(buttonTOAK, labelTOAK);
            _ButtonsAndLabels.Add(buttonFOAK, labelFOAK);
            _ButtonsAndLabels.Add(buttonFH, labelFH);
            _ButtonsAndLabels.Add(buttonSmallStraight, labelSmallStraight);
            _ButtonsAndLabels.Add(buttonLargeStraight, labelLargeStraight);
            _ButtonsAndLabels.Add(buttonYahtzee, labelYahtzee);
            _ButtonsAndLabels.Add(buttonChance, labelChance);

            for (int i = 0; i < labels.Count; i++)
            {
                labels[i].Text = null;
            }
        }
        public void RefreshBoxes()
        {
            Dice[] dices = game.GetDices();
            for (int i = 0; i < dices.Length; i++)
            {
                pBoxes[i].Image = Resources.ResourceManager.GetObject("dice" + dices[i].value) as Image;
            }
        }
        private void ScoreOfTop()
        {
            int sum = 0;
            for (int i = 0; i < 6; i++)
            {
                Int32.TryParse(labels[i].Text, out int value);
                sum += value;
            }
            labelTop.Text = sum.ToString();
            if(sum >= 63)
            {
                hasBonus = true;
                labelBonus.Text = "YES!";
                labelTopTotal.Text = (sum + 35).ToString();
            }
            else
            {
                labelBonus.Text = "NO!";
                labelTopTotal.Text = sum.ToString();
            }
        }
        private void isGameDone()
        {
            int sum = 0;
            foreach (Label l in _ButtonsAndLabels.Values)
            {
                int value;
                bool success = Int32.TryParse(l.Text, out value);
                if (!success)
                {
                    return;
                }
                sum += value;
            }
            if (hasBonus)
            {
                sum += 35;
            }
            var result = MessageBox.Show("You finished with score: " + sum, "Message",
            MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (result == DialogResult.Yes)
            {
                Application.Restart();
            }
            if (result == DialogResult.No)
            {
                Application.Exit();
            }
        }
        private void UpdateLabel()
        {
            if (game.amountOfRolls == 0)
            {
                buttonRoll.Enabled = false;
                labelRolls.Text = "Rolls left: 0";
            }
            labelRolls.Text = "Rolls left: " + game.amountOfRolls;
        }
        private void CheckTop()
        {
            for (int i = 0; i < 6; i++)
            {
                int diceValue = i + 1;
                if(game.CheckValue(diceValue) >= 1)
                {
                    buttons[i].Enabled = true;
                    buttons[i].Text = (game.CheckValue(diceValue) * diceValue).ToString();
                }
                else
                {
                    buttons[i].Enabled = false;
                    buttons[i].Text = (i+1).ToString();
                }
            }
        }
        private void CheckBottom()
        {
            int threeOfAKind = game.CheckXOAK(3);
            int fourOfAKind = game.CheckXOAK(4);
            int yahtzee = game.CheckXOAK(5);
            int street = game.CheckStreet();

            if (threeOfAKind != 0)
            {
                buttonTOAK.Enabled = true;
                buttonTOAK.Tag = game.SumOfDice();
                buttonTOAK.Text = game.SumOfDice().ToString();
                if (game.CheckXOAK(2,threeOfAKind) != 0)
                {
                    buttonFH.Enabled = true;
                    buttonFH.Tag = 25;
                    buttonFH.Text = "25";
                }
                else
                {
                    buttonFH.Enabled = false;
                    buttonFH.Tag = "";
                }
            }
            else
            {
                buttonTOAK.Enabled = false;
                buttonTOAK.Tag = "";
            }
            if (fourOfAKind != 0)
            {
                buttonFOAK.Enabled = true;
                buttonFOAK.Tag = game.SumOfDice();
                buttonFOAK.Text = game.SumOfDice().ToString();
            }
            else
            {
                buttonFOAK.Enabled = false;
                buttonFOAK.Tag = "";
            }
            if (yahtzee != 0)
            {
                buttonYahtzee.Enabled = true;
                buttonYahtzee.Tag = 50;
                buttonYahtzee.Text = "50";
            }
            else
            {
                buttonYahtzee.Enabled = false;
                buttonYahtzee.Tag = "";
            }
            if(street >= 4)
            {
                buttonSmallStraight.Enabled = true;
                buttonSmallStraight.Tag = 30;
                buttonSmallStraight.Text = "30";
            }
            else
            {
                buttonSmallStraight.Enabled = false;
                buttonSmallStraight.Tag = "";
            }
            if(street == 5)
            {
                buttonLargeStraight.Enabled = true;
                buttonLargeStraight.Tag = 40;
                buttonLargeStraight.Text = "40";
            }
            else
            {
                buttonLargeStraight.Enabled = false;
                buttonLargeStraight.Tag = "";
            }
            if (!isChanceUsed)
            {
                buttonChance.Enabled = true;
                buttonChance.Tag = game.SumOfDice().ToString();
                buttonChance.Text = game.SumOfDice().ToString();
            }
            else
            {
                buttonChance.Enabled = false;
                buttonChance.Tag = "";
            }
        }
        private void NoOptions()
        {
            hasOption = false;
            foreach (Button b in _ButtonsAndLabels.Keys)
            {
                if (b.Enabled)
                {
                    hasOption = true;
                }
            }
            foreach (Button b in _ButtonsAndLabels.Keys)
            {
                if (!b.Enabled && game.amountOfRolls == 0)
                {
                    b.Enabled = true;
                    b.Text = "0";
                }
            }

        }
        private void Reset()
        {
            ScoreOfTop();
            buttonRoll.Enabled = true;

            foreach (Button b in _ButtonsAndLabels.Keys)
            {
                Label label = _ButtonsAndLabels[b];
                if (label.Text == null || label.Text == String.Empty)
                { 
                    b.Visible = true;
                    b.Enabled = false;
                    b.Text = "";
                }
            }
            foreach (CheckBox c in cBoxes)
            {
                c.Checked = false;
                c.Enabled = false;
            }
            game.ResetRolls();
            isGameDone();
        }

        private void buttonRoll_Click(object sender, EventArgs e)
        {
            game.CheckChecked(cBoxes);
            game.RollDices();
            game.UpdateRolls();
            UpdateLabel();
            CheckTop();
            CheckBottom();
            NoOptions();
            for (int i = 0; i < cBoxes.Count; i++)
            {
                cBoxes[i].Enabled = true;
            }
        }
        private void TagIsDiceValue_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            Label label = _ButtonsAndLabels[button];
            int diceValue = Convert.ToInt32(button.Tag);//dice value
            button.Visible = false;
            if (hasOption)
            {
                label.Text = (game.CheckValue(diceValue) * diceValue).ToString();
            }
            else
            {
                label.Text = "0";
            }
            Reset();
            UpdateLabel();
        }
        private void TagIsScore_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            Label label = _ButtonsAndLabels[button];
            int score;
            Int32.TryParse(button.Tag.ToString(), out score);//score
            button.Visible = false;
            if (hasOption)
            {
                label.Text = score.ToString();
            }
            else
            {
                label.Text = "0";
            }
            Reset();
            UpdateLabel();
        }
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Are you sure you want to restart?", "Message",
            MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (result == DialogResult.Yes)
            {
                Application.Restart();
            }
        }
        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Are you sure you want to exit?", "Message",
            MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}

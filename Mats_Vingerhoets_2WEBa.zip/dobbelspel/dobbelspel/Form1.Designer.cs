﻿namespace dobbelspel
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_p1Dice1 = new System.Windows.Forms.Label();
            this.lbl_p1Dice2 = new System.Windows.Forms.Label();
            this.lbl_p1Dice3 = new System.Windows.Forms.Label();
            this.lbl_p1Dice4 = new System.Windows.Forms.Label();
            this.lbl_p1Dice5 = new System.Windows.Forms.Label();
            this.lbl_p1displayResults = new System.Windows.Forms.Label();
            this.lbl_p2Dice5 = new System.Windows.Forms.Label();
            this.lbl_p2Dice4 = new System.Windows.Forms.Label();
            this.lbl_p2Dice3 = new System.Windows.Forms.Label();
            this.lbl_p2Dice2 = new System.Windows.Forms.Label();
            this.lbl_p2Dice1 = new System.Windows.Forms.Label();
            this.Lbl_winnerResult = new System.Windows.Forms.Label();
            this.btn_P1RollDice = new System.Windows.Forms.Button();
            this.btn_P2RollDice = new System.Windows.Forms.Button();
            this.lbl_p1Name = new System.Windows.Forms.Label();
            this.lbl_P2Name = new System.Windows.Forms.Label();
            this.lbl_p2displayResults = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_p1Dice1
            // 
            this.lbl_p1Dice1.Image = global::dobbelspel.Properties.Resources.dice_blank;
            this.lbl_p1Dice1.Location = new System.Drawing.Point(40, 138);
            this.lbl_p1Dice1.Name = "lbl_p1Dice1";
            this.lbl_p1Dice1.Size = new System.Drawing.Size(50, 50);
            this.lbl_p1Dice1.TabIndex = 0;
            // 
            // lbl_p1Dice2
            // 
            this.lbl_p1Dice2.Image = global::dobbelspel.Properties.Resources.dice_blank;
            this.lbl_p1Dice2.Location = new System.Drawing.Point(96, 138);
            this.lbl_p1Dice2.Name = "lbl_p1Dice2";
            this.lbl_p1Dice2.Size = new System.Drawing.Size(50, 50);
            this.lbl_p1Dice2.TabIndex = 1;
            // 
            // lbl_p1Dice3
            // 
            this.lbl_p1Dice3.Image = global::dobbelspel.Properties.Resources.dice_blank;
            this.lbl_p1Dice3.Location = new System.Drawing.Point(152, 138);
            this.lbl_p1Dice3.Name = "lbl_p1Dice3";
            this.lbl_p1Dice3.Size = new System.Drawing.Size(50, 50);
            this.lbl_p1Dice3.TabIndex = 2;
            // 
            // lbl_p1Dice4
            // 
            this.lbl_p1Dice4.Image = global::dobbelspel.Properties.Resources.dice_blank;
            this.lbl_p1Dice4.Location = new System.Drawing.Point(208, 138);
            this.lbl_p1Dice4.Name = "lbl_p1Dice4";
            this.lbl_p1Dice4.Size = new System.Drawing.Size(50, 50);
            this.lbl_p1Dice4.TabIndex = 3;
            // 
            // lbl_p1Dice5
            // 
            this.lbl_p1Dice5.Image = global::dobbelspel.Properties.Resources.dice_blank;
            this.lbl_p1Dice5.Location = new System.Drawing.Point(264, 138);
            this.lbl_p1Dice5.Name = "lbl_p1Dice5";
            this.lbl_p1Dice5.Size = new System.Drawing.Size(50, 50);
            this.lbl_p1Dice5.TabIndex = 4;
            // 
            // lbl_p1displayResults
            // 
            this.lbl_p1displayResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_p1displayResults.Location = new System.Drawing.Point(38, 313);
            this.lbl_p1displayResults.Name = "lbl_p1displayResults";
            this.lbl_p1displayResults.Size = new System.Drawing.Size(250, 50);
            this.lbl_p1displayResults.TabIndex = 6;
            this.lbl_p1displayResults.Text = "Roll The Dice";
            this.lbl_p1displayResults.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_p2Dice5
            // 
            this.lbl_p2Dice5.Image = global::dobbelspel.Properties.Resources.dice_blank;
            this.lbl_p2Dice5.Location = new System.Drawing.Point(691, 138);
            this.lbl_p2Dice5.Name = "lbl_p2Dice5";
            this.lbl_p2Dice5.Size = new System.Drawing.Size(50, 50);
            this.lbl_p2Dice5.TabIndex = 11;
            // 
            // lbl_p2Dice4
            // 
            this.lbl_p2Dice4.Image = global::dobbelspel.Properties.Resources.dice_blank;
            this.lbl_p2Dice4.Location = new System.Drawing.Point(635, 138);
            this.lbl_p2Dice4.Name = "lbl_p2Dice4";
            this.lbl_p2Dice4.Size = new System.Drawing.Size(50, 50);
            this.lbl_p2Dice4.TabIndex = 10;
            // 
            // lbl_p2Dice3
            // 
            this.lbl_p2Dice3.Image = global::dobbelspel.Properties.Resources.dice_blank;
            this.lbl_p2Dice3.Location = new System.Drawing.Point(579, 138);
            this.lbl_p2Dice3.Name = "lbl_p2Dice3";
            this.lbl_p2Dice3.Size = new System.Drawing.Size(50, 50);
            this.lbl_p2Dice3.TabIndex = 9;
            // 
            // lbl_p2Dice2
            // 
            this.lbl_p2Dice2.Image = global::dobbelspel.Properties.Resources.dice_blank;
            this.lbl_p2Dice2.Location = new System.Drawing.Point(523, 138);
            this.lbl_p2Dice2.Name = "lbl_p2Dice2";
            this.lbl_p2Dice2.Size = new System.Drawing.Size(50, 50);
            this.lbl_p2Dice2.TabIndex = 8;
            // 
            // lbl_p2Dice1
            // 
            this.lbl_p2Dice1.Image = global::dobbelspel.Properties.Resources.dice_blank;
            this.lbl_p2Dice1.Location = new System.Drawing.Point(467, 138);
            this.lbl_p2Dice1.Name = "lbl_p2Dice1";
            this.lbl_p2Dice1.Size = new System.Drawing.Size(50, 50);
            this.lbl_p2Dice1.TabIndex = 7;
            // 
            // Lbl_winnerResult
            // 
            this.Lbl_winnerResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_winnerResult.Location = new System.Drawing.Point(223, 22);
            this.Lbl_winnerResult.Name = "Lbl_winnerResult";
            this.Lbl_winnerResult.Size = new System.Drawing.Size(350, 50);
            this.Lbl_winnerResult.TabIndex = 14;
            this.Lbl_winnerResult.Text = "Waiting for roll";
            this.Lbl_winnerResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_P1RollDice
            // 
            this.btn_P1RollDice.Location = new System.Drawing.Point(64, 241);
            this.btn_P1RollDice.Name = "btn_P1RollDice";
            this.btn_P1RollDice.Size = new System.Drawing.Size(194, 60);
            this.btn_P1RollDice.TabIndex = 15;
            this.btn_P1RollDice.Text = "Roll Dice";
            this.btn_P1RollDice.UseVisualStyleBackColor = true;
            this.btn_P1RollDice.Click += new System.EventHandler(this.btn_P1RollDice_Click);
            // 
            // btn_P2RollDice
            // 
            this.btn_P2RollDice.Location = new System.Drawing.Point(506, 241);
            this.btn_P2RollDice.Name = "btn_P2RollDice";
            this.btn_P2RollDice.Size = new System.Drawing.Size(194, 60);
            this.btn_P2RollDice.TabIndex = 16;
            this.btn_P2RollDice.Text = "Roll Dice";
            this.btn_P2RollDice.UseVisualStyleBackColor = true;
            this.btn_P2RollDice.Click += new System.EventHandler(this.btn_P2RollDice_Click);
            // 
            // lbl_p1Name
            // 
            this.lbl_p1Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_p1Name.Location = new System.Drawing.Point(38, 88);
            this.lbl_p1Name.Name = "lbl_p1Name";
            this.lbl_p1Name.Size = new System.Drawing.Size(250, 50);
            this.lbl_p1Name.TabIndex = 17;
            // 
            // lbl_P2Name
            // 
            this.lbl_P2Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P2Name.Location = new System.Drawing.Point(482, 88);
            this.lbl_P2Name.Name = "lbl_P2Name";
            this.lbl_P2Name.Size = new System.Drawing.Size(250, 50);
            this.lbl_P2Name.TabIndex = 18;
            // 
            // lbl_p2displayResults
            // 
            this.lbl_p2displayResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_p2displayResults.Location = new System.Drawing.Point(465, 323);
            this.lbl_p2displayResults.Name = "lbl_p2displayResults";
            this.lbl_p2displayResults.Size = new System.Drawing.Size(250, 50);
            this.lbl_p2displayResults.TabIndex = 19;
            this.lbl_p2displayResults.Text = "Roll The Dice";
            this.lbl_p2displayResults.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.lbl_p2displayResults);
            this.Controls.Add(this.lbl_P2Name);
            this.Controls.Add(this.lbl_p1Name);
            this.Controls.Add(this.btn_P2RollDice);
            this.Controls.Add(this.btn_P1RollDice);
            this.Controls.Add(this.Lbl_winnerResult);
            this.Controls.Add(this.lbl_p2Dice5);
            this.Controls.Add(this.lbl_p2Dice4);
            this.Controls.Add(this.lbl_p2Dice3);
            this.Controls.Add(this.lbl_p2Dice2);
            this.Controls.Add(this.lbl_p2Dice1);
            this.Controls.Add(this.lbl_p1displayResults);
            this.Controls.Add(this.lbl_p1Dice5);
            this.Controls.Add(this.lbl_p1Dice4);
            this.Controls.Add(this.lbl_p1Dice3);
            this.Controls.Add(this.lbl_p1Dice2);
            this.Controls.Add(this.lbl_p1Dice1);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(800, 600);
            this.MinimumSize = new System.Drawing.Size(800, 600);
            this.Name = "Form1";
            this.Text = "Dice Game";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbl_p1Dice1;
        private System.Windows.Forms.Label lbl_p1Dice2;
        private System.Windows.Forms.Label lbl_p1Dice3;
        private System.Windows.Forms.Label lbl_p1Dice4;
        private System.Windows.Forms.Label lbl_p1Dice5;
        private System.Windows.Forms.Label lbl_p1displayResults;
        private System.Windows.Forms.Label lbl_p2Dice5;
        private System.Windows.Forms.Label lbl_p2Dice4;
        private System.Windows.Forms.Label lbl_p2Dice3;
        private System.Windows.Forms.Label lbl_p2Dice2;
        private System.Windows.Forms.Label lbl_p2Dice1;
        private System.Windows.Forms.Label Lbl_winnerResult;
        private System.Windows.Forms.Button btn_P1RollDice;
        private System.Windows.Forms.Button btn_P2RollDice;
        private System.Windows.Forms.Label lbl_p1Name;
        private System.Windows.Forms.Label lbl_P2Name;
        private System.Windows.Forms.Label lbl_p2displayResults;
    }
}

